# DQ Platform Console

React + Vite + TypeScript + Tailwind console for the Data Quality Framework.
Multi-project: every page is scoped to the project selected in the sidebar
switcher. The current project persists to localStorage.

## Pages

| Route             | Purpose                                          |
|-------------------|--------------------------------------------------|
| `/`               | Dashboard — KPIs, pass-rate trend, recent runs   |
| `/rules`          | Rules catalog — search + filter by status        |
| `/rules/:ruleId`  | Rule editor — view/edit, dry-run, submit         |
| `/runs`           | Validation runs — full history with ADF lineage  |
| `/errors`         | Validation errors — failed records with lineage  |
| `/approvals`      | Approvals queue — author/reviewer/approver flow  |
| `/datasets`       | Datasets — coverage by layer                     |
| `/audit`          | Audit log — every config change + run trigger    |
| `/settings`       | Project settings (DQ FW + Ingestion FW context)  |

## Stack

- **React 18** + **TypeScript** + **React Router 6**
- **Vite** for build / dev server
- **Tailwind CSS 3** with a custom palette matching the design deck
- **Recharts** for the dashboard line + bar charts
- **Lucide** for icons

## Development

```bash
cd dqf-console
npm install
npm run dev          # vite dev server on port 5173
```

## Build

```bash
npm run build        # outputs to dist/
npm run preview      # preview the production build locally
```

## Wiring to the real backend

Right now the console uses a mock API in `src/api/mockClient.ts` that returns
seeded data with simulated latency. To switch to FastAPI:

1. Create `src/api/realClient.ts` with the same function signatures, calling
   `fetch("/api/projects/...")` etc.
2. Replace imports of `mockClient` with `realClient` (or add a feature flag).
3. Configure Vite's `server.proxy` to route `/api` to your FastAPI host
   during dev.

The mock client's exports are the contract — `listProjects`, `listRules`,
`listRuns`, `listErrors`, `listAudit`, `getProjectHealth`, `approveRule`,
`rejectRule`, etc. Keep these signatures stable when swapping in the real
implementation.

## Visual design notes

- Palette: deep navy (`#0B2545`) sidebar, teal (`#00A6A6`) accents, surface
  off-white. Matches the design deck exactly.
- Status pills: green (PASS / APPROVED), amber (WARN / PENDING), red (FAIL /
  REJECTED), grey (RETIRED / muted).
- Tabular numbers throughout — important for tables of counts and IDs.
- Mono font (JetBrains Mono fallback) for rule IDs, run IDs, dataset names,
  parameter keys, and SQL — anything you'd copy/paste.
