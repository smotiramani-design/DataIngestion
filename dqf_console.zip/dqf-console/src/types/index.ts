/**
 * Type definitions for the DQ Platform Console.
 *
 * Mirrors the Python dataclasses in `dqf/engine/rule_model.py` and the
 * Delta tables in `dqf/ddl/01_create_tables.sql`. Kept hand-written
 * (instead of generated) so the contract is explicit.
 */

export type Layer = "FILE" | "BUSINESS_RULE" | "POST_TRANSFORM";

export type Severity = "INFO" | "WARN" | "BLOCK";

export type CheckType =
  | "SCHEMA"
  | "ROW_COUNT_MIN"
  | "ROW_COUNT_DRIFT"
  | "NULL_PCT_MAX"
  | "PRIMARY_KEY"
  | "DOMAIN"
  | "EXPRESSION"
  | "REFERENTIAL_INTEGRITY"
  | "AGGREGATE_PARITY";

export type RuleStatus =
  | "DRAFT"
  | "PENDING_APPROVAL"
  | "APPROVED"
  | "REJECTED"
  | "RETIRED";

export type RunStatus = "RUNNING" | "PASS" | "WARN" | "FAIL" | "ERROR";

export type EffectiveStatus = "PASS" | "WARN" | "FAIL" | "ERROR";

export interface Project {
  project_id: number;
  project_code: string;
  project_name: string;
  default_catalog: string;
  bronze_schema: string;
  silver_schema: string;
  gold_schema: string;
  alert_email: string;
  owner_team: string;
  is_active: boolean;
  description?: string;
  cost_center?: string;
}

export interface DqProjectSettings {
  project_id: number;
  dq_framework_version: string;
  is_dq_enabled: boolean;
  block_publish_on_fail: boolean;
  notification_channel?: string;
  pagerduty_service?: string;
}

export interface Rule {
  project_id: number;
  project_code: string;
  rule_id: string;
  version: number;
  name: string;
  description?: string;
  layer: Layer;
  check_type: CheckType;
  severity: Severity;
  datasets: string[];
  expression?: string;
  params: Record<string, string>;
  owner: string;
  status: RuleStatus;
  enabled: boolean;
  effective_from?: string;
  effective_to?: string;
  created_by?: string;
  created_ts?: string;
}

export interface RuleVersion {
  project_id: number;
  rule_id: string;
  version: number;
  prev_version?: number;
  diff_summary?: string;
  change_reason?: string;
  submitted_by: string;
  submitted_ts: string;
  approved_by?: string;
  approved_ts?: string;
  rejection_reason?: string;
}

export interface ValidationRun {
  project_id: number;
  project_code: string;
  run_id: string;
  trigger_type: "FILE_ARRIVAL" | "SCHEDULE" | "INGEST_PIPELINE" | "MANUAL" | "API";
  trigger_ref?: string;
  layer_filter?: string;
  dataset_filter?: string;
  started_ts: string;
  ended_ts?: string;
  status: RunStatus;
  rules_evaluated: number;
  rules_passed: number;
  rules_warned: number;
  rules_failed: number;
  records_checked: number;
  framework_version: string;
  triggered_by: string;
}

export interface ValidationError {
  project_id: number;
  error_id: string;
  run_id: string;
  rule_id: string;
  rule_version: number;
  dataset: string;
  record_pk?: string;
  expected?: string;
  actual?: string;
  severity: Severity;
  sample_payload?: string;
  captured_ts: string;
}

export interface AuditEntry {
  project_id: number;
  audit_id: string;
  actor: string;
  role: "AUTHOR" | "REVIEWER" | "APPROVER" | "ADMIN" | "SYSTEM";
  action: string;
  entity_type: "RULE" | "RUN" | "DATASET" | "PROJECT_SETTINGS";
  entity_id: string;
  before_json?: string;
  after_json?: string;
  reason?: string;
  framework_version?: string;
  event_ts: string;
}

/** Rolled-up dashboard metric per project */
export interface ProjectHealth {
  project_id: number;
  project_code: string;
  project_name: string;
  dq_framework_version: string;
  runs_24h: number;
  runs_pass: number;
  runs_warn: number;
  runs_fail: number;
  total_rules_failed: number;
  total_records_checked: number;
  last_run_ts?: string;
}
