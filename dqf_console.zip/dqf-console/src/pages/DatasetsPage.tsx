import { useEffect, useMemo, useState } from "react";
import { Database } from "lucide-react";
import { useProject } from "../lib/projectContext";
import { listRules } from "../api/mockClient";
import type { Rule } from "../types";
import { PageHeader } from "../components/PageHeader";
import { EmptyState } from "../components/EmptyState";

export function DatasetsPage() {
  const { current } = useProject();
  const [rules, setRules] = useState<Rule[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!current) return;
    setLoading(true);
    let cancelled = false;
    listRules(current.project_id).then((rs) => {
      if (cancelled) return;
      setRules(rs);
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [current]);

  const datasets = useMemo(() => {
    const map = new Map<string, { name: string; layers: Set<string>; ruleCount: number }>();
    for (const r of rules) {
      for (const ds of r.datasets) {
        if (!map.has(ds)) map.set(ds, { name: ds, layers: new Set(), ruleCount: 0 });
        const e = map.get(ds)!;
        e.layers.add(r.layer);
        e.ruleCount += 1;
      }
    }
    return Array.from(map.values()).sort((a, b) => a.name.localeCompare(b.name));
  }, [rules]);

  if (!current) return null;

  return (
    <>
      <PageHeader
        eyebrow={`PROJECT · ${current.project_code}`}
        title="Datasets"
        subtitle="Tables this project's rules touch, with rule counts by layer."
      />

      <div className="px-8 py-6 max-w-[1400px]">
        <div className="card overflow-hidden">
          {loading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading datasets…</div>
          ) : datasets.length === 0 ? (
            <EmptyState icon={Database} title="No datasets"
                        description="No rules reference any datasets yet." />
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Dataset</th>
                  <th className="w-44">Layers covered</th>
                  <th className="w-32 text-right">Rules</th>
                </tr>
              </thead>
              <tbody>
                {datasets.map((d) => (
                  <tr key={d.name}>
                    <td className="font-mono text-[13px] text-ink">{d.name}</td>
                    <td>
                      <div className="flex gap-1">
                        {Array.from(d.layers).map((l) => (
                          <span key={l}
                                className="text-[10px] uppercase tracking-wider font-semibold
                                           text-graphite-muted bg-surface-soft px-1.5 py-0.5
                                           rounded border border-surface-border">
                            {l.replace("_", " ")}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="text-right tabular-nums font-semibold">{d.ruleCount}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}
