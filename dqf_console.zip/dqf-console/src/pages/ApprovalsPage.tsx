import { useEffect, useState } from "react";
import { ClipboardCheck, Check, X } from "lucide-react";
import { useProject } from "../lib/projectContext";
import { approveRule, listRules, rejectRule } from "../api/mockClient";
import type { Rule } from "../types";
import { PageHeader } from "../components/PageHeader";
import { EmptyState } from "../components/EmptyState";
import { severityClass } from "../lib/format";

export function ApprovalsPage() {
  const { current } = useProject();
  const [rules, setRules] = useState<Rule[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!current) return;
    setLoading(true);
    let cancelled = false;
    listRules(current.project_id).then((rs) => {
      if (cancelled) return;
      setRules(rs.filter((r) =>
        r.status === "PENDING_APPROVAL" || r.status === "DRAFT",
      ));
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [current]);

  async function onApprove(rule: Rule) {
    if (!current) return;
    await approveRule(current.project_id, rule.rule_id);
    setRules((rs) => rs.filter((r) => r.rule_id !== rule.rule_id));
  }
  async function onReject(rule: Rule) {
    if (!current) return;
    const reason = prompt(`Reject ${rule.rule_id}? Reason:`) ?? "";
    if (!reason) return;
    await rejectRule(current.project_id, rule.rule_id, reason);
    setRules((rs) => rs.filter((r) => r.rule_id !== rule.rule_id));
  }

  if (!current) return null;

  return (
    <>
      <PageHeader
        eyebrow={`PROJECT · ${current.project_code}`}
        title="Approvals queue"
        subtitle="Rules submitted by authors awaiting reviewer + owner sign-off."
      />

      <div className="px-8 py-6 max-w-[1400px]">
        <div className="card overflow-hidden">
          {loading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading approvals…</div>
          ) : rules.length === 0 ? (
            <EmptyState
              icon={ClipboardCheck}
              title="Inbox zero"
              description="No rules are waiting for approval right now."
            />
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th className="w-28">Rule</th>
                  <th>Name</th>
                  <th className="w-32">Layer</th>
                  <th className="w-24">Severity</th>
                  <th className="w-44">Owner</th>
                  <th className="w-44 text-right">Action</th>
                </tr>
              </thead>
              <tbody>
                {rules.map((r) => (
                  <tr key={r.rule_id}>
                    <td className="font-mono text-[12px] text-teal-deep">{r.rule_id}</td>
                    <td>
                      <div className="font-medium text-ink">{r.name}</div>
                      <div className="text-[11px] text-graphite-muted font-mono mt-0.5">
                        {r.datasets.join(", ")}
                      </div>
                    </td>
                    <td className="text-graphite-muted text-[12px]">{r.layer}</td>
                    <td className={severityClass(r.severity)}>{r.severity}</td>
                    <td className="text-graphite text-[13px]">{r.owner}</td>
                    <td className="text-right">
                      <div className="inline-flex gap-2">
                        <button className="btn btn-primary" onClick={() => onApprove(r)}>
                          <Check size={14}/> Approve
                        </button>
                        <button className="btn btn-ghost" onClick={() => onReject(r)}>
                          <X size={14}/> Reject
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}
