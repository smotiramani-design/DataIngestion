import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis,
  ResponsiveContainer, Tooltip, CartesianGrid,
} from "recharts";
import {
  CheckCircle2, AlertTriangle, ListChecks, PlayCircle, ArrowRight,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useProject } from "../lib/projectContext";
import { listRuns, listRules, listErrors } from "../api/mockClient";
import type { Rule, ValidationError, ValidationRun } from "../types";
import { PageHeader } from "../components/PageHeader";
import { StatusPill } from "../components/StatusPill";
import { fmtNumber, fmtRelative } from "../lib/format";

export function DashboardPage() {
  const { current } = useProject();
  const [runs, setRuns] = useState<ValidationRun[]>([]);
  const [rules, setRules] = useState<Rule[]>([]);
  const [errors, setErrors] = useState<ValidationError[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!current) return;
    let cancelled = false;
    setLoading(true);
    Promise.all([
      listRuns(current.project_id),
      listRules(current.project_id),
      listErrors(current.project_id),
    ]).then(([rs, rl, er]) => {
      if (cancelled) return;
      setRuns(rs); setRules(rl); setErrors(er); setLoading(false);
    });
    return () => { cancelled = true; };
  }, [current]);

  if (!current) return null;

  // KPIs
  const activeRules = rules.filter((r) => r.enabled && r.status === "APPROVED").length;
  const totalRuns = runs.length;
  const passRate = totalRuns > 0
    ? (runs.filter((r) => r.status === "PASS").length / totalRuns) * 100 : 0;
  const blockingErrors = errors.filter((e) => e.severity === "BLOCK").length;

  // Synthetic 14-day trend pulled from runs (just spread the few runs we have)
  const trendData = Array.from({ length: 14 }, (_, i) => {
    const day = 13 - i;
    const noise = Math.sin(i * 0.7) * 0.6;
    return {
      day: day === 0 ? "Today" : `D-${day}`,
      pass: Math.max(95, 98 + noise + (i === 9 ? -2 : 0)),
    };
  });

  // Failures by layer
  const layerCounts: Record<string, number> = { FILE: 0, BUSINESS_RULE: 0, POST_TRANSFORM: 0 };
  errors.forEach((e) => {
    const r = rules.find((x) => x.rule_id === e.rule_id);
    if (r) layerCounts[r.layer] = (layerCounts[r.layer] ?? 0) + 1;
  });
  const layerData = [
    { layer: "File",        count: layerCounts.FILE },
    { layer: "Business",    count: layerCounts.BUSINESS_RULE },
    { layer: "Post-Tx",     count: layerCounts.POST_TRANSFORM },
  ];

  return (
    <>
      <PageHeader
        eyebrow="DASHBOARD"
        title={current.project_name}
        subtitle={`${current.project_code} · catalog: ${current.default_catalog}`}
      />

      <div className="px-8 py-6 max-w-[1400px]">
        {/* KPI cards */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          <KpiCard
            label="Pass rate (24h)"
            value={`${passRate.toFixed(1)}%`}
            color="success"
            icon={CheckCircle2}
          />
          <KpiCard
            label="Runs (24h)"
            value={fmtNumber(totalRuns)}
            color="navy"
            icon={PlayCircle}
          />
          <KpiCard
            label="Active rules"
            value={fmtNumber(activeRules)}
            color="teal"
            icon={ListChecks}
          />
          <KpiCard
            label="Open errors (BLOCK)"
            value={fmtNumber(blockingErrors)}
            color="danger"
            icon={AlertTriangle}
          />
        </div>

        {/* Charts row */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="card col-span-2">
            <div className="card-header">
              <h2 className="text-base font-semibold text-ink">Pass rate — last 14 days</h2>
              <span className="text-xs text-graphite-muted">% of runs marked PASS</span>
            </div>
            <div className="px-4 py-4 h-[260px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trendData} margin={{ top: 6, right: 12, left: 0, bottom: 4 }}>
                  <defs>
                    <linearGradient id="passGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%"  stopColor="#00A6A6" stopOpacity={0.3} />
                      <stop offset="100%" stopColor="#00A6A6" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke="#D6E1EE" vertical={false} />
                  <XAxis dataKey="day" stroke="#64748B" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis domain={[94, 100]} stroke="#64748B" fontSize={11} tickLine={false}
                         axisLine={false} width={32} unit="%" />
                  <Tooltip
                    contentStyle={{ borderRadius: 6, fontSize: 12, border: "1px solid #D6E1EE" }}
                    labelStyle={{ color: "#0B2545", fontWeight: 600 }}
                    formatter={(v: number) => [`${v.toFixed(2)}%`, "Pass rate"]}
                  />
                  <Area type="monotone" dataKey="pass" stroke="#00A6A6"
                        strokeWidth={2.5} fill="url(#passGrad)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="card">
            <div className="card-header">
              <h2 className="text-base font-semibold text-ink">Failures by layer</h2>
              <span className="text-xs text-graphite-muted">24h</span>
            </div>
            <div className="px-4 py-4 h-[260px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={layerData} margin={{ top: 8, right: 12, left: 0, bottom: 4 }}>
                  <CartesianGrid stroke="#D6E1EE" vertical={false} />
                  <XAxis dataKey="layer" stroke="#64748B" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis stroke="#64748B" fontSize={11} tickLine={false} axisLine={false} width={28} />
                  <Tooltip
                    contentStyle={{ borderRadius: 6, fontSize: 12, border: "1px solid #D6E1EE" }}
                    labelStyle={{ color: "#0B2545", fontWeight: 600 }}
                  />
                  <Bar dataKey="count" fill="#1C7293" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Recent runs */}
        <div className="card">
          <div className="card-header">
            <h2 className="text-base font-semibold text-ink">Recent runs</h2>
            <Link to="/runs" className="text-sm text-teal-deep font-medium flex items-center gap-1
                                       hover:gap-1.5 transition-all">
              View all <ArrowRight size={14} />
            </Link>
          </div>
          {loading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading…</div>
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Run</th>
                  <th>Trigger</th>
                  <th>Started</th>
                  <th>Status</th>
                  <th className="text-right">Failed / Evaluated</th>
                  <th className="text-right">Records</th>
                </tr>
              </thead>
              <tbody>
                {runs.slice(0, 5).map((r) => (
                  <tr key={r.run_id}>
                    <td className="font-mono text-[12px] text-teal-deep">{r.run_id}</td>
                    <td className="text-graphite-muted">{r.trigger_type}</td>
                    <td className="text-graphite-muted">{fmtRelative(r.started_ts)}</td>
                    <td><StatusPill status={r.status} /></td>
                    <td className="text-right">
                      <span className={r.rules_failed > 0 ? "text-danger font-semibold" : ""}>
                        {r.rules_failed}
                      </span>
                      <span className="text-graphite-muted"> / {r.rules_evaluated}</span>
                    </td>
                    <td className="text-right text-graphite">{fmtNumber(r.records_checked)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}

// ------------------------------------------------------------------
// KPI card — small inline component
// ------------------------------------------------------------------

interface KpiProps {
  label: string;
  value: string;
  color: "success" | "danger" | "navy" | "teal";
  icon: LucideIcon;
}

function KpiCard({ label, value, color, icon: Icon }: KpiProps) {
  const stripe = {
    success: "bg-success",
    danger:  "bg-danger",
    navy:    "bg-navy-deep",
    teal:    "bg-teal",
  }[color];
  const iconColor = {
    success: "text-success",
    danger:  "text-danger",
    navy:    "text-navy-deep",
    teal:    "text-teal",
  }[color];
  return (
    <div className="card relative overflow-hidden">
      <div className={`absolute left-0 top-0 bottom-0 w-1 ${stripe}`} />
      <div className="px-5 pt-4 pb-3 flex items-start justify-between">
        <div>
          <div className="text-[11px] uppercase tracking-wider text-graphite-muted font-semibold">
            {label}
          </div>
          <div className="text-[32px] leading-none font-bold text-ink mt-2 tabular-nums">{value}</div>
        </div>
        <Icon size={18} className={`${iconColor} mt-1`} />
      </div>
    </div>
  );
}
