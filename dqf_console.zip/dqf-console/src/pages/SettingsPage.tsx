import { useEffect, useState } from "react";
import { useProject } from "../lib/projectContext";
import { getProjectSettings } from "../api/mockClient";
import type { DqProjectSettings } from "../types";
import { PageHeader } from "../components/PageHeader";

export function SettingsPage() {
  const { current } = useProject();
  const [settings, setSettings] = useState<DqProjectSettings | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!current) return;
    setLoading(true);
    let cancelled = false;
    getProjectSettings(current.project_id).then((s) => {
      if (cancelled) return;
      setSettings(s ?? null);
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [current]);

  if (!current) return null;

  return (
    <>
      <PageHeader
        eyebrow={`PROJECT · ${current.project_code}`}
        title="Settings"
        subtitle="Per-project DQ settings stored in dq_project_settings. Project metadata is owned by the Ingestion Framework."
      />

      <div className="px-8 py-6 max-w-[1400px] space-y-4">
        {/* Project (read-only — owned by Ingestion FW) */}
        <div className="card">
          <div className="card-header">
            <h2 className="text-base font-semibold text-ink">Project (from Ingestion FW)</h2>
            <span className="text-[11px] uppercase tracking-wider text-warn font-semibold
                             bg-warn-soft px-2 py-0.5 rounded border border-warn/30">
              External · read-only
            </span>
          </div>
          <table className="data-table">
            <tbody>
              <Row label="project_id"      value={String(current.project_id)} mono />
              <Row label="project_code"    value={current.project_code} mono bold />
              <Row label="project_name"    value={current.project_name} />
              <Row label="default_catalog" value={current.default_catalog} mono />
              <Row label="alert_email"     value={current.alert_email} />
              <Row label="owner_team"      value={current.owner_team} />
              <Row label="cost_center"     value={current.cost_center ?? "—"} />
            </tbody>
          </table>
        </div>

        {/* DQ settings (DQ FW owned) */}
        <div className="card">
          <div className="card-header">
            <h2 className="text-base font-semibold text-ink">DQ settings</h2>
            <span className="text-[11px] uppercase tracking-wider text-success font-semibold
                             bg-success-soft px-2 py-0.5 rounded border border-success/20">
              DQ FW · owned
            </span>
          </div>
          {loading ? (
            <div className="p-6 text-sm text-graphite-muted">Loading…</div>
          ) : !settings ? (
            <div className="p-6 text-sm text-graphite-muted">No DQ settings configured for this project.</div>
          ) : (
            <table className="data-table">
              <tbody>
                <Row label="dq_framework_version"   value={settings.dq_framework_version} mono bold />
                <Row label="is_dq_enabled"          value={String(settings.is_dq_enabled)} mono />
                <Row label="block_publish_on_fail"  value={String(settings.block_publish_on_fail)} mono />
                <Row label="notification_channel"   value={settings.notification_channel ?? "(uses project default)"} />
                <Row label="pagerduty_service"      value={settings.pagerduty_service ?? "(uses project default)"} />
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}

interface RowProps { label: string; value: string; mono?: boolean; bold?: boolean }

function Row({ label, value, mono, bold }: RowProps) {
  return (
    <tr>
      <td className="font-mono text-[12px] text-graphite-muted w-56">{label}</td>
      <td className={`${mono ? "font-mono text-[13px]" : ""} ${bold ? "font-semibold text-ink" : "text-graphite"}`}>
        {value}
      </td>
    </tr>
  );
}
