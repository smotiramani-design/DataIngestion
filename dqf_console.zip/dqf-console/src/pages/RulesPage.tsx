import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Search, Plus, ListChecks } from "lucide-react";
import { useProject } from "../lib/projectContext";
import { listRules } from "../api/mockClient";
import type { Rule, RuleStatus } from "../types";
import { PageHeader } from "../components/PageHeader";
import { StatusPill } from "../components/StatusPill";
import { EmptyState } from "../components/EmptyState";
import { severityClass } from "../lib/format";

type Tab = "all" | "pending" | "approved" | "disabled";

export function RulesPage() {
  const { current } = useProject();
  const [rules, setRules] = useState<Rule[]>([]);
  const [tab, setTab] = useState<Tab>("all");
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!current) return;
    setLoading(true);
    let cancelled = false;
    listRules(current.project_id).then((rs) => {
      if (cancelled) return;
      setRules(rs);
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [current]);

  // Counts for tabs
  const counts = useMemo(() => ({
    all:      rules.length,
    pending:  rules.filter((r) => r.status === "PENDING_APPROVAL" || r.status === "DRAFT").length,
    approved: rules.filter((r) => r.status === "APPROVED").length,
    disabled: rules.filter((r) => !r.enabled || r.status === "RETIRED").length,
  }), [rules]);

  const filtered = useMemo(() => {
    let list = rules;
    if (tab === "pending")  list = list.filter((r) => r.status === "PENDING_APPROVAL" || r.status === "DRAFT");
    if (tab === "approved") list = list.filter((r) => r.status === "APPROVED" && r.enabled);
    if (tab === "disabled") list = list.filter((r) => !r.enabled || r.status === "RETIRED");

    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter((r) =>
        r.rule_id.toLowerCase().includes(q) ||
        r.name.toLowerCase().includes(q) ||
        r.owner.toLowerCase().includes(q) ||
        r.datasets.some((d) => d.toLowerCase().includes(q)),
      );
    }
    return list;
  }, [rules, tab, query]);

  if (!current) return null;

  return (
    <>
      <PageHeader
        eyebrow={`PROJECT · ${current.project_code}`}
        title="Rules Catalog"
        subtitle="Approved rules execute on every validation run for this project."
        actions={
          <button className="btn btn-primary">
            <Plus size={16} /> New rule
          </button>
        }
      />

      <div className="px-8 py-6 max-w-[1400px]">
        {/* Tabs + search */}
        <div className="flex items-center justify-between gap-4 mb-4">
          <div className="flex gap-1.5">
            <Tab label="All"      count={counts.all}      active={tab === "all"}      onClick={() => setTab("all")} />
            <Tab label="Pending"  count={counts.pending}  active={tab === "pending"}  onClick={() => setTab("pending")}
                 status="warn" />
            <Tab label="Approved" count={counts.approved} active={tab === "approved"} onClick={() => setTab("approved")}
                 status="success" />
            <Tab label="Disabled" count={counts.disabled} active={tab === "disabled"} onClick={() => setTab("disabled")} />
          </div>

          <div className="relative w-80">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-graphite-muted" />
            <input
              type="text"
              placeholder="Search by rule_id, name, dataset, owner…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="field-input pl-9"
            />
          </div>
        </div>

        {/* Rules table */}
        <div className="card overflow-hidden">
          {loading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading rules…</div>
          ) : filtered.length === 0 ? (
            <EmptyState icon={ListChecks} title="No rules match"
                        description="Try changing the filter or search." />
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th className="w-32">Rule ID</th>
                  <th>Name</th>
                  <th className="w-32">Layer</th>
                  <th className="w-24">Severity</th>
                  <th className="w-44">Owner</th>
                  <th className="w-32 text-center">Version</th>
                  <th className="w-36">Status</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((r) => (
                  <tr key={r.rule_id} className="cursor-pointer">
                    <td>
                      <Link to={`/rules/${r.rule_id}`}
                            className="font-mono text-[12px] font-bold text-teal-deep hover:underline">
                        {r.rule_id}
                      </Link>
                    </td>
                    <td className="font-medium text-ink">
                      <Link to={`/rules/${r.rule_id}`} className="hover:underline">
                        {r.name}
                      </Link>
                      <div className="text-[11px] text-graphite-muted font-mono mt-0.5">
                        {r.datasets.join(", ")}
                      </div>
                    </td>
                    <td className="text-graphite-muted text-[12px]">
                      {layerLabel(r.layer)}
                    </td>
                    <td className={severityClass(r.severity)}>{r.severity}</td>
                    <td className="text-graphite text-[13px]">{r.owner}</td>
                    <td className="text-center text-graphite tabular-nums">v{r.version}</td>
                    <td><StatusPill status={r.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}

function layerLabel(l: string): string {
  return l === "BUSINESS_RULE" ? "Business" : l === "POST_TRANSFORM" ? "Post-tx" : "File";
}

interface TabProps {
  label: string;
  count: number;
  active: boolean;
  status?: "success" | "warn";
  onClick: () => void;
}

function Tab({ label, count, active, status, onClick }: TabProps) {
  const countColor = status === "warn" ? "text-warn" : status === "success" ? "text-success" : "text-graphite-muted";
  return (
    <button
      onClick={onClick}
      className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center gap-2
                  ${active
                    ? "bg-navy-deep text-white"
                    : "bg-white border border-surface-border text-graphite hover:border-teal/50"}`}
    >
      <span>{label}</span>
      <span className={`text-xs font-semibold tabular-nums
                        ${active ? "text-white/80" : countColor}`}>
        {count}
      </span>
    </button>
  );
}
