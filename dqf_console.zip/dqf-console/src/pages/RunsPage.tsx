import { useEffect, useState } from "react";
import { History } from "lucide-react";
import { useProject } from "../lib/projectContext";
import { listRuns } from "../api/mockClient";
import type { ValidationRun } from "../types";
import { PageHeader } from "../components/PageHeader";
import { StatusPill } from "../components/StatusPill";
import { EmptyState } from "../components/EmptyState";
import { fmtNumber, fmtRelative } from "../lib/format";

export function RunsPage() {
  const { current } = useProject();
  const [runs, setRuns] = useState<ValidationRun[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!current) return;
    setLoading(true);
    let cancelled = false;
    listRuns(current.project_id, 100).then((rs) => {
      if (cancelled) return;
      setRuns(rs);
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [current]);

  if (!current) return null;

  return (
    <>
      <PageHeader
        eyebrow={`PROJECT · ${current.project_code}`}
        title="Validation runs"
        subtitle="Every execution of the engine for this project, ordered most-recent first."
      />
      <div className="px-8 py-6 max-w-[1400px]">
        <div className="card overflow-hidden">
          {loading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading runs…</div>
          ) : runs.length === 0 ? (
            <EmptyState icon={History} title="No runs yet"
                        description="Trigger a run from ADF or the API." />
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Run</th>
                  <th>Trigger</th>
                  <th>ADF Run ID</th>
                  <th>Started</th>
                  <th>Status</th>
                  <th className="text-right">Pass / Warn / Fail</th>
                  <th className="text-right">Records</th>
                  <th>Framework</th>
                </tr>
              </thead>
              <tbody>
                {runs.map((r) => (
                  <tr key={r.run_id}>
                    <td className="font-mono text-[12px] text-teal-deep">{r.run_id}</td>
                    <td className="text-graphite-muted text-[12px]">{r.trigger_type}</td>
                    <td className="font-mono text-[11px] text-graphite-muted">{r.trigger_ref ?? "—"}</td>
                    <td className="text-graphite-muted">{fmtRelative(r.started_ts)}</td>
                    <td><StatusPill status={r.status} /></td>
                    <td className="text-right tabular-nums">
                      <span className="text-success">{r.rules_passed}</span>
                      <span className="text-graphite-muted"> · </span>
                      <span className="text-warn">{r.rules_warned}</span>
                      <span className="text-graphite-muted"> · </span>
                      <span className={r.rules_failed > 0 ? "text-danger font-semibold" : "text-graphite-muted"}>
                        {r.rules_failed}
                      </span>
                    </td>
                    <td className="text-right">{fmtNumber(r.records_checked)}</td>
                    <td className="font-mono text-[11px] text-graphite-muted">v{r.framework_version}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}
