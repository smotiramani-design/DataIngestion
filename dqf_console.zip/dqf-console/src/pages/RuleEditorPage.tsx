import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { ArrowLeft, CheckCircle2, Save, Send, FlaskConical, AlertTriangle } from "lucide-react";
import { useProject } from "../lib/projectContext";
import { getRule } from "../api/mockClient";
import type { Rule } from "../types";
import { PageHeader } from "../components/PageHeader";
import { StatusPill } from "../components/StatusPill";
import { severityClass } from "../lib/format";

type DryRunResult =
  | { status: "idle" }
  | { status: "running" }
  | { status: "pass"; records: number; failures: number; pct: number }
  | { status: "fail"; message: string };

export function RuleEditorPage() {
  const { current } = useProject();
  const { ruleId } = useParams<{ ruleId: string }>();
  const navigate = useNavigate();

  const [rule, setRule] = useState<Rule | null>(null);
  const [loading, setLoading] = useState(true);
  const [dryRun, setDryRun] = useState<DryRunResult>({ status: "idle" });

  useEffect(() => {
    if (!current || !ruleId) return;
    setLoading(true);
    let cancelled = false;
    getRule(current.project_id, ruleId).then((r) => {
      if (cancelled) return;
      setRule(r ?? null);
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [current, ruleId]);

  if (!current) return null;
  if (loading) {
    return <div className="p-8 text-sm text-graphite-muted">Loading rule…</div>;
  }
  if (!rule) {
    return (
      <div className="p-8">
        <Link to="/rules" className="btn btn-ghost"><ArrowLeft size={16}/> Back to rules</Link>
        <div className="card mt-4 p-8 text-center text-graphite-muted">Rule not found.</div>
      </div>
    );
  }

  function runDryRun() {
    setDryRun({ status: "running" });
    setTimeout(() => {
      // Synthetic but believable result
      const records = 1_240_113;
      const failures = Math.floor(Math.random() * 30) + 5;
      const pct = (failures / records) * 100;
      setDryRun({ status: "pass", records, failures, pct });
    }, 900);
  }

  return (
    <>
      <PageHeader
        eyebrow={`PROJECT · ${current.project_code}`}
        title="Edit rule"
        subtitle="Author the rule, dry-run it against current data, then submit for approval."
        actions={
          <>
            <Link to="/rules" className="btn btn-ghost"><ArrowLeft size={14}/> Back</Link>
            <button className="btn btn-ghost" onClick={runDryRun} disabled={dryRun.status === "running"}>
              <FlaskConical size={14}/> {dryRun.status === "running" ? "Running…" : "Dry-run"}
            </button>
            <button className="btn btn-ghost"><Save size={14}/> Save draft</button>
            <button className="btn btn-primary" onClick={() => navigate("/approvals")}>
              <Send size={14}/> Submit for approval
            </button>
          </>
        }
      />

      <div className="px-8 py-6 max-w-[1400px]">
        {/* Rule meta strip */}
        <div className="card mb-4">
          <div className="px-5 py-4 flex items-center gap-4">
            <div className="font-mono text-lg font-bold text-teal-deep">{rule.rule_id}</div>
            <span className="text-graphite-muted">·</span>
            <div className="text-sm text-graphite tabular-nums">version {rule.version}</div>
            <span className="text-graphite-muted">·</span>
            <StatusPill status={rule.status} />
            <div className={`text-xs uppercase tracking-wider ${severityClass(rule.severity)}`}>
              {rule.severity}
            </div>
          </div>
        </div>

        {/* Two-column form */}
        <div className="grid grid-cols-2 gap-4">
          {/* Left: form fields */}
          <div className="card">
            <div className="card-header">
              <h2 className="text-base font-semibold text-ink">Definition</h2>
            </div>
            <div className="px-5 py-5 space-y-4">
              <Field label="Name" value={rule.name} />
              <Field label="Description" value={rule.description ?? ""} />
              <div className="grid grid-cols-2 gap-3">
                <Field label="Layer"      value={rule.layer} mono />
                <Field label="Check type" value={rule.check_type} mono />
              </div>
              <Field label="Datasets" value={rule.datasets.join(", ")} mono />
              <div className="grid grid-cols-2 gap-3">
                <Field label="Severity" value={rule.severity} mono />
                <Field label="Owner"    value={rule.owner} />
              </div>
              <Field label="Tolerance %" value={rule.params.tolerance_pct ?? "—"} />
              <Field label="Effective from" value={rule.created_ts?.slice(0, 10) ?? "—"} />
            </div>
          </div>

          {/* Right: expression */}
          <div>
            <div className="card overflow-hidden">
              <div className="bg-surface-soft border-b border-surface-border px-4 py-2.5">
                <div className="text-[11px] uppercase tracking-wide font-semibold text-graphite-muted">
                  Expression · SQL / DSL
                </div>
              </div>
              <pre className="bg-navy-deep text-[#CADCFC] font-mono text-[12.5px] leading-relaxed
                              p-4 m-0 overflow-x-auto min-h-[260px]">
{rule.expression
  ? `-- Free-form expression\n${rule.expression}`
  : ruleAsConfig(rule)}
              </pre>
            </div>

            {/* Params card */}
            <div className="card mt-4">
              <div className="card-header"><h3 className="text-sm font-semibold text-ink">Parameters</h3></div>
              <table className="data-table">
                <tbody>
                  {Object.entries(rule.params).map(([k, v]) => (
                    <tr key={k}>
                      <td className="font-mono text-[12px] text-graphite-muted w-44">{k}</td>
                      <td className="font-mono text-[12px] text-ink">{v}</td>
                    </tr>
                  ))}
                  {Object.keys(rule.params).length === 0 && (
                    <tr><td colSpan={2} className="text-graphite-muted">No parameters.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Dry-run result strip */}
        {dryRun.status === "pass" && (
          <div className="mt-4 border border-success/30 bg-success-soft rounded-lg
                          px-5 py-3.5 flex items-center gap-3 fade-up">
            <CheckCircle2 size={18} className="text-success flex-shrink-0" />
            <div className="text-sm text-success">
              <strong>Dry-run passed.</strong>{" "}
              <span className="text-success/90">
                Evaluated {dryRun.records.toLocaleString()} records, {dryRun.failures} failures
                ({dryRun.pct.toFixed(4)}%) — under tolerance for {rule.severity}.
              </span>
            </div>
          </div>
        )}
        {dryRun.status === "fail" && (
          <div className="mt-4 border border-danger/30 bg-danger-soft rounded-lg
                          px-5 py-3.5 flex items-center gap-3 fade-up">
            <AlertTriangle size={18} className="text-danger flex-shrink-0" />
            <div className="text-sm text-danger">
              <strong>Dry-run failed.</strong> {dryRun.message}
            </div>
          </div>
        )}
      </div>
    </>
  );
}

interface FieldProps {
  label: string;
  value: string;
  mono?: boolean;
}

function Field({ label, value, mono }: FieldProps) {
  return (
    <div>
      <div className="field-label">{label}</div>
      <div className={`field-input ${mono ? "field-mono" : ""}`}>{value || "—"}</div>
    </div>
  );
}

function ruleAsConfig(r: Rule): string {
  return JSON.stringify(
    {
      rule_id: r.rule_id,
      version: r.version,
      name: r.name,
      layer: r.layer,
      check_type: r.check_type,
      severity: r.severity,
      datasets: r.datasets,
      params: r.params,
      owner: r.owner,
      status: r.status,
    },
    null, 2,
  );
}
