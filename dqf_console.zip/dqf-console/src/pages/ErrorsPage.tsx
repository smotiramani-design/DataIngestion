import { useEffect, useState } from "react";
import { AlertTriangle } from "lucide-react";
import { useProject } from "../lib/projectContext";
import { listErrors } from "../api/mockClient";
import type { ValidationError } from "../types";
import { PageHeader } from "../components/PageHeader";
import { EmptyState } from "../components/EmptyState";
import { severityClass, fmtRelative } from "../lib/format";

export function ErrorsPage() {
  const { current } = useProject();
  const [errors, setErrors] = useState<ValidationError[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!current) return;
    setLoading(true);
    let cancelled = false;
    listErrors(current.project_id).then((es) => {
      if (cancelled) return;
      setErrors(es);
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [current]);

  if (!current) return null;

  return (
    <>
      <PageHeader
        eyebrow={`PROJECT · ${current.project_code}`}
        title="Validation errors"
        subtitle="Failed records captured during runs, with full lineage to rule + run."
      />

      <div className="px-8 py-6 max-w-[1400px]">
        <div className="card overflow-hidden">
          {loading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading errors…</div>
          ) : errors.length === 0 ? (
            <EmptyState icon={AlertTriangle} title="No errors"
                        description="No validation failures captured yet." />
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th className="w-28">Rule</th>
                  <th className="w-24">Severity</th>
                  <th>Dataset</th>
                  <th className="w-20">PK</th>
                  <th>Expected → Actual</th>
                  <th className="w-32">Run</th>
                  <th className="w-32">Captured</th>
                </tr>
              </thead>
              <tbody>
                {errors.map((e) => (
                  <tr key={e.error_id}>
                    <td className="font-mono text-[12px] text-teal-deep">{e.rule_id}</td>
                    <td className={severityClass(e.severity)}>{e.severity}</td>
                    <td className="font-mono text-[12px] text-graphite">{e.dataset}</td>
                    <td className="font-mono text-[12px] text-graphite">{e.record_pk ?? "—"}</td>
                    <td className="text-[12px]">
                      <div className="text-graphite-muted">{e.expected ?? "—"}</div>
                      <div className="text-danger mt-0.5">{e.actual ?? "—"}</div>
                    </td>
                    <td className="font-mono text-[11px] text-graphite-muted">{e.run_id}</td>
                    <td className="text-graphite-muted">{fmtRelative(e.captured_ts)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}
