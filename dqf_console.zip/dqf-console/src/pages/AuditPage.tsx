import { useEffect, useState } from "react";
import { FileSearch } from "lucide-react";
import { useProject } from "../lib/projectContext";
import { listAudit } from "../api/mockClient";
import type { AuditEntry } from "../types";
import { PageHeader } from "../components/PageHeader";
import { EmptyState } from "../components/EmptyState";
import { fmtRelative } from "../lib/format";

export function AuditPage() {
  const { current } = useProject();
  const [entries, setEntries] = useState<AuditEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!current) return;
    setLoading(true);
    let cancelled = false;
    listAudit(current.project_id).then((es) => {
      if (cancelled) return;
      setEntries(es);
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [current]);

  if (!current) return null;

  return (
    <>
      <PageHeader
        eyebrow={`PROJECT · ${current.project_code}`}
        title="Audit log"
        subtitle="Every config change and run trigger, with actor + role + framework version."
      />

      <div className="px-8 py-6 max-w-[1400px]">
        <div className="card overflow-hidden">
          {loading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading audit log…</div>
          ) : entries.length === 0 ? (
            <EmptyState icon={FileSearch} title="No audit entries" />
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th className="w-32">Action</th>
                  <th className="w-32">Actor</th>
                  <th className="w-24">Role</th>
                  <th className="w-32">Entity</th>
                  <th className="w-32">Entity ID</th>
                  <th>Reason</th>
                  <th className="w-32">Framework</th>
                  <th className="w-28">When</th>
                </tr>
              </thead>
              <tbody>
                {entries.map((e) => (
                  <tr key={e.audit_id}>
                    <td className="font-medium text-ink text-[13px]">{e.action.replace(/_/g, " ")}</td>
                    <td className="text-graphite text-[13px]">{e.actor}</td>
                    <td>
                      <span className="text-[11px] uppercase tracking-wider font-semibold text-graphite-muted
                                       bg-surface-soft px-1.5 py-0.5 rounded">
                        {e.role}
                      </span>
                    </td>
                    <td className="text-graphite-muted text-[12px]">{e.entity_type}</td>
                    <td className="font-mono text-[12px] text-teal-deep">{e.entity_id}</td>
                    <td className="text-graphite text-[12px]">{e.reason ?? "—"}</td>
                    <td className="font-mono text-[11px] text-graphite-muted">
                      {e.framework_version ? `v${e.framework_version}` : "—"}
                    </td>
                    <td className="text-graphite-muted">{fmtRelative(e.event_ts)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}
