/**
 * Mock API client.
 *
 * In production this module would issue fetch() calls to the FastAPI backend.
 * For the prototype, we return seeded data with simulated latency so the UI
 * is fully interactive against realistic data — no backend required.
 *
 * Replace each function with a real fetch() call when wiring to FastAPI.
 * Function signatures match the eventual REST contract.
 */
import type {
  AuditEntry,
  DqProjectSettings,
  Project,
  ProjectHealth,
  Rule,
  RuleVersion,
  ValidationError,
  ValidationRun,
} from "../types";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------------------
// Seed data — three projects, distributed rules, runs, errors
// ---------------------------------------------------------------------------

const PROJECTS: Project[] = [
  {
    project_id: 1, project_code: "finance",   project_name: "Finance Data Platform",
    default_catalog: "finance_data",   bronze_schema: "bronze", silver_schema: "silver", gold_schema: "gold",
    alert_email: "finance-data-eng@example.com", owner_team: "finance-data-eng",
    is_active: true,  cost_center: "CC-1001",
    description: "GL, AP/AR, treasury, and forecasting feeds.",
  },
  {
    project_id: 2, project_code: "marketing", project_name: "Marketing Analytics",
    default_catalog: "marketing_data", bronze_schema: "bronze", silver_schema: "silver", gold_schema: "gold",
    alert_email: "mktg-analytics@example.com",   owner_team: "marketing-analytics",
    is_active: true,  cost_center: "CC-2003",
    description: "Customer engagement, campaign attribution, CDP feeds.",
  },
  {
    project_id: 3, project_code: "operations", project_name: "Operations Data",
    default_catalog: "ops_data",       bronze_schema: "bronze", silver_schema: "silver", gold_schema: "gold",
    alert_email: "ops-data@example.com",         owner_team: "ops-data-eng",
    is_active: true,  cost_center: "CC-3007",
    description: "Supply chain, mainframe ledgers, operational reporting.",
  },
];

const SETTINGS: DqProjectSettings[] = [
  { project_id: 1, dq_framework_version: "0.1.0", is_dq_enabled: true, block_publish_on_fail: true,
    notification_channel: "#finance-data-alerts", pagerduty_service: "finance-data-platform" },
  { project_id: 2, dq_framework_version: "0.1.0", is_dq_enabled: true, block_publish_on_fail: false,
    notification_channel: "#mktg-analytics" },
  { project_id: 3, dq_framework_version: "0.1.0", is_dq_enabled: true, block_publish_on_fail: true,
    pagerduty_service: "ops-data-platform" },
];

const RULES: Rule[] = [
  // finance
  { project_id: 1, project_code: "finance", rule_id: "FL_0001", version: 1,
    name: "raw orders schema match", layer: "FILE", check_type: "SCHEMA", severity: "BLOCK",
    datasets: ["finance_data.bronze.orders"],
    params: { expected_schema: "order_id:long,customer_id:long,order_ts:timestamp,amount:decimal(18,2),currency:string,status:string" },
    owner: "finance-data-eng@example.com", status: "APPROVED", enabled: true,
    description: "Incoming orders.csv must contain expected columns in expected types.",
    created_by: "akhil", created_ts: "2026-04-12T10:14:00Z" },
  { project_id: 1, project_code: "finance", rule_id: "FL_0002", version: 1,
    name: "raw orders row count > 0", layer: "FILE", check_type: "ROW_COUNT_MIN", severity: "BLOCK",
    datasets: ["finance_data.bronze.orders"], params: { min_rows: "1" },
    owner: "finance-data-eng@example.com", status: "APPROVED", enabled: true,
    description: "Reject empty files.", created_by: "akhil", created_ts: "2026-04-12T10:15:00Z" },
  { project_id: 1, project_code: "finance", rule_id: "FL_0003", version: 2,
    name: "raw orders amount null pct < 1%", layer: "FILE", check_type: "NULL_PCT_MAX", severity: "WARN",
    datasets: ["finance_data.bronze.orders"], params: { column: "amount", max_null_pct: "1.0" },
    owner: "finance-data-eng@example.com", status: "APPROVED", enabled: true,
    description: "Null rate on amount must be under 1%.", created_by: "akhil", created_ts: "2026-04-15T08:30:00Z" },
  { project_id: 1, project_code: "finance", rule_id: "BR_0142", version: 4,
    name: "orders.customer_id exists in customers", layer: "BUSINESS_RULE",
    check_type: "REFERENTIAL_INTEGRITY", severity: "BLOCK",
    datasets: ["finance_data.silver.orders", "finance_data.silver.customers"],
    params: { left_table: "finance_data.silver.orders", left_keys: "customer_id",
              right_table: "finance_data.silver.customers", right_keys: "customer_id",
              tolerance_pct: "0.0", max_sample_rows: "100" },
    owner: "finance-data-eng@example.com", status: "APPROVED", enabled: true,
    description: "Every order must reference a customer that exists.",
    created_by: "data-quality", created_ts: "2026-03-28T14:02:00Z" },
  { project_id: 1, project_code: "finance", rule_id: "BR_0205", version: 1,
    name: "orders.amount within plausible range", layer: "BUSINESS_RULE",
    check_type: "EXPRESSION", severity: "WARN",
    datasets: ["finance_data.silver.orders"],
    expression: "amount > 0 AND amount < 1000000",
    params: { max_sample_rows: "50" },
    owner: "finance-data-eng@example.com", status: "APPROVED", enabled: true,
    description: "Order amount must be > 0 and < 1,000,000." },
  { project_id: 1, project_code: "finance", rule_id: "BR_0210", version: 1,
    name: "orders.status in allowed values", layer: "BUSINESS_RULE",
    check_type: "DOMAIN", severity: "BLOCK",
    datasets: ["finance_data.silver.orders"],
    params: { column: "status", allowed_values: "PLACED,PAID,SHIPPED,DELIVERED,CANCELLED,REFUNDED" },
    owner: "finance-data-eng@example.com", status: "APPROVED", enabled: true },
  { project_id: 1, project_code: "finance", rule_id: "PT_0031", version: 1,
    name: "fct_sales total = staging sum", layer: "POST_TRANSFORM",
    check_type: "AGGREGATE_PARITY", severity: "BLOCK",
    datasets: ["finance_data.gold.fct_sales", "finance_data.silver.orders"],
    params: { left_table: "finance_data.gold.fct_sales", left_agg: "sum(amount)",
              right_table: "finance_data.silver.orders", right_agg: "sum(amount)",
              filter: "status IN ('PAID','SHIPPED','DELIVERED')",
              tolerance_pct: "0.001" },
    owner: "fin-bi@example.com", status: "PENDING_APPROVAL", enabled: true,
    description: "Sum of amount in fct_sales must equal sum in silver.orders within tolerance." },

  // marketing
  { project_id: 2, project_code: "marketing", rule_id: "BR_0118", version: 1,
    name: "products.product_id non-null and unique", layer: "BUSINESS_RULE",
    check_type: "PRIMARY_KEY", severity: "BLOCK",
    datasets: ["marketing_data.silver.products"], params: { keys: "product_id" },
    owner: "mktg-analytics@example.com", status: "APPROVED", enabled: true },
  { project_id: 2, project_code: "marketing", rule_id: "PT_0044", version: 1,
    name: "dim_customer.email null pct < 1%", layer: "POST_TRANSFORM",
    check_type: "NULL_PCT_MAX", severity: "WARN",
    datasets: ["marketing_data.gold.dim_customer"],
    params: { column: "email", max_null_pct: "1.0" },
    owner: "mktg-analytics@example.com", status: "PENDING_APPROVAL", enabled: true },

  // operations
  { project_id: 3, project_code: "operations", rule_id: "PT_0050", version: 1,
    name: "fct_shipments row count drift < 5% vs prior day", layer: "POST_TRANSFORM",
    check_type: "ROW_COUNT_DRIFT", severity: "WARN",
    datasets: ["ops_data.gold.fct_shipments"],
    params: { max_drop_pct: "5.0", compare_window_days: "1" },
    owner: "ops-data@example.com", status: "APPROVED", enabled: true },
];

// ---------------------------------------------------------------------------
// Synthetic runs / errors / audit — generated relative to "now"
// ---------------------------------------------------------------------------

const now = new Date();
const ago = (h: number) => new Date(now.getTime() - h * 3600_000).toISOString();

const RUNS: ValidationRun[] = [
  { project_id: 1, project_code: "finance", run_id: "r-finance-2826",
    trigger_type: "INGEST_PIPELINE", trigger_ref: "adf-run-7c3d2f", layer_filter: "FILE,BUSINESS_RULE",
    started_ts: ago(0.4), ended_ts: ago(0.39), status: "FAIL",
    rules_evaluated: 6, rules_passed: 3, rules_warned: 1, rules_failed: 2,
    records_checked: 1_240_113, framework_version: "0.1.0", triggered_by: "adf" },
  { project_id: 1, project_code: "finance", run_id: "r-finance-2825",
    trigger_type: "SCHEDULE", trigger_ref: "adf-run-7c3a14",
    started_ts: ago(6.4), ended_ts: ago(6.38), status: "PASS",
    rules_evaluated: 7, rules_passed: 7, rules_warned: 0, rules_failed: 0,
    records_checked: 1_215_440, framework_version: "0.1.0", triggered_by: "adf" },
  { project_id: 1, project_code: "finance", run_id: "r-finance-2820",
    trigger_type: "INGEST_PIPELINE", trigger_ref: "adf-run-7b9981",
    started_ts: ago(13.5), ended_ts: ago(13.45), status: "WARN",
    rules_evaluated: 6, rules_passed: 5, rules_warned: 1, rules_failed: 0,
    records_checked: 1_198_002, framework_version: "0.1.0", triggered_by: "adf" },
  { project_id: 2, project_code: "marketing", run_id: "r-marketing-1407",
    trigger_type: "SCHEDULE", trigger_ref: "adf-run-9a01b2",
    started_ts: ago(2.1), ended_ts: ago(2.08), status: "FAIL",
    rules_evaluated: 1, rules_passed: 0, rules_warned: 0, rules_failed: 1,
    records_checked: 84_322, framework_version: "0.1.0", triggered_by: "adf" },
  { project_id: 3, project_code: "operations", run_id: "r-ops-0892",
    trigger_type: "SCHEDULE", trigger_ref: "adf-run-3f5012",
    started_ts: ago(5.2), ended_ts: ago(5.18), status: "PASS",
    rules_evaluated: 1, rules_passed: 1, rules_warned: 0, rules_failed: 0,
    records_checked: 6_812, framework_version: "0.1.0", triggered_by: "adf" },
];

const ERRORS: ValidationError[] = [
  { project_id: 1, error_id: "e-9001", run_id: "r-finance-2826", rule_id: "BR_0142", rule_version: 4,
    dataset: "finance_data.silver.orders", record_pk: "104",
    expected: "orphan_pct <= 0.0%", actual: "1 orphan (16.67%)",
    severity: "BLOCK", sample_payload: '{"order_id": 104, "customer_id": 99}',
    captured_ts: ago(0.39) },
  { project_id: 1, error_id: "e-9002", run_id: "r-finance-2826", rule_id: "BR_0210", rule_version: 1,
    dataset: "finance_data.silver.orders", record_pk: "106",
    expected: "status in [PLACED,PAID,SHIPPED,DELIVERED,CANCELLED,REFUNDED]",
    actual: "1 row out of domain (UNKNOWN)",
    severity: "BLOCK", sample_payload: '{"order_id": 106, "status": "UNKNOWN"}',
    captured_ts: ago(0.39) },
  { project_id: 1, error_id: "e-9003", run_id: "r-finance-2826", rule_id: "BR_0205", rule_version: 1,
    dataset: "finance_data.silver.orders", record_pk: "105",
    expected: "amount > 0 AND amount < 1000000",
    actual: "1 violating row (amount = -5.00)",
    severity: "WARN", sample_payload: '{"order_id": 105, "amount": -5.00}',
    captured_ts: ago(0.39) },
  { project_id: 2, error_id: "e-9201", run_id: "r-marketing-1407", rule_id: "BR_0118", rule_version: 1,
    dataset: "marketing_data.silver.products", record_pk: "2",
    expected: "no nulls, no duplicates",
    actual: "1 duplicate primary key",
    severity: "BLOCK", sample_payload: '{"product_id": 2, "name": "Gadget Dup"}',
    captured_ts: ago(2.08) },
];

const AUDIT: AuditEntry[] = [
  { project_id: 1, audit_id: "a-501", actor: "akhil", role: "AUTHOR",
    action: "CREATE_RULE", entity_type: "RULE", entity_id: "PT_0031",
    reason: "Add post-transform parity check for fct_sales",
    framework_version: "0.1.0", event_ts: ago(28) },
  { project_id: 1, audit_id: "a-502", actor: "data-quality", role: "REVIEWER",
    action: "REVIEW_RULE", entity_type: "RULE", entity_id: "PT_0031",
    reason: "Approved by reviewer", framework_version: "0.1.0", event_ts: ago(26) },
  { project_id: 2, audit_id: "a-503", actor: "mktg-analytics", role: "AUTHOR",
    action: "UPDATE_RULE", entity_type: "RULE", entity_id: "PT_0044",
    framework_version: "0.1.0", event_ts: ago(20) },
  { project_id: 1, audit_id: "a-504", actor: "adf", role: "SYSTEM",
    action: "RUN_TRIGGER", entity_type: "RUN", entity_id: "r-finance-2826",
    reason: "trigger=INGEST_PIPELINE", framework_version: "0.1.0", event_ts: ago(0.39) },
  { project_id: 2, audit_id: "a-505", actor: "adf", role: "SYSTEM",
    action: "RUN_TRIGGER", entity_type: "RUN", entity_id: "r-marketing-1407",
    reason: "trigger=SCHEDULE", framework_version: "0.1.0", event_ts: ago(2.08) },
];

// ---------------------------------------------------------------------------
// Public API — these are what the React pages call
// ---------------------------------------------------------------------------

export async function listProjects(): Promise<Project[]> {
  await sleep(80);
  return [...PROJECTS];
}

export async function getProjectSettings(projectId: number): Promise<DqProjectSettings | undefined> {
  await sleep(50);
  return SETTINGS.find((s) => s.project_id === projectId);
}

export async function listRules(projectId: number): Promise<Rule[]> {
  await sleep(80);
  return RULES.filter((r) => r.project_id === projectId);
}

export async function getRule(projectId: number, ruleId: string): Promise<Rule | undefined> {
  await sleep(60);
  return RULES.find((r) => r.project_id === projectId && r.rule_id === ruleId);
}

export async function listRuns(projectId: number, limit = 50): Promise<ValidationRun[]> {
  await sleep(80);
  return RUNS.filter((r) => r.project_id === projectId)
    .sort((a, b) => b.started_ts.localeCompare(a.started_ts))
    .slice(0, limit);
}

export async function listErrors(projectId: number, runId?: string): Promise<ValidationError[]> {
  await sleep(80);
  return ERRORS.filter((e) =>
    e.project_id === projectId && (!runId || e.run_id === runId),
  ).sort((a, b) => b.captured_ts.localeCompare(a.captured_ts));
}

export async function listAudit(projectId: number, limit = 50): Promise<AuditEntry[]> {
  await sleep(60);
  return AUDIT.filter((a) => a.project_id === projectId)
    .sort((a, b) => b.event_ts.localeCompare(a.event_ts))
    .slice(0, limit);
}

export async function getProjectHealth(): Promise<ProjectHealth[]> {
  await sleep(80);
  return PROJECTS.map((p) => {
    const settings = SETTINGS.find((s) => s.project_id === p.project_id);
    const projRuns = RUNS.filter((r) => r.project_id === p.project_id);
    return {
      project_id: p.project_id,
      project_code: p.project_code,
      project_name: p.project_name,
      dq_framework_version: settings?.dq_framework_version ?? "0.1.0",
      runs_24h: projRuns.length,
      runs_pass: projRuns.filter((r) => r.status === "PASS").length,
      runs_warn: projRuns.filter((r) => r.status === "WARN").length,
      runs_fail: projRuns.filter((r) => r.status === "FAIL" || r.status === "ERROR").length,
      total_rules_failed: projRuns.reduce((s, r) => s + r.rules_failed, 0),
      total_records_checked: projRuns.reduce((s, r) => s + r.records_checked, 0),
      last_run_ts: projRuns[0]?.started_ts,
    };
  });
}

/** Mutating endpoints — kept as no-ops with optimistic UI */
export async function submitRuleForApproval(_projectId: number, _ruleId: string): Promise<void> {
  await sleep(120);
}
export async function approveRule(_projectId: number, _ruleId: string): Promise<void> {
  await sleep(120);
}
export async function rejectRule(_projectId: number, _ruleId: string, _reason: string): Promise<void> {
  await sleep(120);
}
