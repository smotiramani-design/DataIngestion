/**
 * Formatting helpers used across the console.
 */

export function fmtNumber(n: number | null | undefined): string {
  if (n === null || n === undefined) return "—";
  return new Intl.NumberFormat("en-US").format(n);
}

export function fmtPct(n: number | null | undefined, digits = 1): string {
  if (n === null || n === undefined || isNaN(n)) return "—";
  return `${n.toFixed(digits)}%`;
}

export function fmtRelative(iso: string | undefined): string {
  if (!iso) return "—";
  const ts = new Date(iso).getTime();
  if (Number.isNaN(ts)) return iso;
  const diffMs = Date.now() - ts;
  const sec = Math.floor(diffMs / 1000);
  if (sec < 60) return `${sec}s ago`;
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const day = Math.floor(hr / 24);
  if (day < 7) return `${day}d ago`;
  return new Date(iso).toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

export function fmtDuration(secs: number | null | undefined): string {
  if (secs === null || secs === undefined) return "—";
  if (secs < 60) return `${secs.toFixed(1)}s`;
  const m = Math.floor(secs / 60), s = Math.round(secs - m * 60);
  return `${m}m ${s}s`;
}

export function statusPillClass(status: string): string {
  switch (status) {
    case "PASS":             return "pill pill-pass";
    case "APPROVED":         return "pill pill-pass";
    case "WARN":             return "pill pill-warn";
    case "PENDING_APPROVAL": return "pill pill-pending";
    case "DRAFT":            return "pill pill-pending";
    case "FAIL":             return "pill pill-fail";
    case "ERROR":            return "pill pill-fail";
    case "REJECTED":         return "pill pill-fail";
    case "RETIRED":          return "pill pill-muted";
    case "RUNNING":          return "pill pill-muted";
    default:                  return "pill pill-muted";
  }
}

export function severityClass(sev: string): string {
  switch (sev) {
    case "BLOCK": return "sev-block";
    case "WARN":  return "sev-warn";
    case "INFO":  return "sev-info";
    default:       return "";
  }
}
