/**
 * Project selection context.
 *
 * The console is multi-tenant; everything the user sees is scoped to one
 * project. The current project lives in this context, persisted to
 * localStorage so it survives reloads.
 */
import { createContext, useCallback, useContext, useEffect, useState } from "react";
import type { ReactNode } from "react";
import type { Project } from "../types";
import { listProjects } from "../api/mockClient";

interface ProjectContextValue {
  projects: Project[];
  current: Project | null;
  loading: boolean;
  setCurrentByCode: (code: string) => void;
}

const ProjectContext = createContext<ProjectContextValue | null>(null);

const LS_KEY = "dq.console.currentProject";

export function ProjectProvider({ children }: { children: ReactNode }) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [current, setCurrent] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);

  // Load projects once on mount
  useEffect(() => {
    let cancelled = false;
    listProjects().then((ps) => {
      if (cancelled) return;
      setProjects(ps);
      const stored = localStorage.getItem(LS_KEY);
      const initial = ps.find((p) => p.project_code === stored) ?? ps[0] ?? null;
      setCurrent(initial);
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, []);

  const setCurrentByCode = useCallback((code: string) => {
    setCurrent((prev) => {
      const next = projects.find((p) => p.project_code === code) ?? prev;
      if (next) localStorage.setItem(LS_KEY, next.project_code);
      return next;
    });
  }, [projects]);

  const value: ProjectContextValue = { projects, current, loading, setCurrentByCode };
  return <ProjectContext.Provider value={value}>{children}</ProjectContext.Provider>;
}

export function useProject(): ProjectContextValue {
  const ctx = useContext(ProjectContext);
  if (!ctx) throw new Error("useProject must be used within ProjectProvider");
  return ctx;
}
