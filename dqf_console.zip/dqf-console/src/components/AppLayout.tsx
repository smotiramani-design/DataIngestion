import { NavLink, Outlet } from "react-router-dom";
import {
  LayoutDashboard, ListChecks, History, AlertTriangle,
  ClipboardCheck, Database, FileSearch, Settings, ShieldCheck,
} from "lucide-react";
import { ProjectSwitcher } from "./ProjectSwitcher";

const NAV = [
  { to: "/",          label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/rules",     label: "Rules",     icon: ListChecks },
  { to: "/runs",      label: "Runs",      icon: History },
  { to: "/errors",    label: "Errors",    icon: AlertTriangle },
  { to: "/approvals", label: "Approvals", icon: ClipboardCheck },
  { to: "/datasets",  label: "Datasets",  icon: Database },
  { to: "/audit",     label: "Audit Log", icon: FileSearch },
  { to: "/settings",  label: "Settings",  icon: Settings },
];

export function AppLayout() {
  return (
    <div className="min-h-screen flex bg-surface-soft">
      {/* Sidebar */}
      <aside className="w-64 bg-navy-deep text-white flex flex-col flex-shrink-0">
        {/* Brand */}
        <div className="px-5 pt-5 pb-3 flex items-center gap-2">
          <div className="w-7 h-7 rounded bg-teal flex items-center justify-center">
            <ShieldCheck size={16} className="text-navy-deep" strokeWidth={2.5} />
          </div>
          <div className="text-[11px] uppercase tracking-[0.2em] font-bold text-teal">
            DQ Platform
          </div>
        </div>

        {/* Project switcher */}
        <div className="px-3 pb-2">
          <ProjectSwitcher />
        </div>

        {/* Navigation */}
        <nav className="px-3 pt-2 flex-1 overflow-y-auto">
          {NAV.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                `flex items-center gap-2.5 px-3 py-2 rounded-md text-sm font-medium mb-0.5
                 transition-colors ${
                   isActive
                     ? "bg-navy-soft text-white"
                     : "text-white/70 hover:bg-navy-mid hover:text-white"
                 }`
              }
            >
              <Icon size={16} />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-navy-mid">
          <div className="text-[10px] uppercase tracking-wider text-white/40 mb-1">Framework</div>
          <div className="text-[11px] font-mono text-white/70">v0.1.0</div>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 min-w-0 overflow-x-auto">
        <Outlet />
      </main>
    </div>
  );
}
