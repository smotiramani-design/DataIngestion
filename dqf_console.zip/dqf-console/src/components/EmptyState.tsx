import type { LucideIcon } from "lucide-react";

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description?: string;
}

export function EmptyState({ icon: Icon, title, description }: EmptyStateProps) {
  return (
    <div className="text-center py-14 px-6">
      <div className="inline-flex items-center justify-center w-12 h-12 rounded-full
                      bg-surface-soft border border-surface-border mb-3">
        <Icon size={20} className="text-graphite-muted" />
      </div>
      <div className="text-sm font-semibold text-ink">{title}</div>
      {description && <div className="text-sm text-graphite-muted mt-1">{description}</div>}
    </div>
  );
}
