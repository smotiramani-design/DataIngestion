import type { ReactNode } from "react";

interface PageHeaderProps {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  actions?: ReactNode;
}

export function PageHeader({ eyebrow, title, subtitle, actions }: PageHeaderProps) {
  return (
    <header className="px-8 pt-7 pb-5 border-b border-surface-border bg-white">
      <div className="flex items-start justify-between gap-6">
        <div className="min-w-0">
          {eyebrow && (
            <div className="text-[11px] uppercase tracking-[0.18em] font-bold text-teal-deep mb-1.5">
              {eyebrow}
            </div>
          )}
          <h1 className="text-[28px] leading-tight font-bold text-ink tracking-tight">{title}</h1>
          {subtitle && (
            <p className="text-sm text-graphite-muted mt-1.5 max-w-2xl">{subtitle}</p>
          )}
        </div>
        {actions && <div className="flex items-center gap-2 flex-shrink-0">{actions}</div>}
      </div>
    </header>
  );
}
