import { statusPillClass } from "../lib/format";

export function StatusPill({ status }: { status: string }) {
  return <span className={statusPillClass(status)}>{status.replace(/_/g, " ")}</span>;
}
