import { useEffect, useRef, useState } from "react";
import { ChevronDown, Check } from "lucide-react";
import { useProject } from "../lib/projectContext";

export function ProjectSwitcher() {
  const { projects, current, setCurrentByCode } = useProject();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  // Close when clicking outside the switcher
  useEffect(() => {
    if (!open) return;
    function onDoc(e: MouseEvent) {
      if (!ref.current?.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);

  if (!current) {
    return (
      <div className="bg-navy-mid/40 border border-navy-soft/40 rounded-md px-3 py-3 text-xs text-white/60">
        Loading projects…
      </div>
    );
  }

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="w-full text-left bg-navy-mid border border-navy-soft/60 rounded-md px-3 py-2.5
                   flex items-center justify-between gap-2 hover:border-teal/60 transition-colors
                   focus:outline-none focus:ring-2 focus:ring-teal/40"
      >
        <div className="min-w-0">
          <div className="text-[10px] uppercase tracking-widest text-teal font-semibold">Project</div>
          <div className="text-sm font-semibold text-white truncate">{current.project_name}</div>
          <div className="text-[11px] font-mono text-white/60 truncate">
            {current.project_code} · {current.default_catalog}
          </div>
        </div>
        <ChevronDown
          size={16}
          className={`text-teal flex-shrink-0 transition-transform ${open ? "rotate-180" : ""}`}
        />
      </button>

      {open && (
        <div className="absolute left-0 right-0 mt-1 bg-white border border-surface-border rounded-md
                        shadow-card z-20 overflow-hidden fade-up">
          {projects.map((p) => {
            const selected = p.project_id === current.project_id;
            return (
              <button
                key={p.project_id}
                type="button"
                onClick={() => { setCurrentByCode(p.project_code); setOpen(false); }}
                className={`w-full text-left px-3 py-2.5 hover:bg-surface-soft border-b
                            border-surface-border last:border-b-0 flex items-center gap-2
                            ${selected ? "bg-surface-soft" : ""}`}
              >
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-ink truncate">{p.project_name}</div>
                  <div className="text-[11px] font-mono text-graphite-muted truncate">
                    {p.project_code} · {p.default_catalog}
                  </div>
                </div>
                {selected && <Check size={14} className="text-teal flex-shrink-0" />}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
