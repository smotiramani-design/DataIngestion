import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ProjectProvider } from "./lib/projectContext";
import { AppLayout } from "./components/AppLayout";
import { DashboardPage } from "./pages/DashboardPage";
import { RulesPage } from "./pages/RulesPage";
import { RuleEditorPage } from "./pages/RuleEditorPage";
import { RunsPage } from "./pages/RunsPage";
import { ErrorsPage } from "./pages/ErrorsPage";
import { ApprovalsPage } from "./pages/ApprovalsPage";
import { AuditPage } from "./pages/AuditPage";
import { DatasetsPage } from "./pages/DatasetsPage";
import { SettingsPage } from "./pages/SettingsPage";

export default function App() {
  return (
    <ProjectProvider>
      <BrowserRouter>
        <Routes>
          <Route element={<AppLayout />}>
            <Route path="/"               element={<DashboardPage />} />
            <Route path="/rules"          element={<RulesPage />} />
            <Route path="/rules/:ruleId"  element={<RuleEditorPage />} />
            <Route path="/runs"           element={<RunsPage />} />
            <Route path="/errors"         element={<ErrorsPage />} />
            <Route path="/approvals"      element={<ApprovalsPage />} />
            <Route path="/datasets"       element={<DatasetsPage />} />
            <Route path="/audit"          element={<AuditPage />} />
            <Route path="/settings"       element={<SettingsPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </ProjectProvider>
  );
}
