# Databricks notebook source
# MAGIC %md
# MAGIC # DQ Validation — ADF Notebook Activity entry point
# MAGIC
# MAGIC This notebook is the contract between Azure Data Factory and the Databricks-side
# MAGIC validation engine. ADF invokes it via `Microsoft.DataFactory/factories/pipelines`
# MAGIC Notebook Activity, passing parameters as Databricks widgets.
# MAGIC
# MAGIC The notebook:
# MAGIC   1. Reads ADF parameters from widgets.
# MAGIC   2. Invokes `dqf.jobs.run_validation` with those parameters.
# MAGIC   3. Calls `dbutils.notebook.exit(json.dumps(...))` with the run summary so
# MAGIC      ADF can branch on `runOutput.status` / `runOutput.should_block_publish`.
# MAGIC
# MAGIC ## Activity contract (set in the ADF pipeline's Notebook Activity)
# MAGIC
# MAGIC ```yaml
# MAGIC notebookPath: /dq/notebooks/run_dq_validation
# MAGIC baseParameters:
# MAGIC   project_code:  "@{pipeline().parameters.projectCode}"
# MAGIC   layer_filter:  "@{pipeline().parameters.layer}"          # optional, comma-sep
# MAGIC   dataset_filter: "@{pipeline().parameters.datasets}"      # optional, comma-sep
# MAGIC   trigger_type:  "@{pipeline().parameters.triggerType}"    # INGEST_PIPELINE | SCHEDULE | API
# MAGIC   trigger_ref:   "@{pipeline().RunId}"                     # cross-FW lineage
# MAGIC   env:           "@{pipeline().globalParameters.env}"      # dev | test | prod
# MAGIC ```
# MAGIC
# MAGIC ## Return value (read by next ADF activity via `runOutput`)
# MAGIC
# MAGIC ```json
# MAGIC {
# MAGIC   "run_id": "uuid",
# MAGIC   "project_code": "finance",
# MAGIC   "status": "PASS | WARN | FAIL | ERROR",
# MAGIC   "rules_evaluated": 42,
# MAGIC   "rules_failed": 0,
# MAGIC   "should_block_publish": false,
# MAGIC   "framework_version": "0.1.0"
# MAGIC }
# MAGIC ```
# MAGIC
# MAGIC ADF then branches on `@activity('DQ_Notebook').output.runOutput.should_block_publish`.

# COMMAND ----------

# DBTITLE 1,Widgets — populated by ADF baseParameters
# Widgets must be defined; ADF passes parameters to Databricks via these.
dbutils.widgets.text("project_code",   "",         "project_code (REQUIRED)")
dbutils.widgets.text("layer_filter",   "",         "layer_filter (FILE,BUSINESS_RULE,POST_TRANSFORM)")
dbutils.widgets.text("dataset_filter", "",         "dataset_filter (comma-separated)")
dbutils.widgets.text("trigger_type",   "SCHEDULE", "trigger_type")
dbutils.widgets.text("trigger_ref",    "",         "trigger_ref (ADF pipeline RunId)")
dbutils.widgets.text("env",            "dev",      "env (dev|test|prod)")

# COMMAND ----------

# DBTITLE 1,Read widgets and build CLI argv
import json
import sys

project_code   = dbutils.widgets.get("project_code").strip()
layer_filter   = dbutils.widgets.get("layer_filter").strip()
dataset_filter = dbutils.widgets.get("dataset_filter").strip()
trigger_type   = dbutils.widgets.get("trigger_type").strip() or "SCHEDULE"
trigger_ref    = dbutils.widgets.get("trigger_ref").strip()
env            = dbutils.widgets.get("env").strip() or "dev"

if not project_code:
    # Fail fast and surface the error to ADF
    err = {"error": "project_code widget is required", "status": "ERROR"}
    dbutils.notebook.exit(json.dumps(err))

# Build argv for run_validation.main(). One --layer / --dataset arg per value.
argv = [
    "--project",      project_code,
    "--env",          env,
    "--trigger-type", trigger_type,
    "--triggered-by", "adf",
    "--fail-on-block",
]
if trigger_ref:
    argv += ["--trigger-ref", trigger_ref]
for lyr in [x.strip() for x in layer_filter.split(",") if x.strip()]:
    argv += ["--layer", lyr]
for ds in [x.strip() for x in dataset_filter.split(",") if x.strip()]:
    argv += ["--dataset", ds]

print(f"Invoking dqf.jobs.run_validation with argv: {argv}")

# COMMAND ----------

# DBTITLE 1,Run validation and capture summary
# We don't want run_validation.main()'s sys.exit() to terminate the notebook
# before we can call dbutils.notebook.exit(). So we instead reach into the
# engine directly and re-implement the small CLI flow here, using the same
# load_project / load_rules_from_delta / ValidationEngine helpers.
from dqf.engine import (
    ValidationEngine, load_project, load_rules_from_delta,
)

try:
    project, settings = load_project(spark, project_code)
except ValueError as e:
    dbutils.notebook.exit(json.dumps({
        "status": "ERROR",
        "error": str(e),
        "project_code": project_code,
    }))

layers = [x.strip() for x in layer_filter.split(",") if x.strip()] or None
datasets = [x.strip() for x in dataset_filter.split(",") if x.strip()] or None

rules = load_rules_from_delta(spark, project, layers=layers, datasets=datasets)

if not rules:
    # No rules matched — return a synthetic PASS so ADF doesn't fail the pipeline.
    # Distinguished from a real PASS by rules_evaluated=0.
    dbutils.notebook.exit(json.dumps({
        "run_id": None,
        "project_code": project.project_code,
        "status": "PASS",
        "rules_evaluated": 0,
        "rules_failed": 0,
        "should_block_publish": False,
        "framework_version": settings.dq_framework_version,
        "note": "no_active_rules_matched_filters",
    }))

engine = ValidationEngine(spark, project, settings=settings, env=env)
summary = engine.run(
    rules=rules,
    layers=layers, datasets=datasets,
    trigger_type=trigger_type,
    trigger_ref=trigger_ref or None,
    triggered_by="adf",
)

# COMMAND ----------

# DBTITLE 1,Exit with summary so ADF can branch on it
result = {
    "run_id":               summary.run_id,
    "project_id":           summary.project_id,
    "project_code":         summary.project_code,
    "status":               summary.status,
    "rules_evaluated":      summary.rules_evaluated,
    "rules_passed":         summary.rules_passed,
    "rules_warned":         summary.rules_warned,
    "rules_failed":         summary.rules_failed,
    "records_checked":      summary.records_checked,
    "duration_sec":         summary.duration_sec,
    "should_block_publish": summary.should_block_publish,
    "framework_version":    summary.framework_version,
}
print(json.dumps(result, indent=2))
dbutils.notebook.exit(json.dumps(result))
