"""
End-to-end smoke test for the multi-project validation engine.

Verifies:
  1. Each project's rules execute independently against its own datasets.
  2. Tenant isolation: an engine bound to project A refuses rules from B.
  3. RunSummary carries project_id, project_code, framework_version.
  4. Per-project block_publish_on_fail setting is honored:
       - finance has block_publish_on_fail=true  -> should_block_publish=True on FAIL
       - marketing has block_publish_on_fail=false -> should_block_publish=False on FAIL

Run:  PYTHONPATH=. python -m dqf.tests.test_engine_e2e
"""
from __future__ import annotations

import logging
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from pyspark.sql import SparkSession

from dqf.engine import (
    ValidationEngine, load_dq_settings_from_json,
    load_projects_from_json, load_rules_from_json,
)


def build_test_data(spark: SparkSession) -> dict:
    customers = spark.createDataFrame(
        [(1, "alice@x.com"), (2, "bob@x.com"), (3, None), (4, "dan@x.com")],
        ["customer_id", "email"],
    )
    orders = spark.createDataFrame(
        [
            (101, 1, datetime(2026, 4, 1, 9, 0), Decimal("19.99"), "USD", "PAID"),
            (102, 2, datetime(2026, 4, 1, 10, 0), Decimal("49.50"), "USD", "SHIPPED"),
            (103, 3, datetime(2026, 4, 1, 11, 0), Decimal("0.00"),  "USD", "PLACED"),
            (104, 99, datetime(2026, 4, 1, 12, 0), Decimal("12.00"), "USD", "PAID"),
            (105, 4, datetime(2026, 4, 1, 13, 0), Decimal("-5.00"), "USD", "DELIVERED"),
            (106, 4, datetime(2026, 4, 1, 14, 0), Decimal("99.00"), "USD", "UNKNOWN"),
        ],
        "order_id long, customer_id long, order_ts timestamp, amount decimal(18,2), "
        "currency string, status string",
    )
    fct_sales = orders.filter("status IN ('PAID','SHIPPED','DELIVERED')") \
                      .selectExpr("order_id", "customer_id", "amount")

    products = spark.createDataFrame(
        [(1, "Widget"), (2, "Gadget"), (2, "Gadget Dup")],
        ["product_id", "name"],
    )
    dim_customer = spark.createDataFrame(
        [(1, "alice@x.com"), (2, "bob@x.com"), (3, None), (4, "dan@x.com")],
        ["customer_id", "email"],
    )

    return {
        "finance_data.bronze.orders": orders,
        "finance_data.silver.orders": orders,
        "finance_data.silver.customers": customers,
        "finance_data.gold.fct_sales": fct_sales,
        "marketing_data.silver.products": products,
        "marketing_data.gold.dim_customer": dim_customer,
    }


def make_resolver(datasets):
    def resolve(name: str):
        if name not in datasets:
            raise KeyError(f"test fixture missing dataset: {name}")
        return datasets[name]
    return resolve


def main():
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s :: %(message)s")

    spark = (
        SparkSession.builder
        .appName("dq.e2e_test")
        .master("local[2]")
        .config("spark.sql.shuffle.partitions", "4")
        .config("spark.ui.enabled", "false")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("WARN")

    base = Path(__file__).resolve().parents[1] / "rules"
    # Note: in production, projects are loaded from ingest_platform.control.projects
    # (the Ingestion Framework's table). Here we use a fixture for test isolation.
    projects = load_projects_from_json(base / "sample_projects_FIXTURE.json")
    settings_by_pid = load_dq_settings_from_json(base / "sample_dq_settings.json", projects)
    print(f"\nloaded {len(projects)} projects: {sorted(projects.keys())}")
    print(f"loaded {len(settings_by_pid)} DQ settings")

    datasets = build_test_data(spark)
    resolve = make_resolver(datasets)

    # =========================================================================
    # Run finance project (block_publish_on_fail = true)
    # =========================================================================
    print("\n" + "#" * 70)
    print("# Project: finance  (block_publish_on_fail=true)")
    print("#" * 70)
    finance = projects["finance"]
    fin_settings = settings_by_pid[finance.project_id]
    finance_rules = load_rules_from_json(base / "sample_rules.json", projects, "finance")
    engine_fin = ValidationEngine(spark, finance, settings=fin_settings, env="test",
                                  source_resolver=resolve, persist=False)
    summary_fin = engine_fin.run(rules=finance_rules,
                                 trigger_type="MANUAL", triggered_by="test")
    print_summary(summary_fin)

    # =========================================================================
    # Run marketing project (block_publish_on_fail = false)
    # =========================================================================
    print("\n" + "#" * 70)
    print("# Project: marketing  (block_publish_on_fail=false)")
    print("#" * 70)
    mktg = projects["marketing"]
    mktg_settings = settings_by_pid[mktg.project_id]
    mktg_rules = load_rules_from_json(base / "sample_rules.json", projects, "marketing")
    engine_mktg = ValidationEngine(spark, mktg, settings=mktg_settings, env="test",
                                   source_resolver=resolve, persist=False)
    summary_mktg = engine_mktg.run(rules=mktg_rules,
                                   trigger_type="MANUAL", triggered_by="test")
    print_summary(summary_mktg)

    # =========================================================================
    # Tenant isolation
    # =========================================================================
    print("\n" + "#" * 70)
    print("# Cross-project leak protection")
    print("#" * 70)
    leak_caught = False
    try:
        engine_fin.run(rules=mktg_rules, trigger_type="MANUAL", triggered_by="test")
    except ValueError as e:
        print(f"  PASS: cross-project rule rejected: {e}")
        leak_caught = True
    assert leak_caught, "engine accepted rules from another project"

    # =========================================================================
    # Assertions
    # =========================================================================
    fin_by_id = {r.rule.rule_id: r for r in summary_fin.results}
    mktg_by_id = {r.rule.rule_id: r for r in summary_mktg.results}

    # finance scope
    assert summary_fin.project_code == "finance"
    assert summary_fin.project_id == finance.project_id
    assert fin_by_id["BR_0142"].effective_status == "FAIL"
    assert fin_by_id["BR_0205"].effective_status == "WARN"
    assert fin_by_id["BR_0210"].effective_status == "FAIL"
    assert fin_by_id["FL_0001"].effective_status == "PASS"
    assert fin_by_id["PT_0031"].effective_status == "PASS"
    assert "BR_0118" not in fin_by_id, "marketing rule leaked into finance"
    assert summary_fin.status == "FAIL"

    # marketing scope
    assert summary_mktg.project_code == "marketing"
    assert summary_mktg.project_id == mktg.project_id
    assert mktg_by_id["BR_0118"].effective_status == "FAIL"
    assert mktg_by_id["PT_0044"].effective_status == "WARN"
    assert "BR_0142" not in mktg_by_id, "finance rule leaked into marketing"
    assert summary_mktg.status == "FAIL"

    # framework version comes from each project's settings
    assert summary_fin.framework_version == fin_settings.dq_framework_version
    assert summary_mktg.framework_version == mktg_settings.dq_framework_version

    # block_publish_on_fail honored per project
    assert summary_fin.block_publish_on_fail is True
    assert summary_fin.should_block_publish is True, \
        "finance opts in to gating, FAIL run should block downstream publish"
    assert summary_mktg.block_publish_on_fail is False
    assert summary_mktg.should_block_publish is False, \
        "marketing opts out of gating, FAIL should NOT block publish"

    print("\nAll assertions passed. Multi-project framework wired up correctly.")
    print("Cross-framework integration: projects table sourced from ingest_platform.control.projects;")
    print("DQ settings sourced from dq_platform.governance.dq_project_settings.")
    spark.stop()


def print_summary(s):
    print(f"\nRUN [{s.project_code}] {s.run_id}  status={s.status}")
    print(f"  evaluated={s.rules_evaluated}  pass={s.rules_passed}"
          f"  warn={s.rules_warned}  fail={s.rules_failed}")
    print(f"  duration={s.duration_sec:.2f}s   framework={s.framework_version}")
    print(f"  block_publish_on_fail={s.block_publish_on_fail}  -> "
          f"should_block_publish={s.should_block_publish}")
    print("-" * 70)
    print(f"{'rule_id':<10} {'layer':<16} {'severity':<8} {'status':<6} "
          f"{'failed':>8}  expected -> actual")
    print("-" * 70)
    for r in s.results:
        print(f"{r.rule.rule_id:<10} {r.rule.layer.value:<16} "
              f"{r.rule.severity.value:<8} {r.effective_status:<6} "
              f"{r.records_failed:>8}  {(r.expected or '')[:40]:<40} -> "
              f"{(r.actual or '')[:40]}")


if __name__ == "__main__":
    main()
