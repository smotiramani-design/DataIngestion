# Data Quality Framework — Reference Implementation

Multi-tenant data quality platform on Azure Data Factory + Databricks + Delta.
Three validation layers (file, business rules + joins, post-transform),
Delta-backed rule configuration, full audit trail, severity-driven block/warn/pass
gating, scoped per project.

## Cross-framework integration

The DQ framework is **a downstream consumer** of the Data Ingestion Framework.
They share project identity via direct table reference:

```
                       ┌─────────────────────────────────────────────┐
                       │  ingest_platform.control.projects           │  ← OWNED by Ingestion FW
                       │  project_id, project_code, default_catalog, │     (DQ reads, does not write)
                       │  alert_email, framework_version, ...        │
                       └────────────┬────────────────────────────────┘
                                    │ FK (project_id)
                       ┌────────────┴────────────────────────────────┐
                       │                                             │
                       ▼                                             ▼
          ┌──────────────────────────┐               ┌──────────────────────────┐
          │  Ingestion FW tables     │               │  DQ FW tables            │
          │  feed_config             │               │  dq_project_settings     │  ← DQ-owned sidecar
          │  audit_log               │               │  dq_rules                │
          │  error_log               │               │  dq_validation_runs      │
          │  ALL scoped by project_id│               │  dq_validation_errors    │
          │                          │               │  dq_audit_log            │
          │                          │               │  dq_run_metrics          │
          │                          │               │  ALL scoped by project_id│
          └──────────────────────────┘               └──────────────────────────┘
```

The DQ framework does not own or alter the projects table. Per-project DQ
settings (framework version, block-on-fail, notification overrides) live in
`dq_project_settings` — a sidecar 1:1 with projects, owned by this framework.

## Orchestration

ADF orchestrates everything. Two pipeline patterns, both calling the same
PySpark validation engine via a Databricks Notebook Activity.

**Pattern A — Inline DQ.** A `DQ Notebook` activity inserted into the
Ingestion FW's per-project pipeline between Bronze landing and Silver
promotion. Used for file-level + post-ingest checks tied to one ingestion run.

**Pattern B — Standalone DQ Pipeline.** A dedicated ADF pipeline per project
on its own schedule (e.g. every 6 hours). Used for cross-table business rules
and scheduled post-transform validation independent of ingestion.

Both end with a Branch on `runOutput.should_block_publish` so ADF can decide
block-vs-continue using the engine's existing gating flag.

See `dqf/adf/README.md` for the templates and parameter contract.

## Project layout

```
dqf/
├── ddl/
│   └── 01_create_tables.sql          DQ-owned tables (projects table NOT created here)
├── rules/
│   ├── sample_dq_settings.json       3 DQ settings rows
│   ├── sample_rules.json             10 rules across 3 projects
│   └── sample_projects_FIXTURE.json  Test fixture (production = Ingestion FW table)
├── engine/
│   ├── rule_model.py                 Project, DqProjectSettings, Rule, loaders
│   ├── check_result.py
│   ├── checks.py                     9 check implementations + dispatch
│   └── engine.py                     Project-bound orchestrator
├── jobs/
│   ├── seed_rules.py                 Seeds dq_project_settings + rules
│   └── run_validation.py             --project <code> required; --trigger-ref for ADF lineage
├── notebooks/
│   └── run_dq_validation.py          Databricks notebook entry point for ADF
├── adf/
│   ├── dq_inline_activity.json       Pattern A — drop into ingestion pipelines
│   ├── dq_standalone_pipeline_template.json   Pattern B — per-project pipeline
│   ├── dq_standalone_trigger_template.json    Schedule trigger
│   └── README.md                     Deployment + linked services + parameter contract
└── tests/
    └── test_engine_e2e.py            Multi-project + tenant isolation + per-project gating
```

## How a run flows

```
ADF trigger (schedule / ingest pipeline / API call)
      │
      ▼
ADF Notebook Activity → /Shared/dq/notebooks/run_dq_validation
      │
      ▼
load_project(spark, project_code)
      │  ├── reads ingest_platform.control.projects  (Ingestion FW table)
      │  └── reads dq_platform.governance.dq_project_settings  (DQ FW table)
      │
      ▼
ValidationEngine(spark, project, settings=settings)
      .run(rules=...)
      │
      ├── refuse rules whose project_id != project.project_id  ← isolation guard
      ├── load rules WHERE project_id = ?
      ├── group by primary dataset, dispatch on check_type
      ├── persist failures → dq_validation_errors      (with project_id)
      ├── persist metrics  → dq_run_metrics            (with project_id)
      ├── update header    → dq_validation_runs        (with project_id, framework_version)
      ├── audit            → dq_audit_log              (with project_id, framework_version, trigger_ref)
      └── return summary via dbutils.notebook.exit(json.dumps(...))
            │
            ▼
ADF reads runOutput.should_block_publish, branches:
  - true  → halt downstream (notify, fail pipeline)
  - false → continue (Silver / Gold promotion)
```

## Per-project DQ settings (`dq_project_settings`)

| Column                  | Purpose                                                          |
|-------------------------|------------------------------------------------------------------|
| `project_id`            | FK → `ingest_platform.control.projects`                          |
| `dq_framework_version`  | Pinned per project — opt-in upgrades                             |
| `is_dq_enabled`         | Refuse runs for disabled projects                                |
| `block_publish_on_fail` | Whether FAIL runs gate downstream publish                        |
| `notification_channel`  | Override project's `alert_email` for DQ-specific routing         |
| `pagerduty_service`     | Override project default for DQ alerts                           |

## Severity → run status

| Any rule status | Run status |
|-----------------|------------|
| any ERROR       | ERROR      |
| any BLOCK fail  | FAIL       |
| any WARN fail   | WARN       |
| all pass        | PASS       |

`should_block_publish` is `True` only when status is FAIL/ERROR **and**
the project's `block_publish_on_fail = true`.

## Quick start

### 1. Confirm the Ingestion Framework has been bootstrapped

```sql
SELECT count(*) FROM ingest_platform.control.projects WHERE is_active = true;
```

If this fails or returns 0, deploy the Ingestion Framework first.

### 2. Bootstrap DQ tables

```bash
databricks sql -f ddl/01_create_tables.sql
```

### 3. Onboard projects to the DQ framework + seed rules

```bash
python -m dqf.jobs.seed_rules \
    --settings-json dqf/rules/sample_dq_settings.json \
    --rules-json    dqf/rules/sample_rules.json
```

### 4. Deploy the DQ notebook to Databricks

Upload `dqf/notebooks/run_dq_validation.py` to `/Shared/dq/notebooks/run_dq_validation`
in the Databricks workspace.

### 5. Generate per-project ADF pipelines

```bash
cd dqf/adf
mkdir -p generated
for code in finance marketing operations; do
    sed "s|\${projectCode}|$code|g" dq_standalone_pipeline_template.json \
        > generated/dq_pipeline_$code.json
    sed "s|\${projectCode}|$code|g" dq_standalone_trigger_template.json \
        > generated/trigger_dq_${code}_6h.json
done
```

Deploy generated artifacts via `az datafactory pipeline create-or-update`.

### 6. Run the multi-project smoke test (no Delta required)

```bash
PYTHONPATH=. python -m dqf.tests.test_engine_e2e
```

Expected: 13 assertions pass — finance/marketing run independently,
cross-project rule leak rejected, per-project `block_publish_on_fail`
honored.

## Onboarding a new project to DQ

1. **Project must exist in `ingest_platform.control.projects`** (managed by
   the Ingestion Framework).
2. **Add row to `dq_project_settings`**: pin `dq_framework_version`, decide
   `block_publish_on_fail`, set notifications.
3. **Author rules** through the React console (or seed JSON). Each rule
   carries `project_code`; the seed script resolves `project_id`.
4. **Submit for approval** through the workflow.
5. **Generate ADF artifacts** from templates (sed substitution).
6. **Deploy** to ADF; trigger goes live on schedule.
7. **(Optional)** Embed Pattern A inline activity in the Ingestion FW's
   per-project pipeline for inline gating.

No platform code changes per project.

## Tenant isolation guarantees

| Guarantee                           | How it's enforced                              |
|-------------------------------------|------------------------------------------------|
| Project must exist upstream         | `load_project()` queries Ingestion FW table   |
| Project must have opted in to DQ    | `load_project()` requires `dq_project_settings` row |
| Rule listing scoped per project     | `load_rules_from_delta(project)` filters by `project_id` |
| Engine refuses cross-project rules  | `ValidationEngine.run()` raises ValueError     |
| Persistence rows carry project_id   | Engine stamps `self.project.project_id`        |
| Tables physically partitioned       | DDL `PARTITIONED BY (project_id, ...)`         |
| RBAC per project                    | Unity Catalog row filters / view-per-project   |
| Per-project gating policy           | `block_publish_on_fail` honored at runtime    |
| Cross-framework lineage             | DQ run carries `trigger_ref = ADF pipeline().RunId` |
