# ADF templates

Azure Data Factory artifacts for the DQ framework. Two pipeline patterns,
one notebook entry point.

## Files

| File | Purpose |
|---|---|
| `dq_inline_activity.json` | **Pattern A — Inline DQ.** Drop-in Notebook Activity to embed in the Ingestion FW's per-project pipeline between Bronze and Silver. Includes a downstream `If Condition` example for branching on `should_block_publish`. |
| `dq_standalone_pipeline_template.json` | **Pattern B — Standalone DQ Pipeline.** One pipeline per project. Lookup `dq_project_settings` → DQ Notebook → Switch on status → notify Slack/PagerDuty. |
| `dq_standalone_trigger_template.json` | Schedule trigger for the standalone pipeline. Default 6 hours; customize per project's SLA. |

## Notebook contract

Both patterns invoke the same Databricks notebook:

```
/Shared/dq/notebooks/run_dq_validation
```

Source: `dqf/notebooks/run_dq_validation.py`. ADF Notebook Activity passes
parameters as `baseParameters`; the notebook calls `dbutils.notebook.exit(json.dumps(...))`
so ADF can read the run summary via `runOutput`.

### baseParameters (inputs)

| Parameter | Required | Description |
|---|---|---|
| `project_code` | yes | Resolved against `ingest_platform.control.projects` |
| `layer_filter` | no  | Comma-separated subset of `FILE,BUSINESS_RULE,POST_TRANSFORM` |
| `dataset_filter` | no | Comma-separated fully-qualified table names |
| `trigger_type` | yes | `INGEST_PIPELINE` (Pattern A) / `SCHEDULE` (Pattern B) / `API` |
| `trigger_ref` | yes | Pass `@{pipeline().RunId}` for cross-FW lineage |
| `env` | yes | `dev` / `test` / `prod` (from globalParameters) |

### runOutput (return value)

```json
{
  "run_id": "uuid",
  "project_id": 1,
  "project_code": "finance",
  "status": "PASS | WARN | FAIL | ERROR",
  "rules_evaluated": 42,
  "rules_passed": 40,
  "rules_warned": 1,
  "rules_failed": 1,
  "should_block_publish": false,
  "framework_version": "0.1.0"
}
```

Branch downstream activities on `@activity('DQ_Validation').output.runOutput.should_block_publish`.

## Generating per-project resources

The template files use `${projectCode}` as a literal placeholder. Generate
per-project copies via simple substitution:

```bash
sed 's|${projectCode}|finance|g' \
    dq_standalone_pipeline_template.json \
    > generated/dq_pipeline_finance.json

sed 's|${projectCode}|finance|g' \
    dq_standalone_trigger_template.json \
    > generated/trigger_dq_finance_6h.json
```

Deploy via `az datafactory pipeline create-or-update` or the REST API.

## Linked Services required (one-time, per ADF instance)

| Linked Service | Type | Purpose |
|---|---|---|
| `ls_databricks_workspace` | AzureDatabricks | Notebook activity target. PAT or managed identity. |
| `ls_databricks_delta` | AzureDatabricksDeltaLake | Lookup activity source for `dq_project_settings`. |
| `ls_keyvault` | AzureKeyVault | Backs the Databricks PAT, Slack webhook, PagerDuty key. |

## Global parameters required

| Parameter | Type | Example |
|---|---|---|
| `env` | string | `prod` |
| `alertWebhookUrl` | string | Slack/PagerDuty webhook |

## Onboarding a project to ADF (per-project)

1. Confirm project exists in `ingest_platform.control.projects` and has a
   row in `dq_project_settings` with `is_dq_enabled=true`.
2. Generate per-project pipeline + trigger from templates (sed substitution above).
3. Deploy generated artifacts to ADF.
4. Optionally add the `dq_inline_activity.json` Notebook Activity to the
   Ingestion FW's per-project pipeline if you want inline gating.
