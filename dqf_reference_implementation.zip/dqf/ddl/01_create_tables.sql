-- =============================================================================
-- Data Quality Framework — Control Tables (Multi-Project Platform Edition)
-- =============================================================================
-- The DQ framework REFERENCES the projects table owned by the Data Ingestion
-- Framework. DQ does NOT create or alter that table — it is owned upstream.
--
--   Owner / Source of truth: ingest_platform.control.projects
--                           (created and maintained by the ingestion framework)
--
-- The DQ framework keeps its own per-project settings in dq_project_settings
-- so we don't co-own the ingestion FW's schema. dq_project_settings is a
-- 1:1 sidecar keyed by project_id.
--
-- Every operational DQ table is scoped by project_id so that:
--   * Two projects can both have a rule named "BR_0142" without colliding
--   * RBAC can be granted per project (Unity Catalog row filters or views)
--   * One project's failed runs don't blast-radius another's dashboard
--   * Platform team can roll new framework versions per-project
--
-- Tables created by this DDL:
--   dq_platform.governance.dq_project_settings      — DQ-owned per-project settings
--   dq_platform.governance.dq_rules                 — rules, scoped by project_id
--   dq_platform.governance.dq_rule_versions         — rule history, scoped by project_id
--   dq_platform.governance.dq_validation_runs       — runs, scoped by project_id
--   dq_platform.governance.dq_validation_errors     — errors, scoped by project_id
--   dq_platform.governance.dq_audit_log             — audit, scoped by project_id
--   dq_platform.governance.dq_run_metrics           — metrics, scoped by project_id
--
-- Tables read by this framework but NOT created here:
--   ingest_platform.control.projects                 — owned by ingestion FW
-- =============================================================================

CREATE CATALOG IF NOT EXISTS dq_platform;
CREATE SCHEMA  IF NOT EXISTS dq_platform.governance;

-- -----------------------------------------------------------------------------
-- Sanity check: fail loudly if the ingestion framework's projects table
-- doesn't exist. The DQ framework cannot operate without it.
-- -----------------------------------------------------------------------------
-- (Run as a pre-flight check during deployment; surfaced via job exit code.)
-- SELECT 1 FROM ingest_platform.control.projects LIMIT 1;

-- -----------------------------------------------------------------------------
-- dq_project_settings — DQ-owned per-project settings (sidecar)
-- -----------------------------------------------------------------------------
-- A project must opt INTO the DQ framework by inserting a row here. Pinning
-- dq_framework_version per project means platform-team upgrades roll out
-- safely without forcing all tenants to upgrade in lockstep.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dq_platform.governance.dq_project_settings (
    project_id              BIGINT      NOT NULL,    -- FK -> ingest_platform.control.projects
    dq_framework_version    STRING      NOT NULL,
    is_dq_enabled           BOOLEAN     NOT NULL DEFAULT true,
    block_publish_on_fail   BOOLEAN     NOT NULL DEFAULT true,  -- gate downstream on BLOCK fails
    notification_channel    STRING,                 -- override project's alert_email if set
    pagerduty_service       STRING,                 -- override project default
    onboarded_ts            TIMESTAMP   NOT NULL,
    onboarded_by            STRING      NOT NULL,
    updated_ts              TIMESTAMP,
    updated_by              STRING
)
USING DELTA
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true',
               'delta.autoOptimize.optimizeWrite' = 'true');

-- =============================================================================
-- DQ TABLES — every table carries project_id (FK -> ingest_platform.control.projects)
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1. dq_rules — rule definitions, scoped by project
--    (project_id, rule_id, version) is the natural key.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dq_platform.governance.dq_rules (
    project_id        BIGINT      NOT NULL,    -- FK -> ingest_platform.control.projects
    rule_id           STRING      NOT NULL,
    version           INT         NOT NULL,
    name              STRING      NOT NULL,
    description       STRING,
    layer             STRING      NOT NULL,    -- FILE | BUSINESS_RULE | POST_TRANSFORM
    check_type        STRING      NOT NULL,
    severity          STRING      NOT NULL,    -- INFO | WARN | BLOCK
    datasets          ARRAY<STRING> NOT NULL,
    expression        STRING,
    params            MAP<STRING, STRING>,
    owner             STRING      NOT NULL,
    status            STRING      NOT NULL,    -- DRAFT | PENDING_APPROVAL | APPROVED | REJECTED | RETIRED
    enabled           BOOLEAN     NOT NULL DEFAULT true,
    effective_from    TIMESTAMP   NOT NULL,
    effective_to      TIMESTAMP,
    created_by        STRING      NOT NULL,
    created_ts        TIMESTAMP   NOT NULL,
    updated_by        STRING,
    updated_ts        TIMESTAMP
)
USING DELTA
PARTITIONED BY (project_id, layer)
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- -----------------------------------------------------------------------------
-- 2. dq_rule_versions — immutable rule history
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dq_platform.governance.dq_rule_versions (
    project_id        BIGINT      NOT NULL,
    rule_id           STRING      NOT NULL,
    version           INT         NOT NULL,
    prev_version      INT,
    diff_summary      STRING,
    change_reason     STRING,
    snapshot_json     STRING      NOT NULL,
    submitted_by      STRING      NOT NULL,
    submitted_ts      TIMESTAMP   NOT NULL,
    approved_by       STRING,
    approved_ts       TIMESTAMP,
    rejection_reason  STRING
)
USING DELTA
PARTITIONED BY (project_id)
TBLPROPERTIES ('delta.autoOptimize.optimizeWrite' = 'true');

-- -----------------------------------------------------------------------------
-- 3. dq_validation_runs — header for each run
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dq_platform.governance.dq_validation_runs (
    project_id        BIGINT      NOT NULL,
    run_id            STRING      NOT NULL,
    trigger_type      STRING      NOT NULL,
    trigger_ref       STRING,
    layer_filter      STRING,
    dataset_filter    STRING,
    started_ts        TIMESTAMP   NOT NULL,
    ended_ts          TIMESTAMP,
    status            STRING      NOT NULL,
    rules_evaluated   INT,
    rules_passed      INT,
    rules_warned      INT,
    rules_failed      INT,
    records_checked   BIGINT,
    spark_app_id      STRING,
    framework_version STRING,
    env               STRING,
    triggered_by      STRING,
    run_date          DATE        GENERATED ALWAYS AS (CAST(started_ts AS DATE))
)
USING DELTA
PARTITIONED BY (project_id, run_date)
TBLPROPERTIES ('delta.autoOptimize.optimizeWrite' = 'true');

-- -----------------------------------------------------------------------------
-- 4. dq_validation_errors — per-rule, per-run failure rows
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dq_platform.governance.dq_validation_errors (
    project_id        BIGINT      NOT NULL,
    error_id          STRING      NOT NULL,
    run_id            STRING      NOT NULL,
    rule_id           STRING      NOT NULL,
    rule_version      INT         NOT NULL,
    dataset           STRING      NOT NULL,
    record_pk         STRING,
    failed_value      STRING,
    expected          STRING,
    actual            STRING,
    severity          STRING      NOT NULL,
    sample_payload    STRING,
    captured_ts       TIMESTAMP   NOT NULL,
    captured_date     DATE        GENERATED ALWAYS AS (CAST(captured_ts AS DATE))
)
USING DELTA
PARTITIONED BY (project_id, captured_date)
TBLPROPERTIES ('delta.autoOptimize.optimizeWrite' = 'true');

-- -----------------------------------------------------------------------------
-- 5. dq_audit_log — UI / API config and approval actions
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dq_platform.governance.dq_audit_log (
    project_id        BIGINT      NOT NULL,
    audit_id          STRING      NOT NULL,
    actor             STRING      NOT NULL,
    role              STRING      NOT NULL,
    action            STRING      NOT NULL,
    entity_type       STRING      NOT NULL,
    entity_id         STRING      NOT NULL,
    before_json       STRING,
    after_json        STRING,
    reason            STRING,
    framework_version STRING,
    ip                STRING,
    user_agent        STRING,
    event_ts          TIMESTAMP   NOT NULL,
    event_date        DATE        GENERATED ALWAYS AS (CAST(event_ts AS DATE))
)
USING DELTA
PARTITIONED BY (project_id, event_date)
TBLPROPERTIES ('delta.autoOptimize.optimizeWrite' = 'true');

-- -----------------------------------------------------------------------------
-- 6. dq_run_metrics — aggregated metrics per (run, dataset, layer)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dq_platform.governance.dq_run_metrics (
    project_id        BIGINT      NOT NULL,
    run_id            STRING      NOT NULL,
    dataset           STRING      NOT NULL,
    layer             STRING      NOT NULL,
    rule_count        INT         NOT NULL,
    pass_count        INT         NOT NULL,
    warn_count        INT         NOT NULL,
    fail_count        INT         NOT NULL,
    pass_rate         DOUBLE,
    row_count         BIGINT,
    null_pct          DOUBLE,
    duration_sec      DOUBLE,
    captured_ts       TIMESTAMP   NOT NULL,
    captured_date     DATE        GENERATED ALWAYS AS (CAST(captured_ts AS DATE))
)
USING DELTA
PARTITIONED BY (project_id, captured_date)
TBLPROPERTIES ('delta.autoOptimize.optimizeWrite' = 'true');


-- =============================================================================
-- Convenience views — join across the integration boundary
-- =============================================================================

-- Active approved rules joined with project context from the ingestion FW table.
-- This view is the cross-framework integration point.
CREATE OR REPLACE VIEW dq_platform.governance.v_dq_rules_active AS
SELECT  p.project_code, p.project_name, p.default_catalog, r.*
FROM    dq_platform.governance.dq_rules r
JOIN    ingest_platform.control.projects p
        ON p.project_id = r.project_id
JOIN    dq_platform.governance.dq_project_settings s
        ON s.project_id = r.project_id
WHERE   r.status = 'APPROVED'
  AND   r.enabled = true
  AND   r.effective_to IS NULL
  AND   p.is_active = true
  AND   s.is_dq_enabled = true;

-- Per-project DQ health over the last 24h — powers the platform admin dashboard.
-- Joins ingestion FW's projects table for project metadata.
CREATE OR REPLACE VIEW dq_platform.governance.v_project_dq_health_24h AS
SELECT
    p.project_id,
    p.project_code,
    p.project_name,
    s.dq_framework_version,
    COUNT(r.run_id)                                                AS runs_24h,
    SUM(CASE WHEN r.status = 'PASS' THEN 1 ELSE 0 END)             AS runs_pass,
    SUM(CASE WHEN r.status = 'WARN' THEN 1 ELSE 0 END)             AS runs_warn,
    SUM(CASE WHEN r.status IN ('FAIL','ERROR') THEN 1 ELSE 0 END)  AS runs_fail,
    SUM(r.rules_failed)                                            AS total_rules_failed,
    SUM(r.records_checked)                                         AS total_records_checked,
    MAX(r.started_ts)                                              AS last_run_ts
FROM    ingest_platform.control.projects p
JOIN    dq_platform.governance.dq_project_settings s
        ON s.project_id = p.project_id
LEFT JOIN dq_platform.governance.dq_validation_runs r
        ON r.project_id = p.project_id
       AND r.started_ts >= current_timestamp() - INTERVAL 24 HOURS
WHERE   p.is_active = true
  AND   s.is_dq_enabled = true
GROUP BY p.project_id, p.project_code, p.project_name, s.dq_framework_version;
