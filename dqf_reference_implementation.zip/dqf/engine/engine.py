"""
Validation engine — the orchestrator (multi-project edition).

Implements the 7-step run lifecycle from the deck:
    1. Trigger
    2. Load active rules (scoped to one project)
    3. Plan execution
    4. Run checks (PySpark)
    5. Persist errors  -> dq_validation_errors  (with project_id)
    6. Decision gate
    7. Notify & audit  -> dq_audit_log         (with project_id)

All persistence rows include project_id (FK -> platform.control.projects) and
framework_version, consistent with the data ingestion framework.
"""
from __future__ import annotations

import json
import logging
import time
import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Callable, Iterable

from pyspark.sql import DataFrame, Row, SparkSession

from .check_result import CheckResult
from .checks import run_check
from .rule_model import DqProjectSettings, Project, Rule, load_rules_from_delta

log = logging.getLogger("dq.engine")

CATALOG = "dq_platform.governance"
T_RUNS = f"{CATALOG}.dq_validation_runs"
T_ERRORS = f"{CATALOG}.dq_validation_errors"
T_METRICS = f"{CATALOG}.dq_run_metrics"
T_AUDIT = f"{CATALOG}.dq_audit_log"

FRAMEWORK_VERSION = "0.1.0"

SourceResolver = Callable[[str], DataFrame]


def default_source_resolver(spark: SparkSession) -> SourceResolver:
    """Resolve a fully-qualified table name to a DataFrame via spark.table()."""
    return lambda name: spark.table(name)


@dataclass
class RunSummary:
    run_id: str
    project_id: int
    project_code: str
    status: str                 # PASS | WARN | FAIL | ERROR
    rules_evaluated: int
    rules_passed: int
    rules_warned: int
    rules_failed: int
    records_checked: int
    duration_sec: float
    framework_version: str
    results: list[CheckResult]
    block_publish_on_fail: bool = True  # from DqProjectSettings

    @property
    def should_block_publish(self) -> bool:
        """Block downstream publish only when this project opts in."""
        if not self.block_publish_on_fail:
            return False
        return self.status in ("FAIL", "ERROR")


class ValidationEngine:
    """Project-scoped validation engine.

    One engine instance is bound to one Project. Tenants are isolated by
    construction: the engine never sees rules or persists rows for another
    project.
    """

    def __init__(
        self,
        spark: SparkSession,
        project: Project,
        settings: DqProjectSettings | None = None,
        env: str = "dev",
        source_resolver: SourceResolver | None = None,
        persist: bool = True,
        notifier: Callable[[RunSummary], None] | None = None,
        framework_version: str | None = None,
    ):
        self.spark = spark
        self.project = project
        self.settings = settings
        self.env = env
        self.source_resolver = source_resolver or default_source_resolver(spark)
        self.persist = persist
        self.notifier = notifier
        # Prefer per-project pinned version from settings; fall back to caller
        # override; finally to the framework's compiled-in default.
        if settings and settings.dq_framework_version:
            self.framework_version = settings.dq_framework_version
        else:
            self.framework_version = framework_version or FRAMEWORK_VERSION

    # -------------------------------------------------------------------------
    # Public entry point
    # -------------------------------------------------------------------------
    def run(
        self,
        rules: list[Rule] | None = None,
        layers: Iterable[str] | None = None,
        datasets: Iterable[str] | None = None,
        trigger_type: str = "MANUAL",
        trigger_ref: str | None = None,
        triggered_by: str = "system",
    ) -> RunSummary:
        run_id = str(uuid.uuid4())
        started = datetime.utcnow()
        t0 = time.time()

        # Load rules if not provided. Always project-scoped.
        if rules is None:
            rules = load_rules_from_delta(self.spark, self.project,
                                          layers=layers, datasets=datasets)

        # Defensive: refuse rules from other projects
        bad = [r for r in rules if r.project_id != self.project.project_id]
        if bad:
            raise ValueError(
                f"Cross-project rule leak detected: {len(bad)} rule(s) belong to a "
                f"different project than {self.project.project_code}"
            )

        log.info("dq run %s [project=%s] starting — %d rules",
                 run_id, self.project.project_code, len(rules))

        # Insert RUNNING header row
        if self.persist:
            self._insert_run_header(run_id, started, trigger_type, trigger_ref,
                                    layers, datasets, triggered_by, len(rules))

        # Plan + execute. Group by primary dataset so each source DataFrame is
        # touched once per run (cache could be added here for hot datasets).
        results: list[CheckResult] = []
        by_dataset: dict[str, list[Rule]] = {}
        for r in rules:
            by_dataset.setdefault(r.primary_dataset, []).append(r)

        for dataset, dataset_rules in by_dataset.items():
            log.info("  dataset=%s rules=%d", dataset, len(dataset_rules))
            for rule in dataset_rules:
                res = run_check(self.spark, rule, self.source_resolver)
                log.info("    rule=%s status=%s failed=%d/%d duration=%.2fs",
                         rule.rule_id, res.effective_status,
                         res.records_failed, res.records_checked, res.duration_sec)
                results.append(res)

        # Persist errors + metrics
        if self.persist:
            self._persist_errors(run_id, results)
            self._persist_metrics(run_id, results)

        # Decision gate
        summary = self._summarize(run_id, results, time.time() - t0)

        # Update header + audit + notify
        if self.persist:
            self._finalize_run_header(run_id, summary)
            self._audit_run(run_id, summary, triggered_by, trigger_type)

        if self.notifier:
            try:
                self.notifier(summary)
            except Exception as e:
                log.warning("notifier failed: %s", e)

        log.info("dq run %s [project=%s] finished: %s (%d/%d passed, %d failed)",
                 run_id, self.project.project_code, summary.status,
                 summary.rules_passed, summary.rules_evaluated, summary.rules_failed)
        return summary

    # -------------------------------------------------------------------------
    # Persistence helpers — every row includes project_id + framework_version
    # -------------------------------------------------------------------------
    def _insert_run_header(self, run_id, started, trigger_type, trigger_ref,
                           layers, datasets, triggered_by, n_rules):
        row = Row(
            project_id=self.project.project_id,
            run_id=run_id,
            trigger_type=trigger_type,
            trigger_ref=trigger_ref,
            layer_filter=",".join(layers) if layers else None,
            dataset_filter=",".join(datasets) if datasets else None,
            started_ts=started,
            ended_ts=None,
            status="RUNNING",
            rules_evaluated=n_rules,
            rules_passed=None, rules_warned=None, rules_failed=None,
            records_checked=None,
            spark_app_id=self.spark.sparkContext.applicationId,
            framework_version=self.framework_version,
            env=self.env,
            triggered_by=triggered_by,
        )
        self.spark.createDataFrame([row]).write.mode("append").saveAsTable(T_RUNS)

    def _finalize_run_header(self, run_id, s: RunSummary):
        from delta.tables import DeltaTable
        tgt = DeltaTable.forName(self.spark, T_RUNS)
        upd = self.spark.createDataFrame([Row(
            project_id=self.project.project_id,
            run_id=run_id,
            ended_ts=datetime.utcnow(),
            status=s.status,
            rules_passed=s.rules_passed,
            rules_warned=s.rules_warned,
            rules_failed=s.rules_failed,
            records_checked=s.records_checked,
        )])
        # Match on (project_id, run_id) so the partition prune kicks in
        (tgt.alias("t").merge(upd.alias("u"),
                              "t.project_id = u.project_id AND t.run_id = u.run_id")
            .whenMatchedUpdate(set={
                "ended_ts": "u.ended_ts",
                "status": "u.status",
                "rules_passed": "u.rules_passed",
                "rules_warned": "u.rules_warned",
                "rules_failed": "u.rules_failed",
                "records_checked": "u.records_checked",
            })
            .execute())

    def _persist_errors(self, run_id: str, results: list[CheckResult]):
        rows = []
        now = datetime.utcnow()
        for r in results:
            if r.passed or not r.sample_failures:
                continue
            for sample in r.sample_failures:
                pk = sample.get("id") or sample.get(f"{r.rule.primary_dataset.split('.')[-1]}_id")
                rows.append(Row(
                    project_id=self.project.project_id,
                    error_id=str(uuid.uuid4()),
                    run_id=run_id,
                    rule_id=r.rule.rule_id,
                    rule_version=r.rule.version,
                    dataset=r.rule.primary_dataset,
                    record_pk=str(pk) if pk is not None else None,
                    failed_value=None,
                    expected=r.expected,
                    actual=r.actual,
                    severity=r.rule.severity.value,
                    sample_payload=json.dumps(sample)[:4000],
                    captured_ts=now,
                ))
        if rows:
            self.spark.createDataFrame(rows).write.mode("append").saveAsTable(T_ERRORS)

    def _persist_metrics(self, run_id: str, results: list[CheckResult]):
        agg: dict[tuple[str, str], dict] = {}
        for r in results:
            key = (r.rule.primary_dataset, r.rule.layer.value)
            a = agg.setdefault(key, {"rule": 0, "pass": 0, "warn": 0, "fail": 0,
                                     "rows": 0, "dur": 0.0})
            a["rule"] += 1
            a["dur"] += r.duration_sec
            a["rows"] = max(a["rows"], r.records_checked)
            st = r.effective_status
            if st == "PASS": a["pass"] += 1
            elif st == "WARN": a["warn"] += 1
            elif st in ("FAIL", "ERROR"): a["fail"] += 1

        now = datetime.utcnow()
        rows = []
        for (dataset, layer), v in agg.items():
            rows.append(Row(
                project_id=self.project.project_id,
                run_id=run_id, dataset=dataset, layer=layer,
                rule_count=v["rule"], pass_count=v["pass"],
                warn_count=v["warn"], fail_count=v["fail"],
                pass_rate=(v["pass"] / v["rule"] * 100.0) if v["rule"] else None,
                row_count=int(v["rows"]) if v["rows"] else None,
                null_pct=None,
                duration_sec=round(v["dur"], 4),
                captured_ts=now,
            ))
        if rows:
            self.spark.createDataFrame(rows).write.mode("append").saveAsTable(T_METRICS)

    def _audit_run(self, run_id, summary: RunSummary, actor: str, trigger_type: str):
        row = Row(
            project_id=self.project.project_id,
            audit_id=str(uuid.uuid4()),
            actor=actor, role="SYSTEM",
            action="RUN_TRIGGER",
            entity_type="RUN", entity_id=run_id,
            before_json=None,
            after_json=json.dumps({
                "status": summary.status,
                "rules_evaluated": summary.rules_evaluated,
                "rules_failed": summary.rules_failed,
            }),
            reason=f"trigger={trigger_type}",
            framework_version=self.framework_version,
            ip=None, user_agent=None,
            event_ts=datetime.utcnow(),
        )
        self.spark.createDataFrame([row]).write.mode("append").saveAsTable(T_AUDIT)

    # -------------------------------------------------------------------------
    # Decision gate
    # -------------------------------------------------------------------------
    def _summarize(self, run_id, results: list[CheckResult], duration: float) -> RunSummary:
        passed = warned = failed = 0
        records = 0
        for r in results:
            records += r.records_checked
            st = r.effective_status
            if st == "PASS":
                passed += 1
            elif st == "WARN":
                warned += 1
            elif st in ("FAIL", "ERROR"):
                failed += 1

        if any(r.error_message for r in results):
            status = "ERROR"
        elif any(r.effective_status == "FAIL" for r in results):
            status = "FAIL"
        elif any(r.effective_status == "WARN" for r in results):
            status = "WARN"
        else:
            status = "PASS"

        return RunSummary(
            run_id=run_id,
            project_id=self.project.project_id,
            project_code=self.project.project_code,
            status=status,
            rules_evaluated=len(results),
            rules_passed=passed, rules_warned=warned, rules_failed=failed,
            records_checked=records,
            duration_sec=round(duration, 4),
            framework_version=self.framework_version,
            results=results,
            block_publish_on_fail=self.settings.block_publish_on_fail if self.settings else True,
        )
