"""
Check implementations.

Each check_type maps to a function with the signature:

    fn(spark, rule, source_resolver) -> CheckResult

`source_resolver(table_name) -> DataFrame` lets us swap real Delta tables for
in-memory test DataFrames without changing the engine.

All checks are PySpark-native — joins are real Spark joins, aggregates run
distributed, and we cap collected sample rows for the errors table.
"""
from __future__ import annotations

import json
import time
from typing import Callable

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from .check_result import CheckResult
from .rule_model import CheckType, Rule

SourceResolver = Callable[[str], DataFrame]


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------
def _row_to_dict(row) -> dict:
    """Spark Row -> json-serializable dict, casting unfriendly types to str."""
    out = {}
    for k, v in row.asDict(recursive=True).items():
        try:
            json.dumps(v)
            out[k] = v
        except (TypeError, ValueError):
            out[k] = str(v)
    return out


def _collect_sample(df: DataFrame, n: int) -> list[dict]:
    return [_row_to_dict(r) for r in df.limit(n).collect()]


def _normalize_schema(schema_str: str) -> set[tuple[str, str]]:
    """
    Parse 'col:type,col:type' into a set of (name, type) tuples.

    Naively splitting on ',' breaks types like decimal(18,2). We respect
    parenthesis depth so commas inside parens stay attached to their type.

    Type aliases are normalized so 'long' and 'bigint' (etc.) compare equal.
    """
    aliases = {
        "long": "bigint",
        "short": "smallint",
        "byte": "tinyint",
        "int": "integer",
        "double": "double",
        "float": "float",
    }

    def norm_type(t: str) -> str:
        t = t.strip().lower()
        return aliases.get(t, t)

    parts = []
    depth = 0
    buf = []
    for ch in schema_str:
        if ch == "(":
            depth += 1
            buf.append(ch)
        elif ch == ")":
            depth -= 1
            buf.append(ch)
        elif ch == "," and depth == 0:
            parts.append("".join(buf))
            buf = []
        else:
            buf.append(ch)
    if buf:
        parts.append("".join(buf))

    out = set()
    for part in parts:
        part = part.strip()
        if not part:
            continue
        name, _, dtype = part.partition(":")
        out.add((name.strip().lower(), norm_type(dtype)))
    return out


# -----------------------------------------------------------------------------
# FILE / GENERIC checks
# -----------------------------------------------------------------------------
def check_schema(spark: SparkSession, rule: Rule, src: SourceResolver) -> CheckResult:
    df = src(rule.primary_dataset)
    expected = _normalize_schema(rule.params["expected_schema"])
    # Reuse the same normalizer on the actual side for fair comparison
    actual_str = ",".join(f"{f.name}:{f.dataType.simpleString()}" for f in df.schema.fields)
    actual = _normalize_schema(actual_str)

    missing = expected - actual
    extra = actual - expected
    passed = not missing and not extra
    return CheckResult(
        rule=rule, passed=passed, records_checked=0,
        records_failed=0 if passed else 1,
        expected=str(sorted(expected)),
        actual=str(sorted(actual)),
        sample_failures=[] if passed else [{"missing": list(missing), "extra": list(extra)}],
    )


def check_row_count_min(spark, rule, src) -> CheckResult:
    df = src(rule.primary_dataset)
    min_rows = int(rule.params.get("min_rows", "1"))
    cnt = df.count()
    passed = cnt >= min_rows
    return CheckResult(
        rule=rule, passed=passed, records_checked=cnt,
        records_failed=0 if passed else 1,
        expected=f">= {min_rows}", actual=str(cnt),
    )


def check_null_pct_max(spark, rule, src) -> CheckResult:
    df = src(rule.primary_dataset)
    col = rule.params["column"]
    max_pct = float(rule.params["max_null_pct"])

    total = df.count()
    if total == 0:
        return CheckResult(rule=rule, passed=True, records_checked=0,
                           expected=f"null_pct <= {max_pct}", actual="empty dataset")

    nulls = df.filter(F.col(col).isNull()).count()
    pct = (nulls / total) * 100.0
    passed = pct <= max_pct

    sample = []
    if not passed:
        sample = _collect_sample(df.filter(F.col(col).isNull()), rule.max_sample_rows)

    return CheckResult(
        rule=rule, passed=passed, records_checked=total,
        records_failed=nulls, failure_pct=pct,
        expected=f"null_pct <= {max_pct}%", actual=f"{pct:.4f}%",
        sample_failures=sample,
    )


def check_primary_key(spark, rule, src) -> CheckResult:
    df = src(rule.primary_dataset)
    keys = [k.strip() for k in rule.params["keys"].split(",")]

    # Null check
    null_filter = None
    for k in keys:
        cond = F.col(k).isNull()
        null_filter = cond if null_filter is None else (null_filter | cond)
    nulls = df.filter(null_filter).count() if null_filter is not None else 0

    # Duplicate check
    dups_df = (
        df.groupBy(*keys).count().filter(F.col("count") > 1)
    )
    dup_keys = dups_df.count()
    total = df.count()

    passed = nulls == 0 and dup_keys == 0
    sample = []
    if not passed:
        sample = _collect_sample(dups_df, rule.max_sample_rows)
    return CheckResult(
        rule=rule, passed=passed, records_checked=total,
        records_failed=nulls + dup_keys,
        expected="no nulls, no duplicates",
        actual=f"{nulls} null PKs, {dup_keys} duplicate keys",
        sample_failures=sample,
    )


def check_domain(spark, rule, src) -> CheckResult:
    df = src(rule.primary_dataset)
    col = rule.params["column"]
    allowed = [v.strip() for v in rule.params["allowed_values"].split(",")]

    bad = df.filter(~F.col(col).isin(allowed))
    fails = bad.count()
    total = df.count()
    passed = fails == 0
    return CheckResult(
        rule=rule, passed=passed, records_checked=total,
        records_failed=fails,
        failure_pct=(fails / total * 100.0) if total else 0.0,
        expected=f"{col} in {allowed}",
        actual=f"{fails} rows out of domain",
        sample_failures=_collect_sample(bad, rule.max_sample_rows) if not passed else [],
    )


def check_expression(spark, rule, src) -> CheckResult:
    """Free-form SQL boolean expression. Failing rows are those where it's false."""
    df = src(rule.primary_dataset)
    expr = rule.expression
    if not expr:
        return CheckResult(rule=rule, passed=False, error_message="EXPRESSION rule missing 'expression'")

    bad = df.filter(f"NOT ({expr})")
    fails = bad.count()
    total = df.count()
    passed = fails == 0
    return CheckResult(
        rule=rule, passed=passed, records_checked=total,
        records_failed=fails,
        failure_pct=(fails / total * 100.0) if total else 0.0,
        expected=expr, actual=f"{fails} violating rows",
        sample_failures=_collect_sample(bad, rule.max_sample_rows) if not passed else [],
    )


# -----------------------------------------------------------------------------
# BUSINESS RULES — cross-table
# -----------------------------------------------------------------------------
def check_referential_integrity(spark, rule, src) -> CheckResult:
    """
    LEFT_ANTI join: rows in left where key has no match in right.
    Tolerance: failure_pct must be <= tolerance_pct.
    """
    p = rule.params
    left = src(p["left_table"]).alias("L")
    right = src(p["right_table"]).alias("R")

    left_keys = [k.strip() for k in p["left_keys"].split(",")]
    right_keys = [k.strip() for k in p["right_keys"].split(",")]
    if len(left_keys) != len(right_keys):
        return CheckResult(rule=rule, passed=False,
                           error_message="left_keys / right_keys length mismatch")

    join_cond = None
    for lk, rk in zip(left_keys, right_keys):
        c = F.col(f"L.{lk}") == F.col(f"R.{rk}")
        join_cond = c if join_cond is None else (join_cond & c)

    orphans = left.join(right, join_cond, "left_anti")
    orphan_count = orphans.count()
    total = left.count()
    pct = (orphan_count / total * 100.0) if total else 0.0
    passed = pct <= rule.tolerance_pct

    return CheckResult(
        rule=rule, passed=passed, records_checked=total,
        records_failed=orphan_count, failure_pct=pct,
        expected=f"orphan_pct <= {rule.tolerance_pct}%",
        actual=f"{orphan_count} orphans ({pct:.4f}%)",
        sample_failures=_collect_sample(orphans, rule.max_sample_rows) if not passed else [],
    )


# -----------------------------------------------------------------------------
# POST-TRANSFORM checks
# -----------------------------------------------------------------------------
def check_aggregate_parity(spark, rule, src) -> CheckResult:
    """
    Compare a SQL aggregate on left_table to one on right_table.
    Tolerance: |left - right| / max(|right|, 1) * 100 <= tolerance_pct
    """
    p = rule.params
    left = src(p["left_table"])
    right = src(p["right_table"])
    flt = p.get("filter")
    if flt:
        left = left.filter(flt)
        right = right.filter(flt)

    left_val = left.selectExpr(f"{p['left_agg']} AS v").first()["v"]
    right_val = right.selectExpr(f"{p['right_agg']} AS v").first()["v"]

    lv = float(left_val or 0)
    rv = float(right_val or 0)
    denom = max(abs(rv), 1.0)
    diff_pct = abs(lv - rv) / denom * 100.0
    passed = diff_pct <= rule.tolerance_pct

    return CheckResult(
        rule=rule, passed=passed, records_checked=0,
        records_failed=0 if passed else 1, failure_pct=diff_pct,
        expected=f"|{p['left_agg']} - {p['right_agg']}| within {rule.tolerance_pct}%",
        actual=f"left={lv}, right={rv}, diff={diff_pct:.4f}%",
    )


def check_row_count_drift(spark, rule, src) -> CheckResult:
    """
    Compare today's row count to a prior snapshot stored in dq_run_metrics.
    Falls back to PASS if no prior snapshot exists (cold start).
    """
    p = rule.params
    df = src(rule.primary_dataset)
    today_cnt = df.count()
    max_drop = float(p["max_drop_pct"])

    try:
        prior_df = spark.table("dq_platform.governance.dq_run_metrics") \
            .filter(F.col("dataset") == rule.primary_dataset) \
            .orderBy(F.col("captured_ts").desc()) \
            .limit(1)
        prior = prior_df.first()
    except Exception:
        prior = None

    if not prior or not prior["row_count"]:
        return CheckResult(
            rule=rule, passed=True, records_checked=today_cnt,
            expected=f"drop <= {max_drop}%", actual="no prior snapshot — pass",
        )

    prior_cnt = int(prior["row_count"])
    drop_pct = (prior_cnt - today_cnt) / prior_cnt * 100.0 if prior_cnt else 0.0
    passed = drop_pct <= max_drop
    return CheckResult(
        rule=rule, passed=passed, records_checked=today_cnt,
        records_failed=0 if passed else 1, failure_pct=max(drop_pct, 0.0),
        expected=f"drop <= {max_drop}%",
        actual=f"prior={prior_cnt}, today={today_cnt}, drop={drop_pct:.2f}%",
    )


# -----------------------------------------------------------------------------
# Dispatch table
# -----------------------------------------------------------------------------
CHECK_DISPATCH: dict[CheckType, Callable] = {
    CheckType.SCHEMA: check_schema,
    CheckType.ROW_COUNT_MIN: check_row_count_min,
    CheckType.ROW_COUNT_DRIFT: check_row_count_drift,
    CheckType.NULL_PCT_MAX: check_null_pct_max,
    CheckType.PRIMARY_KEY: check_primary_key,
    CheckType.DOMAIN: check_domain,
    CheckType.EXPRESSION: check_expression,
    CheckType.REFERENTIAL_INTEGRITY: check_referential_integrity,
    CheckType.AGGREGATE_PARITY: check_aggregate_parity,
}


def run_check(spark: SparkSession, rule: Rule, src: SourceResolver) -> CheckResult:
    """Dispatch + timing + error capture wrapper."""
    fn = CHECK_DISPATCH.get(rule.check_type)
    if fn is None:
        return CheckResult(rule=rule, passed=False,
                           error_message=f"Unsupported check_type {rule.check_type}")

    start = time.time()
    try:
        result = fn(spark, rule, src)
    except Exception as e:
        result = CheckResult(rule=rule, passed=False, error_message=f"{type(e).__name__}: {e}")
    result.duration_sec = round(time.time() - start, 4)
    return result
