"""
Rule model — typed wrappers for projects, DQ settings, and rules.

The DQ framework REFERENCES ingest_platform.control.projects (owned by the
Data Ingestion Framework). It does NOT alter or own that table.

Per-project DQ behavior (framework version pinning, block-on-fail flag,
notification overrides) lives in dq_project_settings, owned by this framework.

Production code calls load_project(spark, project_code), which joins both
tables and returns a Project enriched with its DqProjectSettings.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Iterable


class Layer(str, Enum):
    FILE = "FILE"
    BUSINESS_RULE = "BUSINESS_RULE"
    POST_TRANSFORM = "POST_TRANSFORM"


class Severity(str, Enum):
    INFO = "INFO"
    WARN = "WARN"
    BLOCK = "BLOCK"


class CheckType(str, Enum):
    SCHEMA = "SCHEMA"
    ROW_COUNT_MIN = "ROW_COUNT_MIN"
    ROW_COUNT_DRIFT = "ROW_COUNT_DRIFT"
    NULL_PCT_MAX = "NULL_PCT_MAX"
    PRIMARY_KEY = "PRIMARY_KEY"
    DOMAIN = "DOMAIN"
    EXPRESSION = "EXPRESSION"
    REFERENTIAL_INTEGRITY = "REFERENTIAL_INTEGRITY"
    AGGREGATE_PARITY = "AGGREGATE_PARITY"


# -----------------------------------------------------------------------------
# Project — mirrors ingest_platform.control.projects (READ-ONLY for DQ FW)
# -----------------------------------------------------------------------------
@dataclass(frozen=True)
class Project:
    """A registered project, sourced from ingest_platform.control.projects.

    Owned by the Data Ingestion Framework. The DQ framework reads this table
    but does not write to it. Field set matches the ingestion framework's
    Project dataclass for consistency.
    """
    project_id: int
    project_code: str
    project_name: str
    default_catalog: str
    bronze_schema: str
    silver_schema: str
    gold_schema: str
    alert_email: str
    owner_team: str
    is_active: bool
    description: str | None = None
    default_secret_scope: str | None = None
    pagerduty_service: str | None = None
    cost_center: str | None = None
    framework_version: str | None = None  # ingestion FW's version pin

    # ----- helpers consistent with the ingestion framework -------------------
    def bronze_table_name(self, name: str) -> str:
        return f"{self.default_catalog}.{self.bronze_schema}.{name}"

    def silver_table_name(self, name: str) -> str:
        return f"{self.default_catalog}.{self.silver_schema}.{name}"

    def gold_table_name(self, name: str) -> str:
        return f"{self.default_catalog}.{self.gold_schema}.{name}"

    @classmethod
    def from_dict(cls, d: dict[str, Any], *, project_id: int = 0) -> "Project":
        return cls(
            project_id=int(d.get("project_id", project_id)),
            project_code=d["project_code"],
            project_name=d["project_name"],
            description=d.get("description"),
            default_catalog=d["default_catalog"],
            bronze_schema=d.get("bronze_schema", "bronze"),
            silver_schema=d.get("silver_schema", "silver"),
            gold_schema=d.get("gold_schema", "gold"),
            default_secret_scope=d.get("default_secret_scope"),
            alert_email=d["alert_email"],
            pagerduty_service=d.get("pagerduty_service"),
            owner_team=d["owner_team"],
            cost_center=d.get("cost_center"),
            framework_version=d.get("framework_version") or d.get("ingest_framework_version"),
            is_active=bool(d.get("is_active", True)),
        )


# -----------------------------------------------------------------------------
# DqProjectSettings — DQ-owned per-project settings
# -----------------------------------------------------------------------------
@dataclass(frozen=True)
class DqProjectSettings:
    """Per-project DQ settings. Sidecar to Project; owned by this framework."""
    project_id: int
    dq_framework_version: str
    is_dq_enabled: bool = True
    block_publish_on_fail: bool = True
    notification_channel: str | None = None
    pagerduty_service: str | None = None

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "DqProjectSettings":
        return cls(
            project_id=int(d["project_id"]),
            dq_framework_version=d["dq_framework_version"],
            is_dq_enabled=bool(d.get("is_dq_enabled", True)),
            block_publish_on_fail=bool(d.get("block_publish_on_fail", True)),
            notification_channel=d.get("notification_channel"),
            pagerduty_service=d.get("pagerduty_service"),
        )


# -----------------------------------------------------------------------------
# Rule
# -----------------------------------------------------------------------------
@dataclass(frozen=True)
class Rule:
    project_id: int
    project_code: str
    rule_id: str
    version: int
    name: str
    layer: Layer
    check_type: CheckType
    severity: Severity
    datasets: tuple[str, ...]
    owner: str
    status: str
    enabled: bool
    description: str | None = None
    expression: str | None = None
    params: dict[str, str] = field(default_factory=dict)

    @property
    def primary_dataset(self) -> str:
        return self.datasets[0]

    @property
    def tolerance_pct(self) -> float:
        return float(self.params.get("tolerance_pct", "0.0"))

    @property
    def max_sample_rows(self) -> int:
        return int(self.params.get("max_sample_rows", "100"))

    @classmethod
    def from_dict(cls, d: dict[str, Any], *, project: Project | None = None) -> "Rule":
        pid = d.get("project_id")
        pcode = d.get("project_code")
        if project is not None:
            if pid is None:
                pid = project.project_id
            if pcode is None:
                pcode = project.project_code
        if pid is None or pcode is None:
            raise ValueError(
                f"Rule {d.get('rule_id')} missing project_id/project_code "
                "and no Project supplied."
            )
        return cls(
            project_id=int(pid),
            project_code=pcode,
            rule_id=d["rule_id"],
            version=int(d["version"]),
            name=d["name"],
            description=d.get("description"),
            layer=Layer(d["layer"]),
            check_type=CheckType(d["check_type"]),
            severity=Severity(d["severity"]),
            datasets=tuple(d["datasets"]),
            expression=d.get("expression"),
            params={k: str(v) for k, v in (d.get("params") or {}).items()},
            owner=d["owner"],
            status=d["status"],
            enabled=bool(d.get("enabled", True)),
        )


# -----------------------------------------------------------------------------
# Loaders
# -----------------------------------------------------------------------------
# Default table locations:
#   Projects: ingest_platform.control.projects (owned by Ingestion FW)
#   Settings: dq_platform.governance.dq_project_settings (owned by DQ FW)
INGEST_PROJECTS_TABLE = "ingest_platform.control.projects"
DQ_SETTINGS_TABLE = "dq_platform.governance.dq_project_settings"
DQ_RULES_TABLE = "dq_platform.governance.dq_rules"


def load_projects_from_json(path: str | Path) -> dict[str, Project]:
    """Dev / test only. Project IDs auto-assigned 1..N."""
    raw = json.loads(Path(path).read_text())
    out: dict[str, Project] = {}
    for i, d in enumerate(raw, start=1):
        proj = Project.from_dict(d, project_id=i)
        out[proj.project_code] = proj
    return out


def load_dq_settings_from_json(path: str | Path,
                               projects: dict[str, Project]) -> dict[int, DqProjectSettings]:
    """Dev / test only. Loads DQ-owned per-project settings keyed by project_id."""
    raw = json.loads(Path(path).read_text())
    out: dict[int, DqProjectSettings] = {}
    for d in raw:
        pcode = d.get("project_code")
        if not pcode or pcode not in projects:
            raise ValueError(f"Setting references unknown project '{pcode}'")
        pid = projects[pcode].project_id
        d2 = dict(d, project_id=pid)
        out[pid] = DqProjectSettings.from_dict(d2)
    return out


def load_rules_from_json(path: str | Path,
                         projects: dict[str, Project],
                         project_code: str | None = None) -> list[Rule]:
    raw = json.loads(Path(path).read_text())
    rules: list[Rule] = []
    for d in raw:
        pcode = d.get("project_code")
        if not pcode:
            raise ValueError(f"Rule {d.get('rule_id')} missing project_code")
        if project_code and pcode != project_code:
            continue
        proj = projects.get(pcode)
        if proj is None:
            raise ValueError(f"Rule {d.get('rule_id')} references unknown project '{pcode}'")
        rules.append(Rule.from_dict(d, project=proj))
    return rules


def load_project(spark, project_code: str,
                 projects_table: str = INGEST_PROJECTS_TABLE,
                 settings_table: str = DQ_SETTINGS_TABLE) -> tuple[Project, DqProjectSettings]:
    """
    Resolve a project by its code, joining the Ingestion FW's projects table
    with this framework's dq_project_settings sidecar.

    Raises ValueError if the project is not registered in the ingestion FW
    table or has not been onboarded to the DQ framework.
    """
    df = (spark.table(projects_table)
          .filter(f"project_code = '{project_code}' AND is_active = true"))
    rows = df.collect()
    if not rows:
        raise ValueError(
            f"project '{project_code}' not found or not active in {projects_table}. "
            "Register the project via the Ingestion Framework before onboarding to DQ."
        )
    project = Project.from_dict(rows[0].asDict(recursive=True))

    sdf = spark.table(settings_table).filter(f"project_id = {project.project_id}")
    srows = sdf.collect()
    if not srows:
        raise ValueError(
            f"project '{project_code}' (id={project.project_id}) has no row in "
            f"{settings_table}. Run the DQ onboarding step to add it."
        )
    settings = DqProjectSettings.from_dict(srows[0].asDict(recursive=True))
    if not settings.is_dq_enabled:
        raise ValueError(f"project '{project_code}' has DQ disabled (is_dq_enabled=false)")

    return project, settings


def load_rules_from_delta(spark, project: Project,
                          table: str = DQ_RULES_TABLE,
                          layers: Iterable[str] | None = None,
                          datasets: Iterable[str] | None = None) -> list[Rule]:
    """Load currently active, approved rules for a single project."""
    df = (spark.table(table)
          .filter(f"project_id = {project.project_id}")
          .filter("status = 'APPROVED' AND enabled = true AND effective_to IS NULL"))
    if layers:
        df = df.filter(df.layer.isin(list(layers)))
    if datasets:
        from pyspark.sql.functions import array_intersect, array, lit, size
        wanted = array(*[lit(d) for d in datasets])
        df = df.filter(size(array_intersect(df.datasets, wanted)) > 0)

    rules: list[Rule] = []
    for row in df.collect():
        d = row.asDict(recursive=True)
        rules.append(Rule(
            project_id=project.project_id,
            project_code=project.project_code,
            rule_id=d["rule_id"],
            version=int(d["version"]),
            name=d["name"],
            description=d.get("description"),
            layer=Layer(d["layer"]),
            check_type=CheckType(d["check_type"]),
            severity=Severity(d["severity"]),
            datasets=tuple(d["datasets"]),
            expression=d.get("expression"),
            params=dict(d.get("params") or {}),
            owner=d["owner"],
            status=d["status"],
            enabled=bool(d["enabled"]),
        ))
    return rules
