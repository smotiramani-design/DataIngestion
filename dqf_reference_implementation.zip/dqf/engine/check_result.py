"""
CheckResult — uniform return type for every check.

The engine collects these, persists failures to dq_validation_errors,
aggregates pass/warn/fail counts into dq_run_metrics, and decides the
overall run status.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .rule_model import Rule, Severity


@dataclass
class CheckResult:
    rule: Rule
    passed: bool                          # did the rule pass overall?
    records_checked: int = 0              # how many rows were evaluated
    records_failed: int = 0               # how many failed
    failure_pct: float = 0.0              # records_failed / records_checked (0-100)
    duration_sec: float = 0.0
    expected: str | None = None           # human-readable expected
    actual: str | None = None             # human-readable actual
    sample_failures: list[dict[str, Any]] = field(default_factory=list)
    error_message: str | None = None      # set if the check itself errored

    @property
    def effective_status(self) -> str:
        """PASS, WARN, or FAIL — driven by severity."""
        if self.error_message:
            return "ERROR"
        if self.passed:
            return "PASS"
        if self.rule.severity == Severity.BLOCK:
            return "FAIL"
        if self.rule.severity == Severity.WARN:
            return "WARN"
        return "PASS"  # INFO failures are non-blocking
