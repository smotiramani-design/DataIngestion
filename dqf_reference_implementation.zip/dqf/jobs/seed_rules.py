"""
Seed dq_project_settings + dq_rules + dq_rule_versions from JSON.

The DQ framework does NOT seed ingest_platform.control.projects — that table
is owned by the Data Ingestion Framework and must be seeded via that
framework first. This script:

  1. Looks up project_id values by joining on project_code from the
     ingestion FW's projects table (read-only).
  2. Upserts dq_project_settings rows (DQ-owned).
  3. Upserts dq_rules + dq_rule_versions rows (DQ-owned).

Idempotent. Existing (project_id, rule_id, version) rows are skipped via MERGE.

Usage:
    python -m dqf.jobs.seed_rules \\
        --settings-json dqf/rules/sample_dq_settings.json \\
        --rules-json    dqf/rules/sample_rules.json
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

from pyspark.sql import Row, SparkSession


INGEST_PROJECTS_TABLE = "ingest_platform.control.projects"


def resolve_project_ids(spark: SparkSession, project_codes: set[str]) -> dict[str, int]:
    """Read project_id values from the Ingestion FW's projects table."""
    df = (spark.table(INGEST_PROJECTS_TABLE)
          .filter("is_active = true")
          .select("project_id", "project_code"))
    code_to_id: dict[str, int] = {r["project_code"]: r["project_id"] for r in df.collect()}

    missing = project_codes - set(code_to_id.keys())
    if missing:
        raise RuntimeError(
            f"Project(s) not found in {INGEST_PROJECTS_TABLE}: {sorted(missing)}. "
            "Register them via the Ingestion Framework's onboarding flow first."
        )
    return {c: code_to_id[c] for c in project_codes}


def seed_dq_settings(spark: SparkSession, settings_json: Path,
                     code_to_id: dict[str, int], actor: str = "seed-script"):
    settings = json.loads(settings_json.read_text())
    now = datetime.utcnow()

    rows = []
    for s in settings:
        pcode = s["project_code"]
        if pcode not in code_to_id:
            continue
        rows.append(Row(
            project_id=code_to_id[pcode],
            dq_framework_version=s["dq_framework_version"],
            is_dq_enabled=bool(s.get("is_dq_enabled", True)),
            block_publish_on_fail=bool(s.get("block_publish_on_fail", True)),
            notification_channel=s.get("notification_channel"),
            pagerduty_service=s.get("pagerduty_service"),
            onboarded_ts=now,
            onboarded_by=actor,
            updated_ts=now,
            updated_by=actor,
        ))

    target = "dq_platform.governance.dq_project_settings"
    src_df = spark.createDataFrame(rows)

    from delta.tables import DeltaTable
    (DeltaTable.forName(spark, target).alias("t")
        .merge(src_df.alias("s"), "t.project_id = s.project_id")
        .whenMatchedUpdate(set={
            "dq_framework_version": "s.dq_framework_version",
            "is_dq_enabled": "s.is_dq_enabled",
            "block_publish_on_fail": "s.block_publish_on_fail",
            "notification_channel": "s.notification_channel",
            "pagerduty_service": "s.pagerduty_service",
            "updated_ts": "s.updated_ts",
            "updated_by": "s.updated_by",
        })
        .whenNotMatchedInsertAll()
        .execute())

    print(f"Seeded {len(rows)} project settings into {target}")


def seed_rules(spark: SparkSession, rules_json: Path, code_to_id: dict[str, int]):
    rules = json.loads(rules_json.read_text())
    now = datetime.utcnow()

    rule_rows = []
    version_rows = []
    for r in rules:
        pcode = r["project_code"]
        if pcode not in code_to_id:
            raise ValueError(f"Rule {r['rule_id']} references unknown project '{pcode}'")
        pid = code_to_id[pcode]

        rule_rows.append(Row(
            project_id=pid,
            rule_id=r["rule_id"],
            version=int(r["version"]),
            name=r["name"],
            description=r.get("description"),
            layer=r["layer"],
            check_type=r["check_type"],
            severity=r["severity"],
            datasets=list(r["datasets"]),
            expression=r.get("expression"),
            params={k: str(v) for k, v in (r.get("params") or {}).items()},
            owner=r["owner"],
            status=r["status"],
            enabled=bool(r.get("enabled", True)),
            effective_from=now,
            effective_to=None,
            created_by="seed-script",
            created_ts=now,
            updated_by=None,
            updated_ts=None,
        ))
        version_rows.append(Row(
            project_id=pid,
            rule_id=r["rule_id"],
            version=int(r["version"]),
            prev_version=None,
            diff_summary="initial seed",
            change_reason="bootstrap",
            snapshot_json=json.dumps(r),
            submitted_by="seed-script",
            submitted_ts=now,
            approved_by="seed-script" if r["status"] == "APPROVED" else None,
            approved_ts=now if r["status"] == "APPROVED" else None,
            rejection_reason=None,
        ))

    rules_df = spark.createDataFrame(rule_rows)
    versions_df = spark.createDataFrame(version_rows)

    from delta.tables import DeltaTable
    target = "dq_platform.governance.dq_rules"
    target_ver = "dq_platform.governance.dq_rule_versions"

    (DeltaTable.forName(spark, target).alias("t")
        .merge(rules_df.alias("s"),
               "t.project_id = s.project_id AND t.rule_id = s.rule_id AND t.version = s.version")
        .whenNotMatchedInsertAll()
        .execute())

    (DeltaTable.forName(spark, target_ver).alias("t")
        .merge(versions_df.alias("s"),
               "t.project_id = s.project_id AND t.rule_id = s.rule_id AND t.version = s.version")
        .whenNotMatchedInsertAll()
        .execute())

    print(f"Seeded {len(rule_rows)} rules into {target}")


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--settings-json", type=Path, required=True)
    p.add_argument("--rules-json", type=Path, required=True)
    args = p.parse_args(argv)

    spark = SparkSession.builder.appName("dq.seed_rules").getOrCreate()

    # Collect all project codes referenced by either file
    settings = json.loads(args.settings_json.read_text())
    rules = json.loads(args.rules_json.read_text())
    codes = {s["project_code"] for s in settings} | {r["project_code"] for r in rules}

    code_to_id = resolve_project_ids(spark, codes)
    print(f"Resolved {len(code_to_id)} project_id values from {INGEST_PROJECTS_TABLE}")

    seed_dq_settings(spark, args.settings_json, code_to_id)
    seed_rules(spark, args.rules_json, code_to_id)


if __name__ == "__main__":
    sys.exit(main())
