"""
Databricks Workflow job: run all approved rules for a given project.

The --project flag is REQUIRED. The framework is multi-tenant; runs without
a project would have no scoping and could leak across tenants.

Usage:

    python -m dqf.jobs.run_validation \\
        --project finance \\
        --layer BUSINESS_RULE \\
        --dataset finance_data.silver.orders \\
        --env prod \\
        --fail-on-block

Project resolution flow:
    1. Read project from ingest_platform.control.projects (Ingestion FW table)
    2. Read DQ settings from dq_platform.governance.dq_project_settings
    3. Refuse if project not registered or DQ not enabled.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys

from pyspark.sql import SparkSession

from dqf.engine import (
    ValidationEngine, load_project, load_rules_from_delta,
)


def slack_notifier(webhook_url: str):
    import urllib.request

    def _notify(summary):
        if summary.status == "PASS":
            return
        payload = {
            "text": (f":warning: DQ run [{summary.project_code}] {summary.run_id} "
                     f"status={summary.status} "
                     f"failed={summary.rules_failed}/{summary.rules_evaluated}")
        }
        req = urllib.request.Request(
            webhook_url, data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
        )
        try:
            urllib.request.urlopen(req, timeout=5)
        except Exception as e:
            logging.warning("slack notify failed: %s", e)
    return _notify


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--project", required=True,
                   help="project_code from ingest_platform.control.projects")
    p.add_argument("--env", default="dev")
    p.add_argument("--layer", action="append",
                   choices=["FILE", "BUSINESS_RULE", "POST_TRANSFORM"])
    p.add_argument("--dataset", action="append")
    p.add_argument("--trigger-type", default="SCHEDULE",
                   help="MANUAL | SCHEDULE | INGEST_PIPELINE | API. "
                        "When called from ADF inline DQ, pass INGEST_PIPELINE.")
    p.add_argument("--trigger-ref", default=None,
                   help="Free-form reference. From ADF: pass @{pipeline().RunId} so "
                        "DQ runs are traceable back to the parent ADF pipeline run.")
    p.add_argument("--triggered-by", default="adf",
                   help="Actor name written to dq_audit_log (e.g. 'adf', 'airflow', 'user:akhil').")
    p.add_argument("--slack-webhook", default=None)
    p.add_argument("--fail-on-block", action="store_true",
                   help="Exit 1 if any BLOCK-severity rule fails AND project has "
                        "block_publish_on_fail=true. Per-project setting wins; "
                        "this flag only enables the gating behavior on the runner side.")
    args = p.parse_args(argv)

    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s :: %(message)s")

    spark = (SparkSession.builder
             .appName(f"dq.validation_runner.{args.project}")
             .getOrCreate())

    # Resolve project + DQ settings (joins ingest_platform.control.projects with
    # dq_platform.governance.dq_project_settings)
    try:
        project, settings = load_project(spark, args.project)
    except ValueError as e:
        logging.error("project resolution failed: %s", e)
        return 2

    logging.info("running for project=%s (id=%d, catalog=%s, dq_fw=%s, block_on_fail=%s)",
                 project.project_code, project.project_id, project.default_catalog,
                 settings.dq_framework_version, settings.block_publish_on_fail)

    rules = load_rules_from_delta(spark, project,
                                  layers=args.layer, datasets=args.dataset)
    if not rules:
        logging.warning("no active rules matched filters for project=%s", project.project_code)
        return 0

    notifier = slack_notifier(args.slack_webhook) if args.slack_webhook else None
    engine = ValidationEngine(spark, project, settings=settings,
                              env=args.env, notifier=notifier)
    summary = engine.run(
        rules=rules,
        layers=args.layer, datasets=args.dataset,
        trigger_type=args.trigger_type,
        trigger_ref=args.trigger_ref,
        triggered_by=args.triggered_by,
    )

    print(f"\n=== RUN [{summary.project_code}] {summary.run_id} :: {summary.status} ===")
    print(f"  rules: {summary.rules_passed} pass / {summary.rules_warned} warn / "
          f"{summary.rules_failed} fail / {summary.rules_evaluated} total")
    print(f"  duration: {summary.duration_sec:.2f}s   framework: {summary.framework_version}")
    print(f"  block_publish_on_fail: {summary.block_publish_on_fail}")

    if args.fail_on_block and summary.should_block_publish:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
