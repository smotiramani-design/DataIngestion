import clsx from "clsx";
import type { RunStatus, ErrorSeverity } from "@/lib/types";

const RUN_STYLES: Record<RunStatus, string> = {
  RUNNING: "bg-blue-100 text-blue-700",
  SUCCESS: "bg-emerald-100 text-emerald-700",
  FAILED:  "bg-rose-100 text-rose-700",
  PARTIAL: "bg-amber-100 text-amber-700",
};

const SEV_STYLES: Record<ErrorSeverity, string> = {
  WARN:  "bg-amber-100 text-amber-700",
  ERROR: "bg-rose-100 text-rose-700",
  FATAL: "bg-purple-100 text-purple-700",
};

export function RunStatusPill({ status }: { status: RunStatus }) {
  return (
    <span className={clsx("pill", RUN_STYLES[status])}>
      <span className="w-1.5 h-1.5 rounded-full bg-current" />
      {status.toLowerCase()}
    </span>
  );
}

export function SeverityPill({ severity }: { severity: ErrorSeverity }) {
  return (
    <span className={clsx("pill", SEV_STYLES[severity])}>
      {severity}
    </span>
  );
}

export function BoolPill({ value, on = "active", off = "paused" }: {
  value: boolean; on?: string; off?: string;
}) {
  return (
    <span className={clsx("pill", value
      ? "bg-emerald-100 text-emerald-700"
      : "bg-slate-200 text-slate-600")}>
      <span className="w-1.5 h-1.5 rounded-full bg-current" />
      {value ? on : off}
    </span>
  );
}
