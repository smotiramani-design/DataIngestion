import { useState } from "react";
import { NavLink, Outlet } from "react-router-dom";
import {
  LayoutDashboard, Settings, AlertTriangle, ListChecks, ShieldCheck,
  ChevronDown, Check, Building2,
} from "lucide-react";
import clsx from "clsx";

import { useProject } from "@/lib/projectContext";

const NAV = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/feeds",     label: "Feeds",     icon: Settings },
  { to: "/rules",     label: "DQ Rules",  icon: ShieldCheck },
  { to: "/errors",    label: "Errors",    icon: AlertTriangle },
  { to: "/audit",     label: "Audit Log", icon: ListChecks },
];

export default function Layout() {
  const useMock = (import.meta.env.VITE_USE_MOCK_DATA as string) === "true";
  const { projects, selected, setSelected, loading } = useProject();
  const [pickerOpen, setPickerOpen] = useState(false);

  return (
    <div className="flex h-full">
      {/* Sidebar */}
      <aside className="w-64 bg-navy text-white flex flex-col">
        <div className="px-5 py-5 border-b border-white/10">
          <div className="text-xs tracking-[0.2em] text-teal-300 font-semibold">
            INGEST PLATFORM
          </div>
          <div className="text-xs text-slate-400 mt-1">Operator Console</div>
        </div>

        {/* Project switcher */}
        <div className="relative px-3 pt-3 pb-2 border-b border-white/10">
          <div className="text-[10px] tracking-wider text-slate-400 font-semibold mb-1.5 px-2">
            PROJECT
          </div>
          <button
            onClick={() => setPickerOpen(!pickerOpen)}
            disabled={loading || projects.length === 0}
            className="w-full flex items-center gap-2 px-2.5 py-2 rounded-md bg-midnight hover:bg-white/10 transition-colors text-left disabled:opacity-50"
          >
            <Building2 className="w-4 h-4 text-teal-300 shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-white truncate">
                {selected?.project_name ?? (loading ? "Loading…" : "No project")}
              </div>
              {selected && (
                <div className="text-[10px] text-slate-400 font-mono truncate">
                  {selected.project_code} · {selected.default_catalog}
                </div>
              )}
            </div>
            <ChevronDown
              className={clsx(
                "w-4 h-4 text-slate-400 shrink-0 transition-transform",
                pickerOpen && "rotate-180",
              )}
            />
          </button>

          {pickerOpen && (
            <>
              {/* Click-outside to close */}
              <div
                className="fixed inset-0 z-10"
                onClick={() => setPickerOpen(false)}
              />
              <div className="absolute left-3 right-3 mt-1 bg-white rounded-md shadow-lg border border-slate-200 z-20 overflow-hidden">
                {projects.map((p) => (
                  <button
                    key={p.project_code}
                    onClick={() => {
                      setSelected(p);
                      setPickerOpen(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 hover:bg-slate-50 text-left"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-navy truncate">
                        {p.project_name}
                      </div>
                      <div className="text-[10px] text-slate-500 font-mono truncate">
                        {p.project_code} · {p.default_catalog}
                      </div>
                    </div>
                    {selected?.project_code === p.project_code && (
                      <Check className="w-4 h-4 text-teal shrink-0" />
                    )}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        <nav className="flex-1 py-3">
          {NAV.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                clsx(
                  "flex items-center gap-3 px-5 py-2.5 text-sm transition-colors",
                  isActive
                    ? "bg-midnight text-white border-l-2 border-teal-400 font-medium"
                    : "text-slate-300 hover:bg-white/5 border-l-2 border-transparent",
                )
              }
            >
              <Icon className="w-4 h-4" />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="px-5 py-3 border-t border-white/10 text-xs text-slate-400">
          {useMock ? (
            <span className="inline-flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
              Mock data mode
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              Connected
            </span>
          )}
        </div>
      </aside>

      <main className="flex-1 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}
