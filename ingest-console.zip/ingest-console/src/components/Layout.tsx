import { NavLink, Outlet } from "react-router-dom";
import {
  LayoutDashboard, Settings, AlertTriangle, ListChecks,
} from "lucide-react";
import clsx from "clsx";

const NAV = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/feeds",     label: "Feeds",     icon: Settings },
  { to: "/errors",    label: "Errors",    icon: AlertTriangle },
  { to: "/audit",     label: "Audit Log", icon: ListChecks },
];

export default function Layout() {
  const useMock = (import.meta.env.VITE_USE_MOCK_DATA as string) === "true";

  return (
    <div className="flex h-full">
      {/* Sidebar */}
      <aside className="w-56 bg-navy text-white flex flex-col">
        <div className="px-5 py-5 border-b border-white/10">
          <div className="text-xs tracking-[0.2em] text-teal-300 font-semibold">
            INGEST
          </div>
          <div className="text-xs text-slate-400 mt-1">Operator Console</div>
        </div>

        <nav className="flex-1 py-3">
          {NAV.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                clsx(
                  "flex items-center gap-3 px-5 py-2.5 text-sm transition-colors",
                  isActive
                    ? "bg-midnight text-white border-l-2 border-teal-400 font-medium"
                    : "text-slate-300 hover:bg-white/5 border-l-2 border-transparent",
                )
              }
            >
              <Icon className="w-4 h-4" />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="px-5 py-3 border-t border-white/10 text-xs text-slate-400">
          {useMock ? (
            <span className="inline-flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
              Mock data mode
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              Connected
            </span>
          )}
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}
