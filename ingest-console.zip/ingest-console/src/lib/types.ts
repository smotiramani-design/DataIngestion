/**
 * Type definitions mirroring the framework's control-table schemas.
 * Keep these in sync with sql/01_create_control_tables.sql.
 */

export type SourceType =
  | "API" | "RDBMS" | "JSON" | "EXCEL" | "CSV" | "DELIMITED" | "FIXED";

export type LoadMode = "FULL" | "INCREMENTAL" | "CDC" | "UPSERT";

export type RunStatus = "RUNNING" | "SUCCESS" | "FAILED" | "PARTIAL";

export type ErrorType = "SCHEMA" | "DQ" | "CONNECTIVITY" | "RUNTIME" | "CONFIG";

export type ErrorSeverity = "WARN" | "ERROR" | "FATAL";

export interface FeedConfig {
  feed_id: number;
  feed_name: string;
  source_type: SourceType;
  source_location: string;
  source_options: Record<string, string>;
  target_table: string;
  schema_definition: string | null;
  load_mode: LoadMode;
  watermark_column: string | null;
  schedule_cron: string | null;
  sla_minutes: number | null;
  owner: string;
  is_active: boolean;
  created_ts: string;
  updated_ts: string;
}

export interface AuditLogRow {
  run_id: string;
  feed_id: number;
  feed_name: string;          // joined from feed_config
  source_type: SourceType;    // joined from feed_config
  pipeline_id: string | null;
  start_ts: string;
  end_ts: string | null;
  status: RunStatus;
  source_record_count: number | null;
  bronze_count: number | null;
  silver_count: number | null;
  quarantine_count: number | null;
  reconciliation_status: string | null;
  duration_seconds: number | null;
  triggered_by: string;
  error_summary: string | null;
}

export interface ErrorLogRow {
  error_id: number;
  run_id: string;
  feed_id: number;
  feed_name: string;          // joined from feed_config
  error_ts: string;
  error_type: ErrorType;
  error_severity: ErrorSeverity;
  raw_record: string | null;
  expectation_name: string | null;
  error_message: string | null;
  stack_trace: string | null;
  resolved_flag: boolean;
  resolved_ts: string | null;
  resolved_by: string | null;
}

/** Top-of-page KPI summary, computed in a single query. */
export interface DashboardKpis {
  feeds_active: number;
  runs_24h: number;
  success_rate: number;        // 0..1
  quarantined_24h: number;
}

/** One bucket in the runs-by-hour stacked bar chart. */
export interface RunsByHourBucket {
  hour: string;                // "HH:00"
  success: number;
  failed: number;
  partial: number;
}
