/**
 * Type definitions mirroring the framework's control-table schemas.
 * Keep these in sync with sql/01_create_control_tables.sql.
 */

export type SourceType =
  | "API" | "RDBMS" | "JSON" | "EXCEL" | "CSV" | "DELIMITED" | "FIXED";

export type LoadMode = "FULL" | "INCREMENTAL" | "CDC" | "UPSERT";

export type RunStatus = "RUNNING" | "SUCCESS" | "FAILED" | "PARTIAL";

export type ErrorType = "SCHEMA" | "DQ" | "CONNECTIVITY" | "RUNTIME" | "CONFIG";

export type ErrorSeverity = "WARN" | "ERROR" | "FATAL";

export interface Project {
  project_id: number;
  project_code: string;
  project_name: string;
  description: string | null;
  default_catalog: string;
  bronze_schema: string;
  silver_schema: string;
  gold_schema: string;
  default_secret_scope: string | null;
  alert_email: string;
  pagerduty_service: string | null;
  framework_version: string;
  owner_team: string;
  cost_center: string | null;
  is_active: boolean;
}

export interface FeedConfig {
  feed_id: number;
  project_id: number;
  project_code?: string;        // joined for display
  feed_name: string;
  source_type: SourceType;
  source_location: string;
  source_options: Record<string, string>;
  target_table: string | null;
  schema_definition: string | null;
  load_mode: LoadMode;
  watermark_column: string | null;
  schedule_cron: string | null;
  sla_minutes: number | null;
  owner: string;
  is_active: boolean;
  created_ts: string;
  updated_ts: string;
}

export interface AuditLogRow {
  run_id: string;
  project_id: number;
  project_code?: string;        // joined for display
  feed_id: number;
  feed_name: string;
  source_type: SourceType;
  pipeline_id: string | null;
  start_ts: string;
  end_ts: string | null;
  status: RunStatus;
  source_record_count: number | null;
  bronze_count: number | null;
  silver_count: number | null;
  quarantine_count: number | null;
  reconciliation_status: string | null;
  duration_seconds: number | null;
  triggered_by: string;
  error_summary: string | null;
  framework_version: string | null;
}

export interface ErrorLogRow {
  error_id: number;
  project_id: number;
  project_code?: string;        // joined for display
  run_id: string;
  feed_id: number;
  feed_name: string;
  error_ts: string;
  error_type: ErrorType;
  error_severity: ErrorSeverity;
  raw_record: string | null;
  expectation_name: string | null;
  error_message: string | null;
  stack_trace: string | null;
  resolved_flag: boolean;
  resolved_ts: string | null;
  resolved_by: string | null;
}

export interface DashboardKpis {
  feeds_active: number;
  runs_24h: number;
  success_rate: number;
  quarantined_24h: number;
}

export interface RunsByHourBucket {
  hour: string;
  success: number;
  failed: number;
  partial: number;
}
