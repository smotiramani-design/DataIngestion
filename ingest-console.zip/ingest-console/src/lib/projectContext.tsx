/**
 * Project selection context — the currently active project, plus the list
 * of projects the user can switch to.
 *
 * In production, the project list comes from `getProjects()` filtered by
 * the user's group memberships (RBAC). For mock mode, every project is
 * visible.
 *
 * We persist the selected project in localStorage so it sticks across
 * page reloads.
 */

import { createContext, useContext, useState, useEffect, useMemo } from "react";
import type { ReactNode } from "react";
import type { Project } from "@/lib/types";
import { getProjects } from "@/api/queries";

const STORAGE_KEY = "ingest-console.selected-project";

interface ProjectContextValue {
  projects: Project[];
  selected: Project | null;
  setSelected: (p: Project) => void;
  loading: boolean;
}

const ProjectContext = createContext<ProjectContextValue | null>(null);

export function ProjectProvider({ children }: { children: ReactNode }) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCode, setSelectedCode] = useState<string | null>(() =>
    typeof window === "undefined" ? null : window.localStorage.getItem(STORAGE_KEY),
  );

  useEffect(() => {
    let cancelled = false;
    getProjects()
      .then((list) => {
        if (cancelled) return;
        setProjects(list);
        // If no selection or saved selection no longer exists, default to first
        const savedExists = selectedCode && list.some((p) => p.project_code === selectedCode);
        if (!savedExists && list.length > 0) {
          setSelectedCode(list[0].project_code);
          window.localStorage.setItem(STORAGE_KEY, list[0].project_code);
        }
      })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
    // Only run once on mount; we don't want to re-fetch when selection changes
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const selected = useMemo(
    () => projects.find((p) => p.project_code === selectedCode) ?? null,
    [projects, selectedCode],
  );

  const setSelected = (p: Project) => {
    setSelectedCode(p.project_code);
    window.localStorage.setItem(STORAGE_KEY, p.project_code);
  };

  return (
    <ProjectContext.Provider value={{ projects, selected, setSelected, loading }}>
      {children}
    </ProjectContext.Provider>
  );
}

export function useProject(): ProjectContextValue {
  const ctx = useContext(ProjectContext);
  if (!ctx) {
    throw new Error("useProject must be used inside ProjectProvider");
  }
  return ctx;
}
