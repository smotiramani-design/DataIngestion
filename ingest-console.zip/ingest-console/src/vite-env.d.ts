/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_DATABRICKS_HOST: string;
  readonly VITE_DATABRICKS_WAREHOUSE_ID: string;
  readonly VITE_DATABRICKS_TOKEN: string;
  readonly VITE_INGEST_CATALOG: string;
  readonly VITE_INGEST_CONTROL_SCHEMA: string;
  readonly VITE_USE_MOCK_DATA: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
