/**
 * Mock fixtures used when VITE_USE_MOCK_DATA=true.
 *
 * The shape mirrors what the real queries return — keeping these in lockstep
 * with src/api/queries.ts so the UI can't tell the difference.
 */

import type {
  AuditLogRow, ErrorLogRow, FeedConfig, DashboardKpis, RunsByHourBucket,
} from "@/lib/types";

const now = new Date();
const isoMinusMin = (m: number) => new Date(now.getTime() - m * 60_000).toISOString();
const isoMinusHr  = (h: number) => isoMinusMin(h * 60);

// ---------------------------------------------------------------------------
// Feeds
// ---------------------------------------------------------------------------
export const MOCK_FEEDS: FeedConfig[] = [
  {
    feed_id: 1, feed_name: "customers_api", source_type: "API",
    source_location: "https://api.example.com/v2/customers",
    source_options: { auth_type: "bearer", pagination: "cursor" },
    target_table: "ingest_platform.bronze.customers_api",
    schema_definition: null, load_mode: "INCREMENTAL",
    watermark_column: "updated_at", schedule_cron: "0 */15 * * * ?",
    sla_minutes: 15, owner: "customer-data-team@example.com", is_active: true,
    created_ts: "2026-01-15T10:00:00Z", updated_ts: "2026-04-20T14:32:00Z",
  },
  {
    feed_id: 2, feed_name: "orders_oracle", source_type: "RDBMS",
    source_location: "jdbc:oracle:thin:@//oracle-prod.example.com:1521/ORCL",
    source_options: { driver: "oracle.jdbc.OracleDriver", dbtable: "SALES.ORDERS" },
    target_table: "ingest_platform.bronze.orders_oracle",
    schema_definition: null, load_mode: "INCREMENTAL",
    watermark_column: "UPDATED_AT", schedule_cron: "0 0 */1 * * ?",
    sla_minutes: 60, owner: "sales-data-team@example.com", is_active: true,
    created_ts: "2026-01-12T09:00:00Z", updated_ts: "2026-04-22T11:00:00Z",
  },
  {
    feed_id: 3, feed_name: "product_dim_mssql", source_type: "RDBMS",
    source_location: "jdbc:sqlserver://mssql-prod.example.com:1433;database=Catalog",
    source_options: { driver: "com.microsoft.sqlserver.jdbc.SQLServerDriver" },
    target_table: "ingest_platform.bronze.product_dim",
    schema_definition: null, load_mode: "FULL", watermark_column: null,
    schedule_cron: "0 0 2 * * ?", sla_minutes: 240,
    owner: "catalog-team@example.com", is_active: true,
    created_ts: "2026-01-10T08:00:00Z", updated_ts: "2026-03-01T08:00:00Z",
  },
  {
    feed_id: 4, feed_name: "billing_events_json", source_type: "JSON",
    source_location: "abfss://landing@datalake.dfs.core.windows.net/billing/events/",
    source_options: { streaming: "true", multiline: "false" },
    target_table: "ingest_platform.bronze.billing_events",
    schema_definition: null, load_mode: "INCREMENTAL", watermark_column: null,
    schedule_cron: null, sla_minutes: 30,
    owner: "billing-team@example.com", is_active: true,
    created_ts: "2026-02-01T12:00:00Z", updated_ts: "2026-04-25T16:00:00Z",
  },
  {
    feed_id: 5, feed_name: "forecast_excel", source_type: "EXCEL",
    source_location: "abfss://landing@datalake.dfs.core.windows.net/finance/forecast/",
    source_options: { header: "true", infer_schema: "true" },
    target_table: "ingest_platform.bronze.forecast",
    schema_definition: null, load_mode: "FULL", watermark_column: null,
    schedule_cron: "0 0 6 * * MON", sla_minutes: 60,
    owner: "finance-team@example.com", is_active: true,
    created_ts: "2026-02-15T14:00:00Z", updated_ts: "2026-04-22T06:00:00Z",
  },
  {
    feed_id: 6, feed_name: "regional_sales_excel", source_type: "EXCEL",
    source_location: "abfss://landing@datalake.dfs.core.windows.net/sales/regional/",
    source_options: { sheets: "NorthAmerica,EMEA,APAC,LATAM", header: "true" },
    target_table: "ingest_platform.bronze.regional_sales",
    schema_definition: null, load_mode: "FULL", watermark_column: null,
    schedule_cron: "0 0 5 * * ?", sla_minutes: 120,
    owner: "sales-data-team@example.com", is_active: true,
    created_ts: "2026-03-01T10:00:00Z", updated_ts: "2026-04-20T05:00:00Z",
  },
  {
    feed_id: 7, feed_name: "transactions_csv", source_type: "CSV",
    source_location: "abfss://landing@datalake.dfs.core.windows.net/payments/",
    source_options: { streaming: "true", header: "true" },
    target_table: "ingest_platform.bronze.transactions",
    schema_definition: null, load_mode: "INCREMENTAL", watermark_column: null,
    schedule_cron: null, sla_minutes: 30,
    owner: "payments-team@example.com", is_active: true,
    created_ts: "2026-02-20T11:00:00Z", updated_ts: "2026-04-25T09:00:00Z",
  },
  {
    feed_id: 8, feed_name: "vendor_extract_pipe", source_type: "DELIMITED",
    source_location: "abfss://landing@datalake.dfs.core.windows.net/vendors/acme/",
    source_options: { delimiter: "|", header: "true" },
    target_table: "ingest_platform.bronze.vendor_acme",
    schema_definition: null, load_mode: "FULL", watermark_column: null,
    schedule_cron: "0 30 4 * * ?", sla_minutes: 60,
    owner: "vendor-ops@example.com", is_active: true,
    created_ts: "2026-03-10T13:00:00Z", updated_ts: "2026-04-21T04:30:00Z",
  },
  {
    feed_id: 9, feed_name: "ledger_fixed", source_type: "FIXED",
    source_location: "abfss://landing@datalake.dfs.core.windows.net/mainframe/ledger/",
    source_options: {},
    target_table: "ingest_platform.bronze.ledger",
    schema_definition: '{"fields":[{"name":"account_id","start":1,"length":12}]}',
    load_mode: "INCREMENTAL", watermark_column: null,
    schedule_cron: "0 0 3 * * ?", sla_minutes: 180,
    owner: "finance-ops@example.com", is_active: true,
    created_ts: "2026-03-15T15:00:00Z", updated_ts: "2026-04-22T03:00:00Z",
  },
  {
    feed_id: 10, feed_name: "deprecated_legacy_feed", source_type: "CSV",
    source_location: "abfss://archive@datalake.dfs.core.windows.net/legacy/",
    source_options: { header: "true" },
    target_table: "ingest_platform.bronze.legacy", schema_definition: null,
    load_mode: "FULL", watermark_column: null,
    schedule_cron: null, sla_minutes: null,
    owner: "data-archive@example.com", is_active: false,
    created_ts: "2025-08-01T10:00:00Z", updated_ts: "2026-01-15T10:00:00Z",
  },
];

// ---------------------------------------------------------------------------
// Audit log — last 24h of runs across feeds, deterministic-but-varied
// ---------------------------------------------------------------------------
function generateAuditRows(): AuditLogRow[] {
  const rows: AuditLogRow[] = [];
  const activeFeeds = MOCK_FEEDS.filter((f) => f.is_active);

  // For each active feed, generate ~6-12 runs spread over 24h
  activeFeeds.forEach((feed, idx) => {
    const runsForFeed = 6 + (idx % 4) * 2;
    for (let i = 0; i < runsForFeed; i++) {
      const minutesAgo = Math.floor((24 * 60 / runsForFeed) * i + (idx * 7) % 30);
      // Failure pattern: each feed has its own quirks
      const status = pickStatus(idx, i);
      const sourceCount = 1000 + ((idx * 31 + i * 17) % 9000);
      const quarantineCount = status === "PARTIAL" ? Math.floor(sourceCount * 0.04) : 0;
      const bronzeCount = status === "FAILED" ? null : sourceCount;
      const silverCount = status === "FAILED" ? null : sourceCount - quarantineCount;
      const duration = 30 + ((idx * 13 + i * 11) % 240);

      rows.push({
        run_id: `2026${String(now.getUTCMonth() + 1).padStart(2, "0")}${String(now.getUTCDate()).padStart(2, "0")}T${String(i).padStart(6, "0")}-${feed.feed_id}${i}`,
        feed_id: feed.feed_id,
        feed_name: feed.feed_name,
        source_type: feed.source_type,
        pipeline_id: null,
        start_ts: isoMinusMin(minutesAgo),
        end_ts: status === "RUNNING" ? null : isoMinusMin(Math.max(0, minutesAgo - duration / 60)),
        status,
        source_record_count: sourceCount,
        bronze_count: bronzeCount,
        silver_count: silverCount,
        quarantine_count: quarantineCount,
        reconciliation_status: status === "FAILED" ? "FAIL" : status === "PARTIAL" ? "FAIL" : "PASS",
        duration_seconds: status === "RUNNING" ? null : duration,
        triggered_by: "schedule",
        error_summary: status === "FAILED"
          ? "Connection refused: oracle-prod.example.com:1521 (connect timeout)"
          : null,
      });
    }
  });

  return rows.sort((a, b) => b.start_ts.localeCompare(a.start_ts));
}

function pickStatus(feedIdx: number, runIdx: number): AuditLogRow["status"] {
  // Feed 4 has a chronic DQ issue (PARTIAL), feed 9 is currently failing
  if (feedIdx === 3 && runIdx % 3 === 1) return "PARTIAL";
  if (feedIdx === 8 && runIdx === 0) return "FAILED";
  if (feedIdx === 1 && runIdx === 0) return "RUNNING";
  if ((feedIdx + runIdx) % 19 === 7) return "FAILED";
  if ((feedIdx + runIdx) % 11 === 3) return "PARTIAL";
  return "SUCCESS";
}

export const MOCK_AUDIT: AuditLogRow[] = generateAuditRows();

// ---------------------------------------------------------------------------
// Errors — open + recently resolved
// ---------------------------------------------------------------------------
export const MOCK_ERRORS: ErrorLogRow[] = [
  {
    error_id: 1001, run_id: MOCK_AUDIT[0].run_id, feed_id: 9,
    feed_name: "ledger_fixed", error_ts: isoMinusMin(12),
    error_type: "CONNECTIVITY", error_severity: "FATAL",
    raw_record: null, expectation_name: null,
    error_message: "ADLS path unavailable: 401 Unauthorized — service principal token expired",
    stack_trace: "azure.core.exceptions.ClientAuthenticationError: ...",
    resolved_flag: false, resolved_ts: null, resolved_by: null,
  },
  {
    error_id: 1002, run_id: "20260426T120000-4-3", feed_id: 4,
    feed_name: "billing_events_json", error_ts: isoMinusMin(45),
    error_type: "DQ", error_severity: "WARN",
    raw_record: '{"event_id":"evt_472","amount":-50.00,"currency":"USD","ts":"2026-04-26T11:14:00Z"}',
    expectation_name: "valid_amount",
    error_message: "Failed expectation: amount >= 0",
    stack_trace: null,
    resolved_flag: false, resolved_ts: null, resolved_by: null,
  },
  {
    error_id: 1003, run_id: "20260426T120000-4-3", feed_id: 4,
    feed_name: "billing_events_json", error_ts: isoMinusMin(46),
    error_type: "DQ", error_severity: "WARN",
    raw_record: '{"event_id":"evt_473","amount":null,"currency":"USD","ts":"2026-04-26T11:14:00Z"}',
    expectation_name: "non_null_amount",
    error_message: "Failed expectation: amount IS NOT NULL",
    stack_trace: null,
    resolved_flag: false, resolved_ts: null, resolved_by: null,
  },
  {
    error_id: 1004, run_id: "20260426T080000-2-2", feed_id: 2,
    feed_name: "orders_oracle", error_ts: isoMinusHr(3),
    error_type: "SCHEMA", error_severity: "ERROR",
    raw_record: null, expectation_name: null,
    error_message: "New column SALES.ORDERS.PROMO_CODE detected; mergeSchema=true added it to Bronze",
    stack_trace: null,
    resolved_flag: true, resolved_ts: isoMinusHr(2), resolved_by: "alice@example.com",
  },
  {
    error_id: 1005, run_id: "20260425T220000-7-1", feed_id: 7,
    feed_name: "transactions_csv", error_ts: isoMinusHr(15),
    error_type: "RUNTIME", error_severity: "ERROR",
    raw_record: null, expectation_name: null,
    error_message: "Reconciliation FAIL: source=8755, bronze=8754",
    stack_trace: null,
    resolved_flag: true, resolved_ts: isoMinusHr(14),
    resolved_by: "bob@example.com",
  },
];

// ---------------------------------------------------------------------------
// KPI summary
// ---------------------------------------------------------------------------
export function mockKpis(): DashboardKpis {
  const last24 = MOCK_AUDIT;
  const success = last24.filter((r) => r.status === "SUCCESS").length;
  const total = last24.filter((r) => r.status !== "RUNNING").length;
  return {
    feeds_active: MOCK_FEEDS.filter((f) => f.is_active).length,
    runs_24h: last24.length,
    success_rate: total > 0 ? success / total : 0,
    quarantined_24h: last24.reduce((s, r) => s + (r.quarantine_count ?? 0), 0),
  };
}

// ---------------------------------------------------------------------------
// Runs-by-hour stacked bar
// ---------------------------------------------------------------------------
export function mockRunsByHour(): RunsByHourBucket[] {
  const buckets: Record<string, RunsByHourBucket> = {};
  for (let h = 0; h < 24; h++) {
    const label = `${String(h).padStart(2, "0")}:00`;
    buckets[label] = { hour: label, success: 0, failed: 0, partial: 0 };
  }
  MOCK_AUDIT.forEach((row) => {
    const hr = new Date(row.start_ts).getHours();
    const key = `${String(hr).padStart(2, "0")}:00`;
    if (row.status === "SUCCESS") buckets[key].success++;
    else if (row.status === "FAILED") buckets[key].failed++;
    else if (row.status === "PARTIAL") buckets[key].partial++;
  });
  return Object.values(buckets);
}
