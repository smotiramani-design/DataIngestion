/**
 * Mock fixtures for the multi-project console (used when VITE_USE_MOCK_DATA=true).
 *
 * Three projects (finance, marketing, operations) with feeds, audit rows,
 * and errors distributed across them. Each project's data is independent —
 * filters scope correctly without bleed-through.
 */

import type {
  AuditLogRow, ErrorLogRow, FeedConfig, DashboardKpis, RunsByHourBucket, Project,
} from "@/lib/types";

const now = new Date();
const isoMinusMin = (m: number) => new Date(now.getTime() - m * 60_000).toISOString();
const isoMinusHr  = (h: number) => isoMinusMin(h * 60);

// ---------------------------------------------------------------------------
// Projects
// ---------------------------------------------------------------------------
export const MOCK_PROJECTS: Project[] = [
  {
    project_id: 1, project_code: "finance", project_name: "Finance Data Platform",
    description: "GL, AP/AR, treasury, and forecasting feeds.",
    default_catalog: "finance_data",
    bronze_schema: "bronze", silver_schema: "silver", gold_schema: "gold",
    default_secret_scope: "finance-ingest",
    alert_email: "finance-data-eng@example.com",
    pagerduty_service: "finance-data-platform",
    framework_version: "0.1.0",
    owner_team: "finance-data-eng", cost_center: "CC-1001", is_active: true,
  },
  {
    project_id: 2, project_code: "marketing", project_name: "Marketing Analytics",
    description: "Customer engagement, campaign attribution, CDP feeds.",
    default_catalog: "marketing_data",
    bronze_schema: "bronze", silver_schema: "silver", gold_schema: "gold",
    default_secret_scope: "marketing-ingest",
    alert_email: "mktg-analytics@example.com",
    pagerduty_service: null,
    framework_version: "0.1.0",
    owner_team: "marketing-analytics", cost_center: "CC-2003", is_active: true,
  },
  {
    project_id: 3, project_code: "operations", project_name: "Operations Data",
    description: "Supply chain, mainframe ledgers, operational reporting.",
    default_catalog: "operations_data",
    bronze_schema: "bronze", silver_schema: "silver", gold_schema: "gold",
    default_secret_scope: "ops-ingest",
    alert_email: "ops-platform@example.com",
    pagerduty_service: "ops-data-platform",
    framework_version: "0.1.0",
    owner_team: "ops-platform", cost_center: "CC-3007", is_active: true,
  },
];

// ---------------------------------------------------------------------------
// Feeds — each scoped to a project
// ---------------------------------------------------------------------------
export const MOCK_FEEDS: FeedConfig[] = [
  // Finance
  feed(1, 1, "finance", "gl_journal_oracle",   "RDBMS", "finance_data.bronze.gl_journal_oracle", "INCREMENTAL", "POSTED_AT", 60),
  feed(2, 1, "finance", "ap_invoices_oracle",  "RDBMS", "finance_data.bronze.ap_invoices_oracle", "INCREMENTAL", "UPDATED_AT", 60),
  feed(3, 1, "finance", "vendor_extract_acme", "DELIMITED", null, "FULL", null, 60),
  feed(4, 1, "finance", "forecast_workbook",   "EXCEL", null, "FULL", null, 60),
  feed(5, 1, "finance", "treasury_positions",  "API", null, "INCREMENTAL", "as_of_ts", 30),

  // Marketing
  feed(10, 2, "marketing", "cdp_customers",      "API", null, "INCREMENTAL", "updated_at", 30),
  feed(11, 2, "marketing", "campaign_events",    "JSON", null, "INCREMENTAL", null, 30),
  feed(12, 2, "marketing", "regional_sales",     "EXCEL", null, "FULL", null, 120),
  feed(13, 2, "marketing", "attribution_pixels", "CSV", null, "INCREMENTAL", null, 30),

  // Operations
  feed(20, 3, "operations", "mainframe_ledger",        "FIXED", null, "INCREMENTAL", null, 180),
  feed(21, 3, "operations", "inventory_snapshot_mssql","RDBMS", null, "FULL", null, 240),
  feed(22, 3, "operations", "transactions_csv",        "CSV", null, "INCREMENTAL", null, 30),
  feed(23, 3, "operations", "warehouse_events_json",   "JSON", null, "INCREMENTAL", null, 30),
  feed(24, 3, "operations", "shipping_extracts",       "DELIMITED", null, "FULL", null, 90),
  feed(25, 3, "operations", "deprecated_legacy_feed",  "CSV", null, "FULL", null, null, false),
];

function feed(
  feed_id: number, project_id: number, project_code: string,
  feed_name: string, source_type: FeedConfig["source_type"],
  target_table: string | null, load_mode: FeedConfig["load_mode"],
  watermark_column: string | null, sla_minutes: number | null,
  is_active: boolean = true,
): FeedConfig {
  const proj = MOCK_PROJECTS.find((p) => p.project_code === project_code)!;
  const opts: Record<string, string> = {};
  if (source_type === "RDBMS") opts.driver = "oracle.jdbc.OracleDriver";
  if (source_type === "API")   opts.auth_type = "bearer";
  if (source_type === "EXCEL") opts.header = "true";
  if (source_type === "CSV" || source_type === "DELIMITED") opts.header = "true";
  if (source_type === "JSON")  opts.streaming = "true";

  return {
    feed_id, project_id, project_code, feed_name, source_type,
    source_location: source_type === "API"
      ? `https://api.example.com/${feed_name}`
      : `abfss://landing@${proj.default_catalog}.dfs.core.windows.net/${feed_name}/`,
    source_options: opts,
    target_table,
    schema_definition: null,
    load_mode,
    watermark_column,
    schedule_cron: load_mode === "INCREMENTAL" ? "0 0 */1 * * ?" : "0 0 2 * * ?",
    sla_minutes,
    owner: proj.alert_email,
    is_active,
    created_ts: "2026-01-15T10:00:00Z",
    updated_ts: isoMinusHr(24 + (feed_id % 168)),
  };
}

// ---------------------------------------------------------------------------
// Audit log — generated runs across all projects
// ---------------------------------------------------------------------------
function generateAuditRows(): AuditLogRow[] {
  const rows: AuditLogRow[] = [];
  const activeFeeds = MOCK_FEEDS.filter((f) => f.is_active);

  activeFeeds.forEach((feed, idx) => {
    const runsForFeed = 6 + (idx % 4) * 2;
    for (let i = 0; i < runsForFeed; i++) {
      const minutesAgo = Math.floor((24 * 60 / runsForFeed) * i + (idx * 7) % 30);
      const status = pickStatus(idx, i);
      const sourceCount = 1000 + ((idx * 31 + i * 17) % 9000);
      const quarantineCount = status === "PARTIAL" ? Math.floor(sourceCount * 0.04) : 0;
      const bronzeCount = status === "FAILED" ? null : sourceCount;
      const silverCount = status === "FAILED" ? null : sourceCount - quarantineCount;
      const duration = 30 + ((idx * 13 + i * 11) % 240);

      rows.push({
        run_id: `2026${String(now.getUTCMonth() + 1).padStart(2, "0")}${String(now.getUTCDate()).padStart(2, "0")}T${String(i).padStart(6, "0")}-${feed.feed_id}${i}`,
        project_id: feed.project_id,
        project_code: feed.project_code,
        feed_id: feed.feed_id,
        feed_name: feed.feed_name,
        source_type: feed.source_type,
        pipeline_id: null,
        start_ts: isoMinusMin(minutesAgo),
        end_ts: status === "RUNNING" ? null : isoMinusMin(Math.max(0, minutesAgo - duration / 60)),
        status,
        source_record_count: sourceCount,
        bronze_count: bronzeCount,
        silver_count: silverCount,
        quarantine_count: quarantineCount,
        reconciliation_status: status === "FAILED" ? "FAIL" : status === "PARTIAL" ? "FAIL" : "PASS",
        duration_seconds: status === "RUNNING" ? null : duration,
        triggered_by: "schedule",
        error_summary: status === "FAILED"
          ? "Connection refused: source endpoint unreachable (connect timeout)"
          : null,
        framework_version: "0.1.0",
      });
    }
  });

  return rows.sort((a, b) => b.start_ts.localeCompare(a.start_ts));
}

function pickStatus(feedIdx: number, runIdx: number): AuditLogRow["status"] {
  if (feedIdx === 6 && runIdx % 3 === 1) return "PARTIAL";
  if (feedIdx === 9 && runIdx === 0) return "FAILED";
  if (feedIdx === 1 && runIdx === 0) return "RUNNING";
  if ((feedIdx + runIdx) % 19 === 7) return "FAILED";
  if ((feedIdx + runIdx) % 11 === 3) return "PARTIAL";
  return "SUCCESS";
}

export const MOCK_AUDIT: AuditLogRow[] = generateAuditRows();

// ---------------------------------------------------------------------------
// Errors — open + recently resolved, distributed across projects
// ---------------------------------------------------------------------------
export const MOCK_ERRORS: ErrorLogRow[] = [
  {
    error_id: 1001, project_id: 3, project_code: "operations",
    run_id: MOCK_AUDIT[0].run_id, feed_id: 20,
    feed_name: "mainframe_ledger", error_ts: isoMinusMin(12),
    error_type: "CONNECTIVITY", error_severity: "FATAL",
    raw_record: null, rule_name: null,
    error_message: "ADLS path unavailable: 401 Unauthorized — service principal token expired",
    stack_trace: "azure.core.exceptions.ClientAuthenticationError: ...",
    resolved_flag: false, resolved_ts: null, resolved_by: null,
  },
  {
    error_id: 1002, project_id: 2, project_code: "marketing",
    run_id: "20260426T120000-11-3", feed_id: 11,
    feed_name: "campaign_events", error_ts: isoMinusMin(45),
    error_type: "DQ", error_severity: "WARN",
    raw_record: '{"event_id":"evt_472","amount":-50.00,"currency":"USD","ts":"2026-04-26T11:14:00Z"}',
    rule_name: "valid_amount",
    error_message: "Failed rule: amount >= 0",
    stack_trace: null,
    resolved_flag: false, resolved_ts: null, resolved_by: null,
  },
  {
    error_id: 1003, project_id: 2, project_code: "marketing",
    run_id: "20260426T120000-11-3", feed_id: 11,
    feed_name: "campaign_events", error_ts: isoMinusMin(46),
    error_type: "DQ", error_severity: "WARN",
    raw_record: '{"event_id":"evt_473","amount":null,"currency":"USD","ts":"2026-04-26T11:14:00Z"}',
    rule_name: "non_null_amount",
    error_message: "Failed rule: amount IS NOT NULL",
    stack_trace: null,
    resolved_flag: false, resolved_ts: null, resolved_by: null,
  },
  {
    error_id: 1004, project_id: 1, project_code: "finance",
    run_id: "20260426T080000-1-2", feed_id: 1,
    feed_name: "gl_journal_oracle", error_ts: isoMinusHr(3),
    error_type: "SCHEMA", error_severity: "ERROR",
    raw_record: null, rule_name: null,
    error_message: "New column GL.JOURNAL_ENTRIES.PROMO_CODE detected; mergeSchema=true added it to Bronze",
    stack_trace: null,
    resolved_flag: true, resolved_ts: isoMinusHr(2),
    resolved_by: "alice@example.com",
  },
  {
    error_id: 1005, project_id: 3, project_code: "operations",
    run_id: "20260425T220000-22-1", feed_id: 22,
    feed_name: "transactions_csv", error_ts: isoMinusHr(15),
    error_type: "RUNTIME", error_severity: "ERROR",
    raw_record: null, rule_name: null,
    error_message: "Reconciliation FAIL: source=8755, bronze=8754",
    stack_trace: null,
    resolved_flag: true, resolved_ts: isoMinusHr(14),
    resolved_by: "bob@example.com",
  },
];

// ---------------------------------------------------------------------------
// Project-scoped aggregations
// ---------------------------------------------------------------------------
export function mockKpis(projectCode: string): DashboardKpis {
  const audit = MOCK_AUDIT.filter((r) => r.project_code === projectCode);
  const feeds = MOCK_FEEDS.filter((f) => f.project_code === projectCode);
  const success = audit.filter((r) => r.status === "SUCCESS").length;
  const total = audit.filter((r) => r.status !== "RUNNING").length;
  return {
    feeds_active: feeds.filter((f) => f.is_active).length,
    runs_24h: audit.length,
    success_rate: total > 0 ? success / total : 0,
    quarantined_24h: audit.reduce((s, r) => s + (r.quarantine_count ?? 0), 0),
  };
}

export function mockRunsByHour(projectCode: string): RunsByHourBucket[] {
  const buckets: Record<string, RunsByHourBucket> = {};
  for (let h = 0; h < 24; h++) {
    const label = `${String(h).padStart(2, "0")}:00`;
    buckets[label] = { hour: label, success: 0, failed: 0, partial: 0 };
  }
  MOCK_AUDIT.filter((r) => r.project_code === projectCode).forEach((row) => {
    const hr = new Date(row.start_ts).getHours();
    const key = `${String(hr).padStart(2, "0")}:00`;
    if (row.status === "SUCCESS") buckets[key].success++;
    else if (row.status === "FAILED") buckets[key].failed++;
    else if (row.status === "PARTIAL") buckets[key].partial++;
  });
  return Object.values(buckets);
}

// ---------------------------------------------------------------------------
// DQ rules (NEW — replaces DLT @expect_or_quarantine decorators)
// ---------------------------------------------------------------------------
import type { DqRule } from "@/lib/types";

export const MOCK_RULES: DqRule[] = [
  // gl_journal_oracle (Finance)
  {
    rule_id: 101, feed_id: 1, feed_name: "gl_journal_oracle", project_code: "finance",
    rule_name: "journal_id_required", rule_type: "NOT_NULL",
    predicate: "JOURNAL_ID IS NOT NULL",
    severity: "ERROR", action: "FAIL_RUN",
    error_message: "Journal entries must have a primary key",
    is_active: true,
    created_ts: "2026-02-01T10:00:00Z", updated_ts: "2026-04-15T10:00:00Z",
  },
  {
    rule_id: 102, feed_id: 1, feed_name: "gl_journal_oracle", project_code: "finance",
    rule_name: "amount_present", rule_type: "NOT_NULL",
    predicate: "AMOUNT IS NOT NULL",
    severity: "WARN", action: "QUARANTINE",
    error_message: "Amount cannot be null on a journal entry",
    is_active: true,
    created_ts: "2026-02-01T10:00:00Z", updated_ts: "2026-04-15T10:00:00Z",
  },
  {
    rule_id: 103, feed_id: 1, feed_name: "gl_journal_oracle", project_code: "finance",
    rule_name: "currency_iso", rule_type: "REGEX",
    predicate: "CURRENCY RLIKE '^[A-Z]{3}$'",
    severity: "WARN", action: "QUARANTINE",
    error_message: "Currency must be a 3-letter ISO code",
    is_active: true,
    created_ts: "2026-02-01T10:00:00Z", updated_ts: "2026-04-15T10:00:00Z",
  },
  // cdp_customers (Marketing)
  {
    rule_id: 201, feed_id: 10, feed_name: "cdp_customers", project_code: "marketing",
    rule_name: "valid_email", rule_type: "REGEX",
    predicate: "email RLIKE '^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$'",
    severity: "WARN", action: "QUARANTINE",
    error_message: "Email failed RFC-ish validation",
    is_active: true,
    created_ts: "2026-02-10T10:00:00Z", updated_ts: "2026-04-10T10:00:00Z",
  },
  {
    rule_id: 202, feed_id: 10, feed_name: "cdp_customers", project_code: "marketing",
    rule_name: "customer_id_required", rule_type: "NOT_NULL",
    predicate: "customer_id IS NOT NULL",
    severity: "ERROR", action: "FAIL_RUN",
    error_message: "customer_id must be present",
    is_active: true,
    created_ts: "2026-02-10T10:00:00Z", updated_ts: "2026-04-10T10:00:00Z",
  },
  // mainframe_ledger (Operations)
  {
    rule_id: 301, feed_id: 20, feed_name: "mainframe_ledger", project_code: "operations",
    rule_name: "amount_in_range", rule_type: "RANGE",
    predicate: "amount BETWEEN -100000000 AND 100000000",
    severity: "WARN", action: "QUARANTINE",
    error_message: "Amount outside expected ledger range",
    is_active: true,
    created_ts: "2026-02-15T10:00:00Z", updated_ts: "2026-04-12T10:00:00Z",
  },
  {
    rule_id: 302, feed_id: 20, feed_name: "mainframe_ledger", project_code: "operations",
    rule_name: "txn_date_valid", rule_type: "NOT_NULL",
    predicate: "txn_date IS NOT NULL",
    severity: "ERROR", action: "QUARANTINE",
    error_message: "Transaction date is required",
    is_active: true,
    created_ts: "2026-02-15T10:00:00Z", updated_ts: "2026-04-12T10:00:00Z",
  },
];
