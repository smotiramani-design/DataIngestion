/**
 * Thin wrapper around Databricks' Statement Execution API.
 *
 *   POST /api/2.0/sql/statements         submit
 *   GET  /api/2.0/sql/statements/{id}    poll
 *
 * We submit, poll until SUCCEEDED/FAILED, then map column-oriented rows back
 * to typed objects.
 *
 * In production, prefer OAuth U2M over PATs. For brevity this module accepts
 * a token via env var; swap to a token broker before shipping for real.
 */

const HOST = import.meta.env.VITE_DATABRICKS_HOST as string;
const WAREHOUSE_ID = import.meta.env.VITE_DATABRICKS_WAREHOUSE_ID as string;
const TOKEN = import.meta.env.VITE_DATABRICKS_TOKEN as string;

const POLL_INTERVAL_MS = 500;
const MAX_POLLS = 60;          // 30 seconds total

interface ColumnSchema {
  name: string;
  type_text: string;
}

interface StatementResponse {
  statement_id: string;
  status: { state: "PENDING" | "RUNNING" | "SUCCEEDED" | "FAILED" | "CANCELED";
            error?: { message: string } };
  manifest?: {
    schema: { columns: ColumnSchema[] };
    total_row_count: number;
  };
  result?: {
    data_array?: (string | null)[][];
  };
}

/**
 * Execute a parameterised SQL statement and return rows as typed objects.
 * Parameters are positional via `:name` style — the API does the binding,
 * so we don't have to worry about SQL injection.
 */
export async function executeQuery<T>(
  sql: string,
  params: Record<string, unknown> = {},
): Promise<T[]> {
  if (!HOST || !WAREHOUSE_ID || !TOKEN) {
    throw new Error(
      "Databricks env vars not set — VITE_DATABRICKS_HOST, " +
        "VITE_DATABRICKS_WAREHOUSE_ID, VITE_DATABRICKS_TOKEN required.",
    );
  }

  // Submit
  const submitResp = await fetch(`${HOST}/api/2.0/sql/statements`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${TOKEN}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      warehouse_id: WAREHOUSE_ID,
      statement: sql,
      parameters: Object.entries(params).map(([name, value]) => ({
        name,
        value: value === null || value === undefined ? null : String(value),
      })),
      wait_timeout: "10s",
      on_wait_timeout: "CONTINUE",
      format: "JSON_ARRAY",
      disposition: "INLINE",
    }),
  });

  if (!submitResp.ok) {
    const body = await submitResp.text();
    throw new Error(`Databricks submit failed (${submitResp.status}): ${body}`);
  }

  let result: StatementResponse = await submitResp.json();

  // Poll
  for (let i = 0; i < MAX_POLLS && (result.status.state === "PENDING" || result.status.state === "RUNNING"); i++) {
    await new Promise((r) => setTimeout(r, POLL_INTERVAL_MS));
    const pollResp = await fetch(
      `${HOST}/api/2.0/sql/statements/${result.statement_id}`,
      { headers: { "Authorization": `Bearer ${TOKEN}` } },
    );
    if (!pollResp.ok) {
      throw new Error(`Databricks poll failed (${pollResp.status})`);
    }
    result = await pollResp.json();
  }

  if (result.status.state !== "SUCCEEDED") {
    const reason = result.status.error?.message ?? result.status.state;
    throw new Error(`Statement did not succeed: ${reason}`);
  }

  return mapRows<T>(result);
}

function mapRows<T>(resp: StatementResponse): T[] {
  const cols = resp.manifest?.schema.columns ?? [];
  const rows = resp.result?.data_array ?? [];
  return rows.map((row) => {
    const obj: Record<string, unknown> = {};
    cols.forEach((col, i) => {
      obj[col.name] = coerce(row[i], col.type_text);
    });
    return obj as T;
  });
}

/** Best-effort coercion of API string values to typed JS values. */
function coerce(raw: string | null, typeText: string): unknown {
  if (raw === null) return null;
  const t = typeText.toUpperCase();
  if (t === "BOOLEAN") return raw === "true";
  if (t === "INT" || t === "BIGINT" || t === "SMALLINT" || t === "TINYINT") {
    return Number(raw);
  }
  if (t === "DOUBLE" || t === "FLOAT" || t.startsWith("DECIMAL")) {
    return Number(raw);
  }
  if (t === "MAP" || t.startsWith("MAP<") || t.startsWith("STRUCT<")) {
    try { return JSON.parse(raw); } catch { return raw; }
  }
  return raw;
}
