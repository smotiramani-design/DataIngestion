/**
 * Typed query functions used throughout the UI.
 *
 * Single source of switching between mock and live: when
 * VITE_USE_MOCK_DATA="true", these return fixture data; otherwise they
 * issue real Statement Execution API calls.
 *
 * The query strings here are the actual SQL that will run against the
 * framework's control tables in production.
 */

import { executeQuery } from "@/api/databricks";
import type {
  AuditLogRow, ErrorLogRow, FeedConfig, DashboardKpis, RunsByHourBucket,
} from "@/lib/types";
import {
  MOCK_AUDIT, MOCK_ERRORS, MOCK_FEEDS, mockKpis, mockRunsByHour,
} from "@/mocks/fixtures";

const USE_MOCK = (import.meta.env.VITE_USE_MOCK_DATA as string) === "true";
const CATALOG = (import.meta.env.VITE_INGEST_CATALOG as string) || "ingest_platform";
const SCHEMA  = (import.meta.env.VITE_INGEST_CONTROL_SCHEMA as string) || "control";

const T = {
  feed_config: `${CATALOG}.${SCHEMA}.feed_config`,
  audit_log:   `${CATALOG}.${SCHEMA}.audit_log`,
  error_log:   `${CATALOG}.${SCHEMA}.error_log`,
};

// Tiny artificial delay in mock mode so loading states are visible —
// makes the UX feel real rather than instant-pop.
const MOCK_LATENCY_MS = 250;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------------
export async function getDashboardKpis(): Promise<DashboardKpis> {
  if (USE_MOCK) {
    await sleep(MOCK_LATENCY_MS);
    return mockKpis();
  }
  const rows = await executeQuery<DashboardKpis>(`
    WITH last24 AS (
      SELECT * FROM ${T.audit_log}
      WHERE  start_ts >= current_timestamp() - INTERVAL 24 HOURS
    )
    SELECT
      (SELECT COUNT(*) FROM ${T.feed_config} WHERE is_active = TRUE) AS feeds_active,
      (SELECT COUNT(*) FROM last24) AS runs_24h,
      COALESCE(
        SUM(CASE WHEN status = 'SUCCESS' THEN 1 ELSE 0 END) /
        NULLIF(SUM(CASE WHEN status <> 'RUNNING' THEN 1 ELSE 0 END), 0),
        0
      ) AS success_rate,
      COALESCE(SUM(quarantine_count), 0) AS quarantined_24h
    FROM last24
  `);
  return rows[0] ?? { feeds_active: 0, runs_24h: 0, success_rate: 0, quarantined_24h: 0 };
}

export async function getRunsByHour(): Promise<RunsByHourBucket[]> {
  if (USE_MOCK) {
    await sleep(MOCK_LATENCY_MS);
    return mockRunsByHour();
  }
  return executeQuery<RunsByHourBucket>(`
    SELECT
      date_format(start_ts, 'HH:00') AS hour,
      SUM(CASE WHEN status = 'SUCCESS' THEN 1 ELSE 0 END) AS success,
      SUM(CASE WHEN status = 'FAILED'  THEN 1 ELSE 0 END) AS failed,
      SUM(CASE WHEN status = 'PARTIAL' THEN 1 ELSE 0 END) AS partial
    FROM ${T.audit_log}
    WHERE start_ts >= current_timestamp() - INTERVAL 24 HOURS
    GROUP BY date_format(start_ts, 'HH:00')
    ORDER BY hour
  `);
}

// ---------------------------------------------------------------------------
// Audit log
// ---------------------------------------------------------------------------
export async function getRecentRuns(limit = 50): Promise<AuditLogRow[]> {
  if (USE_MOCK) {
    await sleep(MOCK_LATENCY_MS);
    return MOCK_AUDIT.slice(0, limit);
  }
  return executeQuery<AuditLogRow>(`
    SELECT a.*, f.feed_name, f.source_type
    FROM   ${T.audit_log} a
    JOIN   ${T.feed_config} f USING (feed_id)
    ORDER BY a.start_ts DESC
    LIMIT  :lim
  `, { lim: limit });
}

// ---------------------------------------------------------------------------
// Feeds
// ---------------------------------------------------------------------------
export async function getFeeds(): Promise<FeedConfig[]> {
  if (USE_MOCK) {
    await sleep(MOCK_LATENCY_MS);
    return [...MOCK_FEEDS].sort((a, b) => a.feed_name.localeCompare(b.feed_name));
  }
  return executeQuery<FeedConfig>(`
    SELECT * FROM ${T.feed_config} ORDER BY feed_name
  `);
}

export async function setFeedActive(feed_id: number, is_active: boolean): Promise<void> {
  if (USE_MOCK) {
    await sleep(MOCK_LATENCY_MS);
    const f = MOCK_FEEDS.find((x) => x.feed_id === feed_id);
    if (f) f.is_active = is_active;
    return;
  }
  await executeQuery(`
    UPDATE ${T.feed_config}
    SET    is_active = :active, updated_ts = current_timestamp()
    WHERE  feed_id = :id
  `, { active: is_active, id: feed_id });
}

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------
export async function getOpenErrors(limit = 100): Promise<ErrorLogRow[]> {
  if (USE_MOCK) {
    await sleep(MOCK_LATENCY_MS);
    return MOCK_ERRORS.filter((e) => !e.resolved_flag).slice(0, limit);
  }
  return executeQuery<ErrorLogRow>(`
    SELECT e.*, f.feed_name
    FROM   ${T.error_log} e
    JOIN   ${T.feed_config} f USING (feed_id)
    WHERE  e.resolved_flag = FALSE
    ORDER BY e.error_ts DESC
    LIMIT  :lim
  `, { lim: limit });
}

export async function getResolvedErrors(limit = 50): Promise<ErrorLogRow[]> {
  if (USE_MOCK) {
    await sleep(MOCK_LATENCY_MS);
    return MOCK_ERRORS.filter((e) => e.resolved_flag).slice(0, limit);
  }
  return executeQuery<ErrorLogRow>(`
    SELECT e.*, f.feed_name
    FROM   ${T.error_log} e
    JOIN   ${T.feed_config} f USING (feed_id)
    WHERE  e.resolved_flag = TRUE
    ORDER BY e.resolved_ts DESC
    LIMIT  :lim
  `, { lim: limit });
}

export async function resolveError(error_id: number, resolved_by: string): Promise<void> {
  if (USE_MOCK) {
    await sleep(MOCK_LATENCY_MS);
    const e = MOCK_ERRORS.find((x) => x.error_id === error_id);
    if (e) {
      e.resolved_flag = true;
      e.resolved_ts = new Date().toISOString();
      e.resolved_by = resolved_by;
    }
    return;
  }
  await executeQuery(`
    UPDATE ${T.error_log}
    SET    resolved_flag = TRUE,
           resolved_ts = current_timestamp(),
           resolved_by = :by
    WHERE  error_id = :id
  `, { by: resolved_by, id: error_id });
}
