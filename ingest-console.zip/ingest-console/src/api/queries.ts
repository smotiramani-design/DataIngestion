/**
 * Typed query functions used throughout the UI (multi-project edition).
 *
 * Every query is project-scoped — there's no "give me everything" endpoint.
 * The UI's ProjectProvider passes the active project_code into each call.
 *
 * Single source of switching between mock and live: VITE_USE_MOCK_DATA.
 */

import { executeQuery } from "@/api/databricks";
import type {
  AuditLogRow, ErrorLogRow, FeedConfig, DashboardKpis, RunsByHourBucket, Project,
} from "@/lib/types";
import {
  MOCK_AUDIT, MOCK_ERRORS, MOCK_FEEDS, MOCK_PROJECTS,
  mockKpis, mockRunsByHour,
} from "@/mocks/fixtures";

const USE_MOCK = (import.meta.env.VITE_USE_MOCK_DATA as string) === "true";
const CATALOG = (import.meta.env.VITE_INGEST_CATALOG as string) || "ingest_platform";
const SCHEMA  = (import.meta.env.VITE_INGEST_CONTROL_SCHEMA as string) || "control";

const T = {
  projects:    `${CATALOG}.${SCHEMA}.projects`,
  feed_config: `${CATALOG}.${SCHEMA}.feed_config`,
  audit_log:   `${CATALOG}.${SCHEMA}.audit_log`,
  error_log:   `${CATALOG}.${SCHEMA}.error_log`,
};

const MOCK_LATENCY_MS = 250;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------------------
// Projects (the new top of the hierarchy)
// ---------------------------------------------------------------------------
export async function getProjects(): Promise<Project[]> {
  if (USE_MOCK) {
    await sleep(MOCK_LATENCY_MS);
    return MOCK_PROJECTS.filter((p) => p.is_active);
  }
  return executeQuery<Project>(`
    SELECT * FROM ${T.projects}
    WHERE  is_active = TRUE
    ORDER BY project_name
  `);
}

// ---------------------------------------------------------------------------
// Dashboard — project-scoped
// ---------------------------------------------------------------------------
export async function getDashboardKpis(projectCode: string): Promise<DashboardKpis> {
  if (USE_MOCK) {
    await sleep(MOCK_LATENCY_MS);
    return mockKpis(projectCode);
  }
  const rows = await executeQuery<DashboardKpis>(`
    WITH project AS (
      SELECT project_id FROM ${T.projects} WHERE project_code = :code
    ),
    last24 AS (
      SELECT a.* FROM ${T.audit_log} a
      JOIN   project p ON p.project_id = a.project_id
      WHERE  a.start_ts >= current_timestamp() - INTERVAL 24 HOURS
    )
    SELECT
      (SELECT COUNT(*) FROM ${T.feed_config} f
              JOIN project p ON p.project_id = f.project_id
              WHERE f.is_active = TRUE) AS feeds_active,
      (SELECT COUNT(*) FROM last24) AS runs_24h,
      COALESCE(
        SUM(CASE WHEN status = 'SUCCESS' THEN 1 ELSE 0 END) /
        NULLIF(SUM(CASE WHEN status <> 'RUNNING' THEN 1 ELSE 0 END), 0), 0
      ) AS success_rate,
      COALESCE(SUM(quarantine_count), 0) AS quarantined_24h
    FROM last24
  `, { code: projectCode });
  return rows[0] ?? { feeds_active: 0, runs_24h: 0, success_rate: 0, quarantined_24h: 0 };
}

export async function getRunsByHour(projectCode: string): Promise<RunsByHourBucket[]> {
  if (USE_MOCK) {
    await sleep(MOCK_LATENCY_MS);
    return mockRunsByHour(projectCode);
  }
  return executeQuery<RunsByHourBucket>(`
    SELECT
      date_format(a.start_ts, 'HH:00') AS hour,
      SUM(CASE WHEN a.status = 'SUCCESS' THEN 1 ELSE 0 END) AS success,
      SUM(CASE WHEN a.status = 'FAILED'  THEN 1 ELSE 0 END) AS failed,
      SUM(CASE WHEN a.status = 'PARTIAL' THEN 1 ELSE 0 END) AS partial
    FROM ${T.audit_log} a
    JOIN ${T.projects}  p ON p.project_id = a.project_id
    WHERE p.project_code = :code
      AND a.start_ts >= current_timestamp() - INTERVAL 24 HOURS
    GROUP BY date_format(a.start_ts, 'HH:00')
    ORDER BY hour
  `, { code: projectCode });
}

// ---------------------------------------------------------------------------
// Audit log — project-scoped
// ---------------------------------------------------------------------------
export async function getRecentRuns(projectCode: string, limit = 50): Promise<AuditLogRow[]> {
  if (USE_MOCK) {
    await sleep(MOCK_LATENCY_MS);
    return MOCK_AUDIT.filter((r) => r.project_code === projectCode).slice(0, limit);
  }
  return executeQuery<AuditLogRow>(`
    SELECT a.*, f.feed_name, f.source_type, p.project_code
    FROM   ${T.audit_log}   a
    JOIN   ${T.feed_config} f USING (feed_id)
    JOIN   ${T.projects}    p ON p.project_id = a.project_id
    WHERE  p.project_code = :code
    ORDER BY a.start_ts DESC
    LIMIT  :lim
  `, { code: projectCode, lim: limit });
}

// ---------------------------------------------------------------------------
// Feeds — project-scoped
// ---------------------------------------------------------------------------
export async function getFeeds(projectCode: string): Promise<FeedConfig[]> {
  if (USE_MOCK) {
    await sleep(MOCK_LATENCY_MS);
    return MOCK_FEEDS
      .filter((f) => f.project_code === projectCode)
      .sort((a, b) => a.feed_name.localeCompare(b.feed_name));
  }
  return executeQuery<FeedConfig>(`
    SELECT f.*, p.project_code
    FROM   ${T.feed_config} f
    JOIN   ${T.projects}    p ON p.project_id = f.project_id
    WHERE  p.project_code = :code
    ORDER BY f.feed_name
  `, { code: projectCode });
}

export async function setFeedActive(feed_id: number, is_active: boolean): Promise<void> {
  if (USE_MOCK) {
    await sleep(MOCK_LATENCY_MS);
    const f = MOCK_FEEDS.find((x) => x.feed_id === feed_id);
    if (f) f.is_active = is_active;
    return;
  }
  await executeQuery(`
    UPDATE ${T.feed_config}
    SET    is_active = :active, updated_ts = current_timestamp()
    WHERE  feed_id = :id
  `, { active: is_active, id: feed_id });
}

// ---------------------------------------------------------------------------
// Errors — project-scoped
// ---------------------------------------------------------------------------
export async function getOpenErrors(projectCode: string, limit = 100): Promise<ErrorLogRow[]> {
  if (USE_MOCK) {
    await sleep(MOCK_LATENCY_MS);
    return MOCK_ERRORS
      .filter((e) => e.project_code === projectCode && !e.resolved_flag)
      .slice(0, limit);
  }
  return executeQuery<ErrorLogRow>(`
    SELECT e.*, f.feed_name, p.project_code
    FROM   ${T.error_log}   e
    JOIN   ${T.feed_config} f USING (feed_id)
    JOIN   ${T.projects}    p ON p.project_id = e.project_id
    WHERE  p.project_code = :code AND e.resolved_flag = FALSE
    ORDER BY e.error_ts DESC
    LIMIT  :lim
  `, { code: projectCode, lim: limit });
}

export async function getResolvedErrors(projectCode: string, limit = 50): Promise<ErrorLogRow[]> {
  if (USE_MOCK) {
    await sleep(MOCK_LATENCY_MS);
    return MOCK_ERRORS
      .filter((e) => e.project_code === projectCode && e.resolved_flag)
      .slice(0, limit);
  }
  return executeQuery<ErrorLogRow>(`
    SELECT e.*, f.feed_name, p.project_code
    FROM   ${T.error_log}   e
    JOIN   ${T.feed_config} f USING (feed_id)
    JOIN   ${T.projects}    p ON p.project_id = e.project_id
    WHERE  p.project_code = :code AND e.resolved_flag = TRUE
    ORDER BY e.resolved_ts DESC
    LIMIT  :lim
  `, { code: projectCode, lim: limit });
}

export async function resolveError(error_id: number, resolved_by: string): Promise<void> {
  if (USE_MOCK) {
    await sleep(MOCK_LATENCY_MS);
    const e = MOCK_ERRORS.find((x) => x.error_id === error_id);
    if (e) {
      e.resolved_flag = true;
      e.resolved_ts = new Date().toISOString();
      e.resolved_by = resolved_by;
    }
    return;
  }
  await executeQuery(`
    UPDATE ${T.error_log}
    SET    resolved_flag = TRUE,
           resolved_ts = current_timestamp(),
           resolved_by = :by
    WHERE  error_id = :id
  `, { by: resolved_by, id: error_id });
}
