import { Routes, Route, Navigate } from "react-router-dom";
import Layout from "@/components/Layout";
import DashboardPage from "@/pages/Dashboard";
import FeedsPage from "@/pages/Feeds";
import ErrorsPage from "@/pages/Errors";
import AuditPage from "@/pages/Audit";

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/feeds"     element={<FeedsPage />} />
        <Route path="/errors"    element={<ErrorsPage />} />
        <Route path="/audit"     element={<AuditPage />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Route>
    </Routes>
  );
}
