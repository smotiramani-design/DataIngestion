import { useNavigate } from "react-router-dom";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  CartesianGrid, Legend,
} from "recharts";
import { RefreshCw, Activity, CheckCircle2, AlertOctagon, Database } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

import PageHeader from "@/components/PageHeader";
import { RunStatusPill } from "@/components/StatusPill";
import { useAsync } from "@/lib/useAsync";
import { getDashboardKpis, getRecentRuns, getRunsByHour } from "@/api/queries";

export default function DashboardPage() {
  const kpis = useAsync(getDashboardKpis);
  const chart = useAsync(getRunsByHour);
  const runs  = useAsync(() => getRecentRuns(8));

  const refreshAll = () => {
    kpis.refresh();
    chart.refresh();
    runs.refresh();
  };

  return (
    <>
      <PageHeader
        title="Dashboard"
        subtitle="Last 24 hours · all feeds"
        actions={
          <button onClick={refreshAll} className="btn-ghost">
            <RefreshCw className="w-4 h-4" /> Refresh
          </button>
        }
      />

      <div className="px-8 py-6 space-y-6">
        {/* KPI strip */}
        <section className="grid grid-cols-4 gap-4">
          <KpiCard
            label="Feeds Active"
            value={kpis.loading ? "—" : String(kpis.data?.feeds_active ?? 0)}
            icon={Database}
            accent="bg-teal"
          />
          <KpiCard
            label="Runs (24h)"
            value={kpis.loading ? "—" : String(kpis.data?.runs_24h ?? 0)}
            icon={Activity}
            accent="bg-deepblue"
          />
          <KpiCard
            label="Success Rate"
            value={kpis.loading ? "—" : `${((kpis.data?.success_rate ?? 0) * 100).toFixed(1)}%`}
            icon={CheckCircle2}
            accent="bg-emerald-500"
          />
          <KpiCard
            label="Quarantined"
            value={kpis.loading ? "—" : (kpis.data?.quarantined_24h ?? 0).toLocaleString()}
            icon={AlertOctagon}
            accent="bg-amber-500"
          />
        </section>

        {/* Chart + recent runs */}
        <section className="grid grid-cols-3 gap-4">
          <div className="col-span-2 card p-5">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-navy">Runs by hour</h2>
              <span className="text-xs text-slate-500">Stacked: success / partial / failed</span>
            </div>

            <div className="h-64">
              {chart.loading ? (
                <SkeletonBlock />
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chart.data ?? []} margin={{ top: 10, right: 10, bottom: 0, left: -20 }}>
                    <CartesianGrid stroke="#E2E8F0" vertical={false} />
                    <XAxis dataKey="hour" stroke="#64748B" fontSize={11}
                           interval="preserveStartEnd" tickCount={8} />
                    <YAxis stroke="#64748B" fontSize={11} />
                    <Tooltip
                      contentStyle={{ fontSize: 12, borderRadius: 6, border: "1px solid #E2E8F0" }}
                      cursor={{ fill: "#F1F5F9" }}
                    />
                    <Legend iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                    <Bar dataKey="success" stackId="a" fill="#1C7293" />
                    <Bar dataKey="partial" stackId="a" fill="#F59E0B" />
                    <Bar dataKey="failed"  stackId="a" fill="#EF4444" />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          <RecentRunsCard
            runs={runs.data ?? []}
            loading={runs.loading}
          />
        </section>
      </div>
    </>
  );
}

// ---------------------------------------------------------------------------
function KpiCard({ label, value, icon: Icon, accent }: {
  label: string; value: string;
  icon: React.ComponentType<{ className?: string }>; accent: string;
}) {
  return (
    <div className="card p-4 relative overflow-hidden">
      <div className={`absolute top-0 left-0 h-1 w-full ${accent}`} />
      <div className="flex items-start justify-between mb-2 mt-1">
        <div className="text-[10px] tracking-wider font-semibold text-slate-500 uppercase">
          {label}
        </div>
        <Icon className="w-4 h-4 text-slate-400" />
      </div>
      <div className="text-3xl font-semibold text-navy tabular-nums">{value}</div>
    </div>
  );
}

function RecentRunsCard({ runs, loading }: {
  runs: Awaited<ReturnType<typeof getRecentRuns>>;
  loading: boolean;
}) {
  const navigate = useNavigate();
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-sm font-semibold text-navy">Recent runs</h2>
        <button
          onClick={() => navigate("/audit")}
          className="text-xs text-deepblue hover:underline"
        >
          View all →
        </button>
      </div>

      {loading ? <SkeletonBlock /> : (
        <ul className="divide-y divide-slate-100 text-sm">
          {runs.map((r) => (
            <li key={r.run_id} className="py-2 flex items-center justify-between gap-2">
              <div className="min-w-0 flex-1">
                <div className="font-medium text-slate-800 truncate">{r.feed_name}</div>
                <div className="text-xs text-slate-500">
                  {formatDistanceToNow(new Date(r.start_ts), { addSuffix: true })}
                </div>
              </div>
              <RunStatusPill status={r.status} />
            </li>
          ))}
          {runs.length === 0 && (
            <li className="py-6 text-center text-sm text-slate-400">No runs yet.</li>
          )}
        </ul>
      )}
    </div>
  );
}

function SkeletonBlock() {
  return (
    <div className="h-full w-full bg-slate-100 rounded animate-pulse min-h-32" />
  );
}
