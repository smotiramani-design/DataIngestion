import { useState } from "react";
import { Check, ChevronDown, ChevronRight } from "lucide-react";
import clsx from "clsx";
import { formatDistanceToNow } from "date-fns";

import PageHeader from "@/components/PageHeader";
import { SeverityPill } from "@/components/StatusPill";
import { useAsync } from "@/lib/useAsync";
import { getOpenErrors, getResolvedErrors, resolveError } from "@/api/queries";
import type { ErrorLogRow, ErrorType } from "@/lib/types";

const TYPE_COLORS: Record<ErrorType, string> = {
  SCHEMA:       "bg-blue-100 text-blue-700",
  DQ:           "bg-amber-100 text-amber-700",
  CONNECTIVITY: "bg-rose-100 text-rose-700",
  RUNTIME:      "bg-purple-100 text-purple-700",
  CONFIG:       "bg-slate-200 text-slate-700",
};

export default function ErrorsPage() {
  const [tab, setTab] = useState<"open" | "resolved">("open");
  const open     = useAsync(getOpenErrors);
  const resolved = useAsync(() => getResolvedErrors(50));
  const errors = tab === "open" ? open : resolved;

  return (
    <>
      <PageHeader
        title="Errors"
        subtitle={
          tab === "open"
            ? `${(open.data ?? []).length} open · awaiting triage`
            : `${(resolved.data ?? []).length} recently resolved`
        }
        actions={
          <div className="flex border border-slate-200 rounded-md overflow-hidden text-sm">
            <button
              onClick={() => setTab("open")}
              className={clsx(
                "px-3 py-1.5",
                tab === "open" ? "bg-deepblue text-white" : "bg-white text-slate-600 hover:bg-slate-50",
              )}
            >
              Open
            </button>
            <button
              onClick={() => setTab("resolved")}
              className={clsx(
                "px-3 py-1.5 border-l border-slate-200",
                tab === "resolved" ? "bg-deepblue text-white" : "bg-white text-slate-600 hover:bg-slate-50",
              )}
            >
              Resolved
            </button>
          </div>
        }
      />

      <div className="px-8 py-6">
        {errors.loading && (
          <div className="card p-8 text-center text-slate-400">Loading…</div>
        )}
        {!errors.loading && (errors.data ?? []).length === 0 && (
          <div className="card p-12 text-center">
            <div className="text-2xl mb-2">🎉</div>
            <div className="text-slate-700 font-medium">
              {tab === "open" ? "No open errors. All clear." : "No resolved errors yet."}
            </div>
          </div>
        )}

        <div className="space-y-2">
          {(errors.data ?? []).map((e) => (
            <ErrorRow
              key={e.error_id}
              row={e}
              onResolve={async () => {
                await resolveError(e.error_id, "you@example.com");
                open.refresh();
                resolved.refresh();
              }}
              showResolveAction={tab === "open"}
            />
          ))}
        </div>
      </div>
    </>
  );
}

function ErrorRow({ row, onResolve, showResolveAction }: {
  row: ErrorLogRow;
  onResolve: () => Promise<void>;
  showResolveAction: boolean;
}) {
  const [expanded, setExpanded] = useState(false);
  const [busy, setBusy] = useState(false);
  const handleResolve = async () => {
    setBusy(true);
    try { await onResolve(); } finally { setBusy(false); }
  };

  return (
    <div className="card overflow-hidden">
      <div
        className="flex items-center gap-3 px-4 py-3 cursor-pointer hover:bg-slate-50"
        onClick={() => setExpanded(!expanded)}
      >
        <button className="text-slate-400">
          {expanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </button>

        <div className="flex items-center gap-2 w-44 shrink-0">
          <SeverityPill severity={row.error_severity} />
          <span className={clsx("pill", TYPE_COLORS[row.error_type])}>
            {row.error_type}
          </span>
        </div>

        <div className="flex-1 min-w-0">
          <div className="font-medium text-navy truncate">{row.feed_name}</div>
          <div className="text-xs text-slate-500 truncate">
            {row.error_message}
          </div>
        </div>

        <div className="text-xs text-slate-400 shrink-0">
          {formatDistanceToNow(new Date(row.error_ts), { addSuffix: true })}
        </div>

        {showResolveAction && (
          <button
            disabled={busy}
            onClick={(ev) => { ev.stopPropagation(); handleResolve(); }}
            className="btn bg-emerald-50 text-emerald-700 hover:bg-emerald-100 disabled:opacity-50"
          >
            <Check className="w-3.5 h-3.5" />
            Resolve
          </button>
        )}
      </div>

      {expanded && (
        <div className="px-4 pb-4 pt-1 bg-slate-50 border-t border-slate-100 space-y-3">
          <DetailRow label="Run ID" value={row.run_id} mono />
          <DetailRow label="Error ID" value={String(row.error_id)} mono />
          {row.expectation_name && (
            <DetailRow label="Expectation" value={row.expectation_name} mono />
          )}
          {row.raw_record && (
            <DetailBlock label="Raw record">
              <pre className="text-xs bg-white border border-slate-200 rounded p-2 overflow-x-auto">
                {tryFormatJson(row.raw_record)}
              </pre>
            </DetailBlock>
          )}
          {row.stack_trace && (
            <DetailBlock label="Stack trace">
              <pre className="text-xs bg-white border border-slate-200 rounded p-2 overflow-x-auto">
                {row.stack_trace}
              </pre>
            </DetailBlock>
          )}
          {row.resolved_flag && (
            <div className="text-xs text-slate-600 flex items-center gap-2">
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              Resolved by <span className="font-mono">{row.resolved_by}</span> ·{" "}
              {row.resolved_ts && formatDistanceToNow(new Date(row.resolved_ts), { addSuffix: true })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function DetailRow({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex gap-3 text-xs">
      <div className="w-28 shrink-0 text-slate-500">{label}</div>
      <div className={clsx(mono && "font-mono", "text-slate-800")}>{value}</div>
    </div>
  );
}

function DetailBlock({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-xs text-slate-500 mb-1">{label}</div>
      {children}
    </div>
  );
}

function tryFormatJson(s: string): string {
  try { return JSON.stringify(JSON.parse(s), null, 2); } catch { return s; }
}
