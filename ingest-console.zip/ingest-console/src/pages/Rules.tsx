import { useState } from "react";
import { Search, Power } from "lucide-react";
import clsx from "clsx";

import PageHeader from "@/components/PageHeader";
import { SeverityPill, BoolPill } from "@/components/StatusPill";
import { useAsync } from "@/lib/useAsync";
import { useProject } from "@/lib/projectContext";
import { getDqRules, setRuleActive } from "@/api/queries";
import type { DqRule, RuleType, RuleAction } from "@/lib/types";

const TYPE_COLORS: Record<RuleType, string> = {
  NOT_NULL:   "bg-slate-100 text-slate-700",
  RANGE:      "bg-cyan-100 text-cyan-700",
  REGEX:      "bg-violet-100 text-violet-700",
  UNIQUE:     "bg-emerald-100 text-emerald-700",
  CUSTOM_SQL: "bg-amber-100 text-amber-700",
};

const ACTION_COLORS: Record<RuleAction, string> = {
  DROP:       "bg-slate-200 text-slate-700",
  QUARANTINE: "bg-amber-100 text-amber-700",
  FAIL_RUN:   "bg-rose-100 text-rose-700",
};

export default function RulesPage() {
  const { selected } = useProject();
  const code = selected?.project_code ?? "";
  const rules = useAsync(() => code ? getDqRules(code) : Promise.resolve([]), [code]);

  const [filter, setFilter] = useState("");
  const [busyId, setBusyId] = useState<number | null>(null);

  const visible = (rules.data ?? []).filter((r) =>
    r.rule_name.toLowerCase().includes(filter.toLowerCase()) ||
    (r.feed_name ?? "").toLowerCase().includes(filter.toLowerCase()),
  );

  const toggleActive = async (rule: DqRule) => {
    setBusyId(rule.rule_id);
    try {
      await setRuleActive(rule.rule_id, !rule.is_active);
      rules.refresh();
    } finally {
      setBusyId(null);
    }
  };

  return (
    <>
      <PageHeader
        title="DQ Rules"
        subtitle={
          selected
            ? `${selected.project_name} · ${(rules.data ?? []).filter(r => r.is_active).length} active of ${(rules.data ?? []).length}`
            : "Loading…"
        }
      />

      <div className="px-8 py-6">
        <div className="card p-3 mb-4 flex items-center gap-2">
          <Search className="w-4 h-4 text-slate-400 ml-1" />
          <input
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="Filter by rule name or feed…"
            className="flex-1 outline-none text-sm bg-transparent"
          />
        </div>

        <div className="card overflow-hidden">
          <table className="w-full text-sm table-fixed">
            <colgroup>
              <col className="w-48" />
              <col className="w-40" />
              <col className="w-28" />
              <col className="w-24" />
              <col className="w-28" />
              <col />
              <col className="w-20" />
              <col className="w-16" />
            </colgroup>
            <thead>
              <tr className="bg-slate-50 text-left text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="px-4 py-3">Rule</th>
                <th className="px-4 py-3">Feed</th>
                <th className="px-4 py-3">Type</th>
                <th className="px-4 py-3">Severity</th>
                <th className="px-4 py-3">Action</th>
                <th className="px-4 py-3">Predicate</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 text-right"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rules.loading && (
                <tr><td colSpan={8} className="px-4 py-8 text-center text-slate-400">Loading…</td></tr>
              )}
              {!rules.loading && visible.length === 0 && (
                <tr><td colSpan={8} className="px-4 py-8 text-center text-slate-400">
                  {filter ? "No rules match this filter." : "No DQ rules configured for this project."}
                </td></tr>
              )}
              {visible.map((rule) => (
                <tr key={rule.rule_id} className="hover:bg-slate-50">
                  <td className="px-4 py-2.5 font-mono text-xs text-navy">{rule.rule_name}</td>
                  <td className="px-4 py-2.5 text-slate-600 truncate" title={rule.feed_name}>
                    {rule.feed_name}
                  </td>
                  <td className="px-4 py-2.5">
                    <span className={clsx("pill", TYPE_COLORS[rule.rule_type])}>{rule.rule_type}</span>
                  </td>
                  <td className="px-4 py-2.5">
                    <SeverityPill severity={rule.severity} />
                  </td>
                  <td className="px-4 py-2.5">
                    <span className={clsx("pill", ACTION_COLORS[rule.action])}>{rule.action}</span>
                  </td>
                  <td className="px-4 py-2.5 font-mono text-[11px] text-slate-500 truncate" title={rule.predicate}>
                    {rule.predicate}
                  </td>
                  <td className="px-4 py-2.5">
                    <BoolPill value={rule.is_active} on="active" off="paused" />
                  </td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center justify-end">
                      <button
                        className={clsx(
                          "btn-ghost",
                          rule.is_active ? "hover:text-rose-600" : "hover:text-emerald-600",
                        )}
                        title={rule.is_active ? "Disable rule" : "Activate rule"}
                        disabled={busyId === rule.rule_id}
                        onClick={() => toggleActive(rule)}
                      >
                        <Power className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
