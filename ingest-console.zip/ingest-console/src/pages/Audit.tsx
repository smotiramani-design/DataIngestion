import { useState, useMemo } from "react";
import { Search } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

import PageHeader from "@/components/PageHeader";
import { RunStatusPill } from "@/components/StatusPill";
import { useAsync } from "@/lib/useAsync";
import { useProject } from "@/lib/projectContext";
import { getRecentRuns } from "@/api/queries";
import type { RunStatus } from "@/lib/types";

const STATUS_FILTERS: Array<RunStatus | "ALL"> = ["ALL", "SUCCESS", "PARTIAL", "FAILED", "RUNNING"];

export default function AuditPage() {
  const { selected } = useProject();
  const code = selected?.project_code ?? "";
  const runs = useAsync(() => code ? getRecentRuns(code, 200) : Promise.resolve([]), [code]);
  const [statusFilter, setStatusFilter] = useState<RunStatus | "ALL">("ALL");
  const [feedFilter, setFeedFilter] = useState("");

  const visible = useMemo(() => {
    return (runs.data ?? []).filter((r) => {
      if (statusFilter !== "ALL" && r.status !== statusFilter) return false;
      if (feedFilter && !r.feed_name.toLowerCase().includes(feedFilter.toLowerCase())) return false;
      return true;
    });
  }, [runs.data, statusFilter, feedFilter]);

  return (
    <>
      <PageHeader
        title="Audit Log"
        subtitle={`${visible.length} of ${(runs.data ?? []).length} runs · last 200`}
      />

      <div className="px-8 py-6">
        {/* Filters */}
        <div className="card p-3 mb-4 flex items-center gap-3">
          <div className="flex items-center gap-2 flex-1">
            <Search className="w-4 h-4 text-slate-400 ml-1" />
            <input
              value={feedFilter}
              onChange={(e) => setFeedFilter(e.target.value)}
              placeholder="Filter by feed name…"
              className="flex-1 outline-none text-sm bg-transparent"
            />
          </div>

          <div className="flex border border-slate-200 rounded-md overflow-hidden text-xs">
            {STATUS_FILTERS.map((s) => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={
                  "px-2.5 py-1.5 border-l first:border-l-0 border-slate-200 " +
                  (statusFilter === s
                    ? "bg-deepblue text-white"
                    : "bg-white text-slate-600 hover:bg-slate-50")
                }
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Table */}
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 text-left text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="px-4 py-3">Run ID</th>
                <th className="px-4 py-3">Feed</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 text-right">Source</th>
                <th className="px-4 py-3 text-right">Bronze</th>
                <th className="px-4 py-3 text-right">Silver</th>
                <th className="px-4 py-3 text-right">Quarantined</th>
                <th className="px-4 py-3 text-right">Duration</th>
                <th className="px-4 py-3">Started</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {runs.loading && (
                <tr><td colSpan={9} className="px-4 py-8 text-center text-slate-400">Loading…</td></tr>
              )}
              {!runs.loading && visible.length === 0 && (
                <tr><td colSpan={9} className="px-4 py-8 text-center text-slate-400">
                  No runs match these filters.
                </td></tr>
              )}
              {visible.map((r) => (
                <tr key={r.run_id} className="hover:bg-slate-50">
                  <td className="px-4 py-2.5 font-mono text-[11px] text-slate-500 truncate max-w-[180px]">
                    {r.run_id}
                  </td>
                  <td className="px-4 py-2.5 font-medium text-navy">{r.feed_name}</td>
                  <td className="px-4 py-2.5"><RunStatusPill status={r.status} /></td>
                  <td className="px-4 py-2.5 text-right tabular-nums text-slate-600">
                    {r.source_record_count?.toLocaleString() ?? "—"}
                  </td>
                  <td className="px-4 py-2.5 text-right tabular-nums text-slate-600">
                    {r.bronze_count?.toLocaleString() ?? "—"}
                  </td>
                  <td className="px-4 py-2.5 text-right tabular-nums text-slate-600">
                    {r.silver_count?.toLocaleString() ?? "—"}
                  </td>
                  <td className="px-4 py-2.5 text-right tabular-nums">
                    {(r.quarantine_count ?? 0) > 0 ? (
                      <span className="text-amber-700 font-medium">
                        {r.quarantine_count!.toLocaleString()}
                      </span>
                    ) : (
                      <span className="text-slate-300">—</span>
                    )}
                  </td>
                  <td className="px-4 py-2.5 text-right tabular-nums text-slate-600">
                    {r.duration_seconds != null ? formatDuration(r.duration_seconds) : "—"}
                  </td>
                  <td className="px-4 py-2.5 text-xs text-slate-500" title={r.start_ts}>
                    {formatDistanceToNow(new Date(r.start_ts), { addSuffix: true })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

function formatDuration(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return s ? `${m}m ${s}s` : `${m}m`;
}
