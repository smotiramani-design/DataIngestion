import { useState } from "react";
import { Search, Power, Play } from "lucide-react";
import clsx from "clsx";
import { formatDistanceToNow } from "date-fns";

import PageHeader from "@/components/PageHeader";
import { BoolPill } from "@/components/StatusPill";
import { useAsync } from "@/lib/useAsync";
import { getFeeds, setFeedActive } from "@/api/queries";
import type { FeedConfig, SourceType } from "@/lib/types";

const SOURCE_TYPE_COLORS: Record<SourceType, string> = {
  API:       "bg-violet-100 text-violet-700",
  RDBMS:     "bg-blue-100 text-blue-700",
  JSON:      "bg-cyan-100 text-cyan-700",
  EXCEL:     "bg-emerald-100 text-emerald-700",
  CSV:       "bg-orange-100 text-orange-700",
  DELIMITED: "bg-amber-100 text-amber-700",
  FIXED:     "bg-rose-100 text-rose-700",
};

export default function FeedsPage() {
  const feeds = useAsync(getFeeds);
  const [filter, setFilter] = useState("");
  const [busyId, setBusyId] = useState<number | null>(null);

  const visible = (feeds.data ?? []).filter((f) =>
    f.feed_name.toLowerCase().includes(filter.toLowerCase()) ||
    f.target_table.toLowerCase().includes(filter.toLowerCase()),
  );

  const toggleActive = async (feed: FeedConfig) => {
    setBusyId(feed.feed_id);
    try {
      await setFeedActive(feed.feed_id, !feed.is_active);
      feeds.refresh();
    } finally {
      setBusyId(null);
    }
  };

  return (
    <>
      <PageHeader
        title="Feeds"
        subtitle={`${(feeds.data ?? []).filter(f => f.is_active).length} active · ${(feeds.data ?? []).length} total`}
      />

      <div className="px-8 py-6">
        {/* Filter bar */}
        <div className="card p-3 mb-4 flex items-center gap-2">
          <Search className="w-4 h-4 text-slate-400 ml-1" />
          <input
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="Filter by feed name or target table…"
            className="flex-1 outline-none text-sm bg-transparent"
          />
        </div>

        {/* Table */}
        <div className="card overflow-hidden">
          <table className="w-full text-sm table-fixed">
            <colgroup>
              <col className="w-48" />          {/* Name */}
              <col className="w-24" />          {/* Source */}
              <col />                            {/* Target table - flexible */}
              <col className="w-28" />          {/* Mode */}
              <col className="w-24" />          {/* Status */}
              <col className="w-44" />          {/* Owner */}
              <col className="w-28" />          {/* Updated */}
              <col className="w-24" />          {/* Actions */}
            </colgroup>
            <thead>
              <tr className="bg-slate-50 text-left text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Source</th>
                <th className="px-4 py-3">Target Table</th>
                <th className="px-4 py-3">Mode</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Owner</th>
                <th className="px-4 py-3">Updated</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {feeds.loading && (
                <tr><td colSpan={8} className="px-4 py-8 text-center text-slate-400">Loading…</td></tr>
              )}
              {!feeds.loading && visible.length === 0 && (
                <tr><td colSpan={8} className="px-4 py-8 text-center text-slate-400">
                  {filter ? "No feeds match this filter." : "No feeds configured."}
                </td></tr>
              )}
              {visible.map((feed) => (
                <tr key={feed.feed_id} className="hover:bg-slate-50">
                  <td className="px-4 py-3 font-medium text-navy">
                    {feed.feed_name}
                  </td>
                  <td className="px-4 py-3">
                    <span className={clsx("pill", SOURCE_TYPE_COLORS[feed.source_type])}>
                      {feed.source_type}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-slate-600 truncate">
                    {feed.target_table}
                  </td>
                  <td className="px-4 py-3 text-slate-600">{feed.load_mode}</td>
                  <td className="px-4 py-3">
                    <BoolPill value={feed.is_active} />
                  </td>
                  <td className="px-4 py-3 text-slate-500 text-xs truncate" title={feed.owner}>
                    {feed.owner}
                  </td>
                  <td className="px-4 py-3 text-slate-500 text-xs whitespace-nowrap">
                    {formatDistanceToNow(new Date(feed.updated_ts), { addSuffix: true })}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1 justify-end">
                      <button
                        className="btn-ghost"
                        title="Run feed now"
                        onClick={() => alert(`Would trigger Job: ingest_run_single_feed(${feed.feed_name})`)}
                      >
                        <Play className="w-3.5 h-3.5" />
                      </button>
                      <button
                        className={clsx(
                          "btn-ghost",
                          feed.is_active ? "hover:text-rose-600" : "hover:text-emerald-600",
                        )}
                        title={feed.is_active ? "Pause feed" : "Activate feed"}
                        disabled={busyId === feed.feed_id}
                        onClick={() => toggleActive(feed)}
                      >
                        <Power className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
