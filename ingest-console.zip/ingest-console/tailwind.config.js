/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Match the deck's Ocean Gradient palette
        navy:     "#0A1F44",
        deepblue: "#065A82",
        teal:     "#1C7293",
        midnight: "#21295C",
        ice:      "#E8F1F5",
        cream:    "#F7FAFC",
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "Consolas", "monospace"],
      },
    },
  },
  plugins: [],
};
