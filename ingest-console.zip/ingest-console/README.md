# Ingest Operator Console

A React + TypeScript single-page app for monitoring and operating the
[Ingestion Framework](../ingestion-framework). Talks directly to the
framework's Delta control tables (`feed_config`, `audit_log`, `error_log`)
via the Databricks Statement Execution API — no separate backend service
to host.

## What it does

- **Dashboard** — top-level KPIs (active feeds, runs in last 24h, success
  rate, quarantined records) plus a runs-by-hour stacked bar chart and a
  recent-runs ticker.
- **Feeds** — every row in `feed_config` with filter, source-type chips,
  pause/activate toggle, and per-feed run-now action.
- **Errors** — open + resolved error queue with expandable rows showing
  raw record JSON, expectation name, and stack trace; one-click Resolve.
- **Audit Log** — full run history (last 200) with status filter and feed
  search; surfaces source / Bronze / Silver / quarantined counts so the
  framework's no-record-loss reconciliation is visible at a glance.

## Quickstart

```bash
npm install
cp .env.example .env.local      # mock mode is on by default
npm run dev                      # http://localhost:5173
```

The app boots in **mock mode** — every page shows realistic fixture data
without needing a Databricks workspace. Useful for local dev, demos, and
running the test suite.

## Wiring it to a real Databricks workspace

Edit `.env.local`:

```ini
VITE_USE_MOCK_DATA=false
VITE_DATABRICKS_HOST=https://adb-1234567890.cloud.databricks.com
VITE_DATABRICKS_WAREHOUSE_ID=abc123def456              # SQL Warehouses → Connection details
VITE_DATABRICKS_TOKEN=dapi...                          # see security note below
VITE_INGEST_CATALOG=ingest_platform
VITE_INGEST_CONTROL_SCHEMA=control
```

The catalog and schema must match what the framework's Asset Bundle
deployed (default `ingest_platform.control`).

### Security: don't ship PATs in the browser

This README and `.env.example` use a Personal Access Token for brevity, but
PATs in the browser are a non-starter for production. Two paths to ship:

1. **Databricks Apps** (recommended) — host the static build inside
   Databricks Apps so the user's session token is propagated automatically.
   Replace the `Authorization: Bearer ${TOKEN}` line in
   `src/api/databricks.ts` with the in-app token endpoint.
2. **OAuth U2M** with PKCE — implement the OAuth dance against
   `/oidc/v1/authorize` and acquire short-lived tokens per session.
   Slightly more wiring but works outside Databricks.

Either way, drop `VITE_DATABRICKS_TOKEN` from `.env.local` before going to
production.

## Project layout

```
console/
├── index.html
├── package.json
├── vite.config.ts
├── tailwind.config.js
├── tsconfig*.json
├── .env.example
└── src/
    ├── main.tsx                     React entry
    ├── App.tsx                      Router
    ├── index.css                    Tailwind directives + base styles
    ├── api/
    │   ├── databricks.ts            Statement Execution API client
    │   └── queries.ts               Typed query functions (mock-aware)
    ├── components/
    │   ├── Layout.tsx               Sidebar + outlet shell
    │   ├── PageHeader.tsx           Shared page header
    │   └── StatusPill.tsx           Run status / severity / boolean pills
    ├── lib/
    │   ├── types.ts                 Mirrors the framework's table schemas
    │   └── useAsync.ts              Tiny data-fetching hook
    ├── mocks/
    │   └── fixtures.ts              Realistic offline data
    └── pages/
        ├── Dashboard.tsx
        ├── Feeds.tsx
        ├── Errors.tsx
        └── Audit.tsx
```

## How it talks to Delta

There's exactly one source of switching between mock and live data:
`VITE_USE_MOCK_DATA`. Every UI component imports from `@/api/queries`,
which checks that flag and either:

- returns from `@/mocks/fixtures` (with a small artificial delay so loading
  states are visible), or
- builds a parameterised SQL string and submits it via
  `@/api/databricks.executeQuery()`, which handles submit → poll → row
  mapping against the Statement Execution API.

The SQL strings in `queries.ts` are the actual queries that will run in
production — they're documented inline alongside the function that issues
them.

## Building for production

```bash
npm run build           # → dist/
npm run preview         # local preview of the built bundle
```

Drop `dist/` behind any static host (Databricks Apps, S3+CloudFront,
nginx, GitHub Pages…). The bundle has no server-side requirements.

## Adding a new page

1. Create `src/pages/YourPage.tsx`
2. Register it in `src/App.tsx` and `src/components/Layout.tsx`
3. If it needs new data, add a typed query function to `src/api/queries.ts`
   with both a mock branch (using `@/mocks/fixtures`) and a live SQL branch
4. The fetched data flows through `useAsync` for loading / error / refresh
