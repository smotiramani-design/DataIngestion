import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { MsalProvider } from "@azure/msal-react";

import { msalInstance } from "@/lib/auth/msalConfig";
import { ProjectProvider } from "@/lib/projectContext";
import App from "./App";
import "@/styles/globals.css";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
      staleTime: 30_000,
    },
  },
});

const USE_MOCK = import.meta.env.VITE_USE_MOCK === "true";

// In real mode, MSAL must finish processing the redirect response before we
// render. In mock mode we skip MSAL entirely.
async function bootstrap() {
  if (!USE_MOCK) {
    await msalInstance.initialize();
    await msalInstance.handleRedirectPromise();
  }

  ReactDOM.createRoot(document.getElementById("root")!).render(
    <React.StrictMode>
      <MsalProvider instance={msalInstance}>
        <QueryClientProvider client={queryClient}>
          <BrowserRouter>
            <ProjectProvider>
              <App />
            </ProjectProvider>
          </BrowserRouter>
        </QueryClientProvider>
      </MsalProvider>
    </React.StrictMode>,
  );
}

bootstrap();
