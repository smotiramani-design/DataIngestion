import { Routes, Route, Navigate } from "react-router-dom";

import Layout from "@/components/Layout";
import { RequireAuth, RequirePerm } from "@/lib/auth/RequireAuth";
import { useProject } from "@/lib/projectContext";

import LoginPage from "@/pages/LoginPage";
import AccessDeniedPage from "@/pages/AccessDeniedPage";
import DashboardPage from "@/pages/DashboardPage";
import ProjectsPage from "@/pages/ProjectsPage";
import AuditPage from "@/pages/AuditPage";
import UsersPage from "@/pages/UsersPage";
import SettingsPage from "@/pages/SettingsPage";

import FeedsPage from "@/pages/ingest/FeedsPage";
import IngestRunsPage from "@/pages/ingest/IngestRunsPage";
import IngestErrorsPage from "@/pages/ingest/IngestErrorsPage";

import DqRulesPage from "@/pages/dq/DqRulesPage";
import DqRunsPage from "@/pages/dq/DqRunsPage";
import ApprovalsPage from "@/pages/dq/ApprovalsPage";

import TxJobsPage from "@/pages/transform/TxJobsPage";
import TxStepsPage from "@/pages/transform/TxStepsPage";
import TxRunsPage from "@/pages/transform/TxRunsPage";
import TxLineagePage from "@/pages/transform/TxLineagePage";

/**
 * Helper: gate a route by permission, scoped to the currently selected project.
 * The permission check is re-evaluated whenever the active project changes,
 * so switching from a project where you are an owner to one where you are a
 * read-only user automatically hides write screens.
 */
function PermRoute({
  perm,
  children,
}: {
  perm: Parameters<typeof RequirePerm>[0]["perm"];
  children: React.ReactNode;
}) {
  const { selected } = useProject();
  return (
    <RequirePerm perm={perm} project_code={selected?.project_code}>
      {children}
    </RequirePerm>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/access-denied"
             element={<RequireAuth><AccessDeniedPage /></RequireAuth>} />

      <Route element={<RequireAuth><Layout /></RequireAuth>}>
        <Route index element={<Navigate to="/dashboard" replace />} />

        <Route path="/dashboard"
               element={<PermRoute perm="project.read"><DashboardPage /></PermRoute>} />
        <Route path="/projects"
               element={<PermRoute perm="project.read"><ProjectsPage /></PermRoute>} />

        {/* Ingestion */}
        <Route path="/ingest/feeds"
               element={<PermRoute perm="feed.read"><FeedsPage /></PermRoute>} />
        <Route path="/ingest/runs"
               element={<PermRoute perm="ingest_run.read"><IngestRunsPage /></PermRoute>} />
        <Route path="/ingest/errors"
               element={<PermRoute perm="ingest_error.read"><IngestErrorsPage /></PermRoute>} />

        {/* DQ */}
        <Route path="/dq/rules"
               element={<PermRoute perm="rule.read"><DqRulesPage /></PermRoute>} />
        <Route path="/dq/runs"
               element={<PermRoute perm="dq_run.read"><DqRunsPage /></PermRoute>} />
        <Route path="/dq/approvals"
               element={<PermRoute perm="dq_approve.write"><ApprovalsPage /></PermRoute>} />

        {/* Transformation */}
        <Route path="/transform/jobs"
               element={<PermRoute perm="tx_job.read"><TxJobsPage /></PermRoute>} />
        <Route path="/transform/jobs/:jobId/steps"
               element={<PermRoute perm="tx_step.read"><TxStepsPage /></PermRoute>} />
        <Route path="/transform/runs"
               element={<PermRoute perm="tx_run.read"><TxRunsPage /></PermRoute>} />
        <Route path="/transform/lineage"
               element={<PermRoute perm="tx_run.read"><TxLineagePage /></PermRoute>} />

        {/* Platform */}
        <Route path="/audit"
               element={<PermRoute perm="audit.read"><AuditPage /></PermRoute>} />
        <Route path="/users"
               element={<PermRoute perm="user.read"><UsersPage /></PermRoute>} />
        <Route path="/settings"
               element={<PermRoute perm="settings.write"><SettingsPage /></PermRoute>} />

        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Route>
    </Routes>
  );
}
