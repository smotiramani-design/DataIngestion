export type DqLayer = "FILE" | "BUSINESS_RULE" | "POST_TRANSFORM";
export type DqSeverity = "INFO" | "WARN" | "BLOCK";
export type DqCheckType =
  | "SCHEMA"
  | "ROW_COUNT_MIN"
  | "ROW_COUNT_DRIFT"
  | "NULL_PCT_MAX"
  | "PRIMARY_KEY"
  | "DOMAIN"
  | "EXPRESSION"
  | "REFERENTIAL_INTEGRITY"
  | "AGGREGATE_PARITY";
export type DqStatus = "DRAFT" | "PROPOSED" | "APPROVED" | "DEPRECATED";

export interface DqRule {
  rule_id: string;
  project_id: number;
  project_code: string;
  current_version: number;
  name: string;
  description: string | null;
  layer: DqLayer;
  check_type: DqCheckType;
  severity: DqSeverity;
  datasets: string[];
  expression: string | null;
  params: Record<string, string>;
  owner: string;
  status: DqStatus;
  enabled: boolean;
  created_at: string;
  updated_at: string;
}

export type TriggeringFramework = "INGEST" | "TRANSFORM" | "STANDALONE" | "API" | null;
export type DqRunStatus = "RUNNING" | "PASS" | "WARN" | "FAIL" | "ERROR";

export interface DqValidationRun {
  run_id: string;
  project_id: number;
  project_code: string;
  trigger_type: string;
  trigger_ref: string | null;
  triggering_framework: TriggeringFramework;
  ingest_run_id: string | null;
  tx_run_id: string | null;
  start_ts: string;
  end_ts: string | null;
  status: DqRunStatus;
  rules_evaluated: number | null;
  rules_passed: number | null;
  rules_warned: number | null;
  rules_failed: number | null;
  records_checked: number | null;
  duration_sec: number | null;
  should_block_publish: boolean | null;
  framework_version: string;
}

export interface DqValidationError {
  error_id: number;
  project_id: number;
  project_code: string;
  run_id: string;
  rule_id: string;
  rule_version: number;
  dataset: string;
  error_ts: string;
  severity: DqSeverity;
  failure_count: number;
  sample_count: number;
  raw_record: string | null;
  error_message: string | null;
}
