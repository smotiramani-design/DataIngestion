/** Subset of feed_config used in the console. */
export interface Feed {
  feed_id: number;
  project_id: number;
  project_code: string;
  feed_name: string;
  source_type: "API" | "RDBMS" | "JSON" | "XML" | "EXCEL" | "CSV" | "DELIMITED" | "FIXED";
  source_table: string | null;
  target_bronze_table: string;
  event_time_column: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  created_by: string | null;
}

/** Subset of audit_log used in the console. */
export interface IngestRun {
  run_id: string;
  project_id: number;
  project_code: string;
  feed_id: number;
  feed_name: string;
  start_ts: string;
  end_ts: string | null;
  status: "running" | "success" | "failed" | "aborted";
  rows_in: number | null;
  rows_out: number | null;
  duration_sec: number | null;
  target_table: string | null;
  max_event_ts: string | null;
  error_message: string | null;
  framework_version: string;
}

/** Subset of error_log used in the console. */
export interface IngestError {
  error_id: number;
  project_id: number;
  project_code: string;
  run_id: string;
  feed_name: string;
  error_ts: string;
  error_type: string;
  error_message: string;
  raw_record: string | null;
}
