export type TxStepType =
  | "read_delta"
  | "read_jdbc"
  | "cleanse"
  | "dedup"
  | "lookup"
  | "scd1"
  | "scd2"
  | "aggregate"
  | "mask_pii"
  | "partition"
  | "write_delta"
  | "custom_sql";

export type TxLayer = "bronze" | "silver" | "gold";
export type TxWriteMode = "merge" | "overwrite" | "append";

export interface TxJob {
  job_id: number;
  project_id: number;
  project_code: string;
  job_code: string;
  job_version: number;
  source_layer: TxLayer;
  target_layer: TxLayer;
  target_catalog: string;
  target_schema: string;
  target_table: string;
  write_mode: TxWriteMode;
  primary_key_cols: string[];
  partition_cols: string[];
  schedule_cron: string | null;
  block_on_dq_fail: boolean;
  git_sha: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface TxStep {
  step_id: number;
  job_id: number;
  project_id: number;
  step_order: number;
  step_name: string;
  step_type: TxStepType;
  input_alias: string | null;
  output_alias: string | null;
  config: Record<string, unknown>;
  depends_on_step_ids: number[];
  error_strategy: "fail" | "skip" | "route_to_quarantine";
  expected_min_rows: number | null;
  expected_max_rows: number | null;
  enabled: boolean;
}

export type TxRunStatus = "running" | "success" | "failed" | "aborted";
export type TxDqVerdict = "pass" | "warn" | "block" | "not_run" | null;

export interface TxRun {
  tx_run_id: string;
  project_id: number;
  project_code: string;
  job_id: number;
  job_code: string;
  job_version: number;
  adf_pipeline_run_id: string | null;
  triggered_by: string;
  upstream_run_id: string | null;
  effective_date: string | null;
  dry_run: boolean;
  override_target: string | null;
  started_at: string;
  ended_at: string | null;
  status: TxRunStatus;
  rows_read: number | null;
  rows_written: number | null;
  rows_rejected: number | null;
  duration_sec: number | null;
  dq_verdict: TxDqVerdict;
  dq_run_id: string | null;
  should_block_publish: boolean | null;
  error_message: string | null;
}

export interface TxLineageRow {
  lineage_id: number;
  tx_run_id: string;
  project_id: number;
  job_id: number;
  src_table_fqn: string;
  tgt_table_fqn: string;
  transform_type: string | null;
  captured_at: string;
}
