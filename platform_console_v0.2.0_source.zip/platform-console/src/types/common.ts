/**
 * Shared type for the project registry (platform.control.projects).
 * Read-only across all three frameworks.
 */
export interface Project {
  project_id: number;
  project_code: string;
  project_name: string;
  default_catalog: string;
  bronze_schema: string;
  silver_schema: string;
  gold_schema: string;
  alert_email: string;
  owner_team: string;
  ingest_framework_version: string;
  tx_framework_version: string;
  dq_framework_version: string;
  is_active: boolean;
}

/**
 * The minimal user identity surfaced by MSAL after sign-in.
 * `roles` come from the JWT `roles` claim populated via Entra App Roles.
 */
export interface AppUser {
  email: string;
  display_name: string;
  oid: string;                       // Entra Object ID
  roles: string[];                   // raw role names from token
  /** Per-project role assignments. Backend resolves these from a project_user
   *  table; for the mock client we hard-code per-user. */
  project_roles: Record<string, string[]>;  // project_code -> role names
}
