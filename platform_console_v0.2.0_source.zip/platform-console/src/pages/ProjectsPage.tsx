import { useQuery } from "@tanstack/react-query";
import { Database } from "lucide-react";

import { api } from "@/api/client";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Pill } from "@/components/Pill";

export default function ProjectsPage() {
  const { data: projects = [], isLoading } = useQuery({
    queryKey: ["projects"],
    queryFn: () => api.listProjects(),
  });

  return (
    <>
      <PageHeader
        title="Projects"
        subtitle="The shared registry. Owned by the Ingestion FW; consumed by all three frameworks."
      />

      <div className="px-8 py-6 max-w-[1400px]">
        <div className="card overflow-hidden">
          {isLoading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading…</div>
          ) : projects.length === 0 ? (
            <EmptyState icon={Database} title="No projects" />
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Code</th>
                  <th>Name</th>
                  <th>Default catalog</th>
                  <th>Owner team</th>
                  <th>Ingest v.</th>
                  <th>TX v.</th>
                  <th>DQ v.</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {projects.map((p) => (
                  <tr key={p.project_code}>
                    <td className="font-mono font-semibold text-ink">{p.project_code}</td>
                    <td>{p.project_name}</td>
                    <td className="font-mono text-[13px]">{p.default_catalog}</td>
                    <td>{p.owner_team}</td>
                    <td className="font-mono text-[13px]">{p.ingest_framework_version}</td>
                    <td className="font-mono text-[13px]">{p.tx_framework_version}</td>
                    <td className="font-mono text-[13px]">{p.dq_framework_version}</td>
                    <td>
                      <Pill tone={p.is_active ? "success" : "neutral"}>
                        {p.is_active ? "Active" : "Inactive"}
                      </Pill>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}
