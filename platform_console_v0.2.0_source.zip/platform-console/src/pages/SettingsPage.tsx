import { Settings as SettingsIcon } from "lucide-react";

import { PageHeader } from "@/components/PageHeader";
import { Pill } from "@/components/Pill";
import { useProject } from "@/lib/projectContext";

export default function SettingsPage() {
  const { selected } = useProject();

  if (!selected) return null;

  return (
    <>
      <PageHeader
        title="Settings"
        subtitle={`Configuration for ${selected.project_code}`}
      />

      <div className="px-8 py-6 max-w-[1400px] space-y-4">
        {/* Project identity */}
        <div className="card overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3 border-b border-surface-border">
            <h3 className="text-sm font-semibold">Project identity</h3>
            <Pill tone="warn">External · read-only</Pill>
          </div>
          <table className="data-table">
            <tbody>
              {Object.entries({
                "Project ID": selected.project_id,
                "Project code": selected.project_code,
                "Project name": selected.project_name,
                "Default catalog": selected.default_catalog,
                "Bronze schema": selected.bronze_schema,
                "Silver schema": selected.silver_schema,
                "Gold schema": selected.gold_schema,
                "Alert email": selected.alert_email,
                "Owner team": selected.owner_team,
              }).map(([k, v]) => (
                <tr key={k}>
                  <td className="w-44 text-graphite-muted text-xs uppercase tracking-wider font-semibold">
                    {k}
                  </td>
                  <td className="font-mono text-[13px]">{String(v)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Framework versions */}
        <div className="card overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3 border-b border-surface-border">
            <h3 className="text-sm font-semibold">Framework versions in use</h3>
            <SettingsIcon className="h-4 w-4 text-graphite-muted" />
          </div>
          <div className="grid grid-cols-3 divide-x divide-surface-border">
            {[
              ["Ingestion FW", selected.ingest_framework_version],
              ["Transformation FW", selected.tx_framework_version],
              ["DQ FW", selected.dq_framework_version],
            ].map(([label, ver]) => (
              <div key={label} className="px-5 py-4">
                <div className="text-xs text-graphite-muted uppercase tracking-wider font-semibold">{label}</div>
                <div className="font-mono text-lg mt-1">{ver}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="text-xs text-graphite-muted">
          Project identity is owned by the platform-control plane and edited
          via the Projects table directly. Framework versions are pinned per
          project — speak to your platform admin to coordinate upgrades.
        </div>
      </div>
    </>
  );
}
