import { useQuery } from "@tanstack/react-query";
import {
  Activity, ShieldCheck, Cog, AlertTriangle, ArrowRight,
} from "lucide-react";
import { Link } from "react-router-dom";
import type { LucideIcon } from "lucide-react";

import { api } from "@/api/client";
import { useProject } from "@/lib/projectContext";
import { PageHeader } from "@/components/PageHeader";
import { Pill } from "@/components/Pill";
import { EmptyState } from "@/components/EmptyState";

function Kpi({
  label, value, icon: Icon, trend,
}: {
  label: string;
  value: string | number;
  icon: LucideIcon;
  trend?: string;
}) {
  return (
    <div className="card-pad">
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="text-[11px] uppercase tracking-wider text-graphite-muted font-semibold">
            {label}
          </div>
          <div className="text-2xl font-semibold text-ink mt-1 tabular-nums">{value}</div>
          {trend && <div className="text-xs text-graphite-muted mt-1">{trend}</div>}
        </div>
        <div className="h-9 w-9 rounded-md bg-teal/10 flex items-center justify-center">
          <Icon className="h-4 w-4 text-teal-deep" />
        </div>
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const { selected, projects, loading } = useProject();
  const code = selected?.project_code;

  const { data: ingestRuns = [] } = useQuery({
    enabled: !!code,
    queryKey: ["ingestRuns", code],
    queryFn: () => api.listIngestRuns(code!, { limit: 50 }),
  });
  const { data: dqRuns = [] } = useQuery({
    enabled: !!code,
    queryKey: ["dqRuns", code],
    queryFn: () => api.listDqRuns(code!, { limit: 50 }),
  });
  const { data: txRuns = [] } = useQuery({
    enabled: !!code,
    queryKey: ["txRuns", code],
    queryFn: () => api.listTxRuns(code!, { limit: 50 }),
  });
  const { data: rules = [] } = useQuery({
    enabled: !!code,
    queryKey: ["rules", code],
    queryFn: () => api.listRules(code!),
  });
  const { data: pendingApprovals = [] } = useQuery({
    enabled: !!code,
    queryKey: ["pending", code],
    queryFn: () => api.listPendingApprovals(code!),
  });

  if (loading) return <div className="p-8 text-sm text-graphite-muted">Loading…</div>;
  if (!selected) {
    return (
      <EmptyState
        icon={AlertTriangle}
        title="No projects available"
        description="No active projects found. Ask a platform admin to register your project."
      />
    );
  }

  const ingestSuccess = ingestRuns.filter((r) => r.status === "success").length;
  const ingestPassRate = ingestRuns.length
    ? Math.round((ingestSuccess / ingestRuns.length) * 100)
    : 100;

  const dqPass = dqRuns.filter((r) => r.status === "PASS").length;
  const dqPassRate = dqRuns.length
    ? Math.round((dqPass / dqRuns.length) * 100)
    : 100;

  const txSuccess = txRuns.filter((r) => r.status === "success").length;
  const txPassRate = txRuns.length
    ? Math.round((txSuccess / txRuns.length) * 100)
    : 100;

  const activeRules = rules.filter((r) => r.enabled && r.status === "APPROVED").length;

  return (
    <>
      <PageHeader
        title="Dashboard"
        subtitle={`${selected.project_name} (${selected.project_code}) · cross-framework health`}
      />

      <div className="px-8 py-6 max-w-[1400px] space-y-6">
        {/* KPI grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Kpi
            label="Ingest pass rate (50)"
            value={`${ingestPassRate}%`}
            icon={Activity}
            trend={`${ingestRuns.length} runs · ${ingestSuccess} success`}
          />
          <Kpi
            label="DQ pass rate (50)"
            value={`${dqPassRate}%`}
            icon={ShieldCheck}
            trend={`${dqRuns.length} runs · ${dqPass} pass`}
          />
          <Kpi
            label="Transform success (50)"
            value={`${txPassRate}%`}
            icon={Cog}
            trend={`${txRuns.length} runs · ${txSuccess} success`}
          />
          <Kpi
            label="Active DQ rules"
            value={activeRules}
            icon={ShieldCheck}
            trend={`${pendingApprovals.length} pending approval`}
          />
        </div>

        {/* Cross-framework integration card */}
        <div className="card-pad">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-[11px] uppercase tracking-wider text-graphite-muted font-semibold">
                Framework versions
              </div>
              <div className="mt-2 flex gap-3 text-sm">
                <div>
                  <div className="text-xs text-graphite-muted">Ingestion</div>
                  <div className="font-mono">{selected.ingest_framework_version}</div>
                </div>
                <div>
                  <div className="text-xs text-graphite-muted">Transform</div>
                  <div className="font-mono">{selected.tx_framework_version}</div>
                </div>
                <div>
                  <div className="text-xs text-graphite-muted">DQ</div>
                  <div className="font-mono">{selected.dq_framework_version}</div>
                </div>
              </div>
            </div>
            <div>
              <div className="text-[11px] uppercase tracking-wider text-graphite-muted font-semibold">
                Active projects
              </div>
              <div className="mt-2 text-sm">{projects.filter((p) => p.is_active).length} of {projects.length}</div>
            </div>
          </div>
        </div>

        {/* Recent activity grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="card overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3 border-b border-surface-border">
              <div className="text-sm font-semibold">Recent ingest runs</div>
              <Link to="/ingest/runs" className="text-xs text-teal-deep flex items-center gap-1 hover:underline">
                View all <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
            {ingestRuns.length === 0
              ? <div className="p-5 text-sm text-graphite-muted">No runs yet.</div>
              : (
                <ul>
                  {ingestRuns.slice(0, 4).map((r) => (
                    <li key={r.run_id} className="flex items-center justify-between gap-2 px-5 py-2 border-b border-surface-border last:border-0">
                      <div className="min-w-0">
                        <div className="text-sm truncate">{r.feed_name}</div>
                        <div className="text-xs text-graphite-muted font-mono truncate">{r.run_id}</div>
                      </div>
                      <Pill tone={r.status === "success" ? "success" : r.status === "failed" ? "danger" : "warn"}>
                        {r.status}
                      </Pill>
                    </li>
                  ))}
                </ul>
              )}
          </div>

          <div className="card overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3 border-b border-surface-border">
              <div className="text-sm font-semibold">Recent DQ validations</div>
              <Link to="/dq/runs" className="text-xs text-teal-deep flex items-center gap-1 hover:underline">
                View all <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
            {dqRuns.length === 0
              ? <div className="p-5 text-sm text-graphite-muted">No runs yet.</div>
              : (
                <ul>
                  {dqRuns.slice(0, 4).map((r) => (
                    <li key={r.run_id} className="flex items-center justify-between gap-2 px-5 py-2 border-b border-surface-border last:border-0">
                      <div className="min-w-0">
                        <div className="text-sm truncate">{r.triggering_framework ?? "—"} trigger</div>
                        <div className="text-xs text-graphite-muted font-mono truncate">{r.run_id}</div>
                      </div>
                      <Pill tone={r.status === "PASS" ? "success" : r.status === "WARN" ? "warn" : "danger"}>
                        {r.status}
                      </Pill>
                    </li>
                  ))}
                </ul>
              )}
          </div>

          <div className="card overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3 border-b border-surface-border">
              <div className="text-sm font-semibold">Recent transform runs</div>
              <Link to="/transform/runs" className="text-xs text-teal-deep flex items-center gap-1 hover:underline">
                View all <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
            {txRuns.length === 0
              ? <div className="p-5 text-sm text-graphite-muted">No runs yet.</div>
              : (
                <ul>
                  {txRuns.slice(0, 4).map((r) => (
                    <li key={r.tx_run_id} className="flex items-center justify-between gap-2 px-5 py-2 border-b border-surface-border last:border-0">
                      <div className="min-w-0">
                        <div className="text-sm truncate">{r.job_code}</div>
                        <div className="text-xs text-graphite-muted font-mono truncate">{r.tx_run_id}</div>
                      </div>
                      <Pill tone={r.status === "success" ? "success" : r.status === "failed" ? "danger" : "warn"}>
                        {r.status}
                      </Pill>
                    </li>
                  ))}
                </ul>
              )}
          </div>
        </div>
      </div>
    </>
  );
}
