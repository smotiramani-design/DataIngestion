import { useQuery } from "@tanstack/react-query";
import { AlertTriangle } from "lucide-react";

import { api } from "@/api/client";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { useProject } from "@/lib/projectContext";

export default function IngestErrorsPage() {
  const { selected } = useProject();
  const code = selected?.project_code;

  const { data: errors = [], isLoading } = useQuery({
    enabled: !!code,
    queryKey: ["ingestErrors", code],
    queryFn: () => api.listIngestErrors(code!, { limit: 200 }),
  });

  if (!code) return null;

  return (
    <>
      <PageHeader title="Ingestion errors" subtitle={`error_log for ${code}`} />

      <div className="px-8 py-6 max-w-[1400px]">
        <div className="card overflow-hidden">
          {isLoading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading…</div>
          ) : errors.length === 0 ? (
            <EmptyState icon={AlertTriangle} title="No errors logged" />
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Error TS</th>
                  <th>Feed</th>
                  <th>Run ID</th>
                  <th>Type</th>
                  <th>Message</th>
                </tr>
              </thead>
              <tbody>
                {errors.map((e) => (
                  <tr key={e.error_id}>
                    <td className="font-mono text-[12px]">{e.error_ts.replace("T", " ").slice(0, 19)}</td>
                    <td className="font-mono text-[13px]">{e.feed_name}</td>
                    <td className="font-mono text-[12px]">{e.run_id}</td>
                    <td className="font-mono text-[12px]">{e.error_type}</td>
                    <td className="text-[13px]">{e.error_message}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}
