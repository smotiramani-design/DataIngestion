import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Cog, Plus, X } from "lucide-react";

import { api } from "@/api/client";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Pill } from "@/components/Pill";
import { useProject } from "@/lib/projectContext";
import { usePermissions } from "@/lib/auth/useAuth";
import type { Feed } from "@/types/ingest";

const SOURCE_TYPES: Feed["source_type"][] = [
  "API", "RDBMS", "JSON", "XML", "EXCEL", "CSV", "DELIMITED", "FIXED",
];

function CreateFeedDialog({ project_code, onClose }: { project_code: string; onClose: () => void }) {
  const qc = useQueryClient();
  const [form, setForm] = useState<Partial<Feed>>({
    source_type: "CSV",
    is_active: true,
  });

  const m = useMutation({
    mutationFn: () =>
      api.createFeed({
        project_code,
        feed_name: form.feed_name!,
        source_type: form.source_type!,
        source_table: form.source_table ?? null,
        target_bronze_table: form.target_bronze_table!,
        event_time_column: form.event_time_column ?? null,
        is_active: form.is_active ?? true,
        created_by: null,
      } as Parameters<typeof api.createFeed>[0]),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["feeds", project_code] });
      onClose();
    },
  });

  return (
    <div className="fixed inset-0 bg-navy/40 flex items-center justify-center z-40">
      <div className="card-pad w-full max-w-xl">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold text-ink">New feed</h2>
          <button onClick={onClose}><X className="h-5 w-5 text-graphite-muted" /></button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="label">Feed name</label>
            <input
              className="input font-mono"
              placeholder="orders_csv"
              value={form.feed_name ?? ""}
              onChange={(e) => setForm({ ...form, feed_name: e.target.value })}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">Source type</label>
              <select
                className="input"
                value={form.source_type}
                onChange={(e) => setForm({ ...form, source_type: e.target.value as Feed["source_type"] })}
              >
                {SOURCE_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Source table (optional)</label>
              <input
                className="input font-mono"
                placeholder="schema.table"
                value={form.source_table ?? ""}
                onChange={(e) => setForm({ ...form, source_table: e.target.value })}
              />
            </div>
          </div>
          <div>
            <label className="label">Target Bronze table</label>
            <input
              className="input font-mono"
              placeholder="catalog.bronze.table"
              value={form.target_bronze_table ?? ""}
              onChange={(e) => setForm({ ...form, target_bronze_table: e.target.value })}
            />
          </div>
          <div>
            <label className="label">Event-time column (optional)</label>
            <input
              className="input font-mono"
              placeholder="event_ts"
              value={form.event_time_column ?? ""}
              onChange={(e) => setForm({ ...form, event_time_column: e.target.value })}
            />
            <p className="text-xs text-graphite-muted mt-1">
              Drives <code className="font-mono">audit_log.max_event_ts</code> for Transform consumers.
            </p>
          </div>
        </div>

        {m.isError && (
          <div className="mt-3 text-sm text-danger">Failed: {(m.error as Error).message}</div>
        )}

        <div className="mt-5 flex justify-end gap-2">
          <button className="btn-secondary" onClick={onClose}>Cancel</button>
          <button
            className="btn-primary"
            disabled={!form.feed_name || !form.target_bronze_table || m.isPending}
            onClick={() => m.mutate()}
          >
            Create feed
          </button>
        </div>
      </div>
    </div>
  );
}

export default function FeedsPage() {
  const { selected } = useProject();
  const { can } = usePermissions();
  const qc = useQueryClient();
  const [creating, setCreating] = useState(false);

  const code = selected?.project_code;
  const canWrite = !!code && can("feed.write", { project_code: code });

  const { data: feeds = [], isLoading } = useQuery({
    enabled: !!code,
    queryKey: ["feeds", code],
    queryFn: () => api.listFeeds(code!),
  });

  const toggle = useMutation({
    mutationFn: ({ feed_id, is_active }: { feed_id: number; is_active: boolean }) =>
      api.setFeedActive(feed_id, is_active),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["feeds", code] }),
  });

  if (!code) return null;

  return (
    <>
      <PageHeader
        title="Feeds"
        subtitle={`Ingestion configuration for ${selected.project_code}`}
        actions={
          canWrite && (
            <button className="btn-primary" onClick={() => setCreating(true)}>
              <Plus className="h-4 w-4" /> New feed
            </button>
          )
        }
      />

      <div className="px-8 py-6 max-w-[1400px]">
        <div className="card overflow-hidden">
          {isLoading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading…</div>
          ) : feeds.length === 0 ? (
            <EmptyState icon={Cog} title="No feeds" description="Create your first feed to start ingesting." />
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Feed</th>
                  <th>Source type</th>
                  <th>Source table</th>
                  <th>Target Bronze</th>
                  <th>Event-time col</th>
                  <th>Status</th>
                  <th className="w-32"></th>
                </tr>
              </thead>
              <tbody>
                {feeds.map((f) => (
                  <tr key={f.feed_id}>
                    <td className="font-mono text-[13px] font-semibold">{f.feed_name}</td>
                    <td><Pill tone="info">{f.source_type}</Pill></td>
                    <td className="font-mono text-[13px]">{f.source_table ?? "—"}</td>
                    <td className="font-mono text-[13px]">{f.target_bronze_table}</td>
                    <td className="font-mono text-[13px]">{f.event_time_column ?? "—"}</td>
                    <td>
                      <Pill tone={f.is_active ? "success" : "neutral"}>
                        {f.is_active ? "Active" : "Disabled"}
                      </Pill>
                    </td>
                    <td className="text-right">
                      {canWrite && (
                        <button
                          className="btn-secondary text-xs"
                          onClick={() => toggle.mutate({ feed_id: f.feed_id, is_active: !f.is_active })}
                        >
                          {f.is_active ? "Disable" : "Enable"}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {creating && <CreateFeedDialog project_code={code} onClose={() => setCreating(false)} />}
    </>
  );
}
