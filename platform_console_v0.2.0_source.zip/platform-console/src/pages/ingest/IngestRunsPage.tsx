import { useQuery } from "@tanstack/react-query";
import { PlayCircle } from "lucide-react";

import { api } from "@/api/client";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Pill } from "@/components/Pill";
import { useProject } from "@/lib/projectContext";

export default function IngestRunsPage() {
  const { selected } = useProject();
  const code = selected?.project_code;

  const { data: runs = [], isLoading } = useQuery({
    enabled: !!code,
    queryKey: ["ingestRuns", code, "all"],
    queryFn: () => api.listIngestRuns(code!, { limit: 200 }),
  });

  if (!code) return null;

  return (
    <>
      <PageHeader title="Ingestion runs" subtitle={`audit_log for ${code}`} />

      <div className="px-8 py-6 max-w-[1400px]">
        <div className="card overflow-hidden">
          {isLoading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading…</div>
          ) : runs.length === 0 ? (
            <EmptyState icon={PlayCircle} title="No runs yet" />
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Run ID</th>
                  <th>Feed</th>
                  <th>Started</th>
                  <th className="text-right">Rows in</th>
                  <th className="text-right">Rows out</th>
                  <th className="text-right">Duration</th>
                  <th>Target</th>
                  <th>Max event ts</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {runs.map((r) => (
                  <tr key={r.run_id}>
                    <td className="font-mono text-[12px]">{r.run_id}</td>
                    <td>{r.feed_name}</td>
                    <td className="font-mono text-[12px]">{r.start_ts.replace("T", " ").slice(0, 19)}</td>
                    <td className="text-right tabular-nums">{r.rows_in?.toLocaleString() ?? "—"}</td>
                    <td className="text-right tabular-nums">{r.rows_out?.toLocaleString() ?? "—"}</td>
                    <td className="text-right tabular-nums">{r.duration_sec ? `${r.duration_sec}s` : "—"}</td>
                    <td className="font-mono text-[12px]">{r.target_table ?? "—"}</td>
                    <td className="font-mono text-[12px]">{r.max_event_ts?.slice(0, 19) ?? "—"}</td>
                    <td>
                      <Pill tone={
                        r.status === "success" ? "success" :
                        r.status === "running" ? "info" :
                        r.status === "failed"  ? "danger" : "warn"
                      }>{r.status}</Pill>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}
