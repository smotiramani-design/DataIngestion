import { useQuery } from "@tanstack/react-query";
import { GitBranch, ArrowRight } from "lucide-react";

import { api } from "@/api/client";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Pill } from "@/components/Pill";
import { useProject } from "@/lib/projectContext";

export default function TxLineagePage() {
  const { selected } = useProject();
  const code = selected?.project_code;

  const { data: lineage = [], isLoading } = useQuery({
    enabled: !!code,
    queryKey: ["txLineage", code],
    queryFn: () => api.listTxLineage(code!, { limit: 200 }),
  });

  if (!code) return null;

  return (
    <>
      <PageHeader
        title="Transform lineage"
        subtitle={`Source → target captured by every transform run for ${code}`}
      />

      <div className="px-8 py-6 max-w-[1400px]">
        <div className="card overflow-hidden">
          {isLoading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading…</div>
          ) : lineage.length === 0 ? (
            <EmptyState icon={GitBranch} title="No lineage captured yet" />
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th>tx_run_id</th>
                  <th>Source FQN</th>
                  <th></th>
                  <th>Target FQN</th>
                  <th>Transform</th>
                  <th>Captured</th>
                </tr>
              </thead>
              <tbody>
                {lineage.map((l) => (
                  <tr key={l.lineage_id}>
                    <td className="font-mono text-[12px]">{l.tx_run_id}</td>
                    <td className="font-mono text-[12px]">{l.src_table_fqn}</td>
                    <td className="w-8 text-center"><ArrowRight className="h-4 w-4 text-graphite-muted inline" /></td>
                    <td className="font-mono text-[12px]">{l.tgt_table_fqn}</td>
                    <td><Pill tone="info">{l.transform_type ?? "—"}</Pill></td>
                    <td className="font-mono text-[12px]">{l.captured_at.replace("T", " ").slice(0, 19)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}
