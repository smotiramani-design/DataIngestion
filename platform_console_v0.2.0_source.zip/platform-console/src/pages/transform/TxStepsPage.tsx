import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ListTree, Plus, X, ArrowLeft } from "lucide-react";

import { api } from "@/api/client";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Pill } from "@/components/Pill";
import { useProject } from "@/lib/projectContext";
import { usePermissions } from "@/lib/auth/useAuth";
import type { TxStep, TxStepType } from "@/types/transform";

const STEP_TYPES: TxStepType[] = [
  "read_delta", "read_jdbc", "cleanse", "dedup", "lookup",
  "scd1", "scd2", "aggregate", "mask_pii", "partition",
  "write_delta", "custom_sql",
];

function AddStepDialog({
  job_id, nextOrder, onClose,
}: { job_id: number; nextOrder: number; onClose: () => void }) {
  const qc = useQueryClient();
  const [form, setForm] = useState({
    step_order: nextOrder,
    step_name: "",
    step_type: "cleanse" as TxStepType,
    input_alias: "",
    output_alias: "",
    config_json: "{}",
    error_strategy: "fail" as TxStep["error_strategy"],
  });

  const m = useMutation({
    mutationFn: () => {
      let config: Record<string, unknown> = {};
      try { config = JSON.parse(form.config_json || "{}"); } catch { config = {}; }
      return api.upsertTxStep({
        job_id,
        step_order: form.step_order,
        step_name: form.step_name,
        step_type: form.step_type,
        input_alias: form.input_alias || null,
        output_alias: form.output_alias || null,
        config,
        error_strategy: form.error_strategy,
        enabled: true,
        depends_on_step_ids: [],
        expected_min_rows: null,
        expected_max_rows: null,
      });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["txSteps", job_id] });
      onClose();
    },
  });

  return (
    <div className="fixed inset-0 bg-navy/40 flex items-center justify-center z-40">
      <div className="card-pad w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold text-ink">Add step</h2>
          <button onClick={onClose}><X className="h-5 w-5 text-graphite-muted" /></button>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div>
            <label className="label">Order</label>
            <input className="input font-mono" type="number" min={1}
                   value={form.step_order}
                   onChange={(e) => setForm({ ...form, step_order: Number(e.target.value) })} />
          </div>
          <div>
            <label className="label">Type</label>
            <select className="input" value={form.step_type}
                    onChange={(e) => setForm({ ...form, step_type: e.target.value as TxStepType })}>
              {STEP_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label className="label">On error</label>
            <select className="input" value={form.error_strategy}
                    onChange={(e) => setForm({ ...form, error_strategy: e.target.value as TxStep["error_strategy"] })}>
              <option value="fail">fail</option>
              <option value="skip">skip</option>
              <option value="route_to_quarantine">route_to_quarantine</option>
            </select>
          </div>
        </div>

        <div className="mt-3">
          <label className="label">Step name</label>
          <input className="input font-mono"
                 value={form.step_name}
                 onChange={(e) => setForm({ ...form, step_name: e.target.value })}
                 placeholder="cleanse_orders" />
        </div>

        <div className="grid grid-cols-2 gap-3 mt-3">
          <div>
            <label className="label">Input alias</label>
            <input className="input font-mono"
                   value={form.input_alias}
                   onChange={(e) => setForm({ ...form, input_alias: e.target.value })}
                   placeholder="raw_orders" />
          </div>
          <div>
            <label className="label">Output alias</label>
            <input className="input font-mono"
                   value={form.output_alias}
                   onChange={(e) => setForm({ ...form, output_alias: e.target.value })}
                   placeholder="cleansed_orders" />
          </div>
        </div>

        <div className="mt-3">
          <label className="label">Config (JSON)</label>
          <textarea className="input font-mono text-xs" rows={6}
                    value={form.config_json}
                    onChange={(e) => setForm({ ...form, config_json: e.target.value })} />
          <p className="text-xs text-graphite-muted mt-1">
            Step-type-specific. E.g. <code>{`{"table_fqn":"fin_prod.bronze.orders"}`}</code> for read_delta.
          </p>
        </div>

        {m.isError && <div className="mt-3 text-sm text-danger">Failed: {(m.error as Error).message}</div>}

        <div className="mt-5 flex justify-end gap-2">
          <button className="btn-secondary" onClick={onClose}>Cancel</button>
          <button className="btn-primary"
                  disabled={!form.step_name || m.isPending}
                  onClick={() => m.mutate()}>
            Add step
          </button>
        </div>
      </div>
    </div>
  );
}

export default function TxStepsPage() {
  const { jobId } = useParams<{ jobId: string }>();
  const job_id = Number(jobId);
  const { selected } = useProject();
  const { can } = usePermissions();
  const code = selected?.project_code;
  const canWrite = !!code && can("tx_step.write", { project_code: code });
  const [adding, setAdding] = useState(false);

  const { data: job } = useQuery({
    enabled: !Number.isNaN(job_id),
    queryKey: ["txJob", job_id],
    queryFn: () => api.getTxJob(job_id),
  });

  const { data: steps = [], isLoading } = useQuery({
    enabled: !Number.isNaN(job_id),
    queryKey: ["txSteps", job_id],
    queryFn: () => api.listTxSteps(job_id),
  });

  const nextOrder = steps.length === 0 ? 1 : Math.max(...steps.map(s => s.step_order)) + 1;

  return (
    <>
      <PageHeader
        title={job ? `Steps · ${job.job_code}` : "Steps"}
        subtitle={
          job
            ? `${job.source_layer} → ${job.target_layer} · ${job.target_catalog}.${job.target_schema}.${job.target_table}`
            : undefined
        }
        actions={
          <div className="flex items-center gap-2">
            <Link to="/transform/jobs" className="btn-secondary">
              <ArrowLeft className="h-4 w-4" /> Back to jobs
            </Link>
            {canWrite && (
              <button className="btn-primary" onClick={() => setAdding(true)}>
                <Plus className="h-4 w-4" /> Add step
              </button>
            )}
          </div>
        }
      />

      <div className="px-8 py-6 max-w-[1400px]">
        <div className="card overflow-hidden">
          {isLoading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading…</div>
          ) : steps.length === 0 ? (
            <EmptyState icon={ListTree} title="No steps"
                        description="Add the first step in this transformation pipeline." />
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th className="w-16">#</th>
                  <th>Name</th>
                  <th>Type</th>
                  <th>Input</th>
                  <th>Output</th>
                  <th>On error</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {steps.map((s) => (
                  <tr key={s.step_id}>
                    <td className="font-mono text-[12px]">{s.step_order}</td>
                    <td className="font-mono text-[13px]">{s.step_name}</td>
                    <td><Pill tone="info">{s.step_type}</Pill></td>
                    <td className="font-mono text-[12px]">{s.input_alias ?? "—"}</td>
                    <td className="font-mono text-[12px]">{s.output_alias ?? "—"}</td>
                    <td>
                      <Pill tone={s.error_strategy === "fail" ? "danger" : "neutral"}>
                        {s.error_strategy}
                      </Pill>
                    </td>
                    <td>
                      <Pill tone={s.enabled ? "success" : "neutral"}>
                        {s.enabled ? "Enabled" : "Disabled"}
                      </Pill>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {adding && (
        <AddStepDialog
          job_id={job_id}
          nextOrder={nextOrder}
          onClose={() => setAdding(false)}
        />
      )}
    </>
  );
}
