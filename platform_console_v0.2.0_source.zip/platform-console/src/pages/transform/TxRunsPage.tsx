import { useQuery } from "@tanstack/react-query";
import { PlayCircle } from "lucide-react";

import { api } from "@/api/client";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Pill } from "@/components/Pill";
import { useProject } from "@/lib/projectContext";

export default function TxRunsPage() {
  const { selected } = useProject();
  const code = selected?.project_code;

  const { data: runs = [], isLoading } = useQuery({
    enabled: !!code,
    queryKey: ["txRuns", code, "all"],
    queryFn: () => api.listTxRuns(code!, { limit: 200 }),
  });

  if (!code) return null;

  return (
    <>
      <PageHeader
        title="Transform runs"
        subtitle={`tx_runs for ${code} · v0.2 lineage triple visible`}
      />

      <div className="px-8 py-6 max-w-[1400px]">
        <div className="card overflow-hidden">
          {isLoading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading…</div>
          ) : runs.length === 0 ? (
            <EmptyState icon={PlayCircle} title="No transform runs yet" />
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th>tx_run_id</th>
                  <th>Job</th>
                  <th>Started</th>
                  <th>Trigger / Upstream</th>
                  <th className="text-right">Rows w / r / rej</th>
                  <th>Status</th>
                  <th>DQ verdict</th>
                  <th>Block?</th>
                </tr>
              </thead>
              <tbody>
                {runs.map((r) => (
                  <tr key={r.tx_run_id}>
                    <td className="font-mono text-[12px]">{r.tx_run_id}</td>
                    <td className="font-mono text-[13px]">{r.job_code}</td>
                    <td className="font-mono text-[12px]">{r.started_at.replace("T", " ").slice(0, 19)}</td>
                    <td className="font-mono text-[12px]">
                      <div>{r.triggered_by}</div>
                      {r.upstream_run_id && (
                        <div className="text-xs text-graphite-muted">⮬ {r.upstream_run_id}</div>
                      )}
                    </td>
                    <td className="text-right tabular-nums text-xs">
                      <div>{r.rows_written?.toLocaleString() ?? "—"}</div>
                      <div className="text-graphite-muted">
                        in {r.rows_read?.toLocaleString() ?? "—"} · rej {r.rows_rejected?.toLocaleString() ?? "—"}
                      </div>
                    </td>
                    <td>
                      <Pill tone={
                        r.status === "success" ? "success" :
                        r.status === "running" ? "info" :
                        r.status === "failed"  ? "danger" : "warn"
                      }>{r.status}</Pill>
                    </td>
                    <td>
                      {r.dq_verdict
                        ? (
                          <div>
                            <Pill tone={
                              r.dq_verdict === "pass" ? "success" :
                              r.dq_verdict === "warn" ? "warn" :
                              r.dq_verdict === "block" ? "danger" : "neutral"
                            }>{r.dq_verdict}</Pill>
                            {r.dq_run_id && (
                              <div className="text-[11px] font-mono text-graphite-muted mt-0.5">
                                {r.dq_run_id}
                              </div>
                            )}
                          </div>
                        )
                        : <Pill tone="neutral">not run</Pill>}
                    </td>
                    <td>
                      {r.should_block_publish === true && <Pill tone="danger">BLOCK</Pill>}
                      {r.should_block_publish === false && <Pill tone="success">publish</Pill>}
                      {r.should_block_publish === null && "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}
