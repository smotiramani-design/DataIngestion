import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Settings as SettingsIcon, Plus, X, ListTree } from "lucide-react";
import { Link } from "react-router-dom";

import { api } from "@/api/client";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Pill } from "@/components/Pill";
import { useProject } from "@/lib/projectContext";
import { usePermissions } from "@/lib/auth/useAuth";
import type { TxLayer, TxWriteMode } from "@/types/transform";

const LAYERS: TxLayer[] = ["bronze", "silver", "gold"];
const WRITE_MODES: TxWriteMode[] = ["merge", "overwrite", "append"];

function CreateJobDialog({ project_code, onClose }: { project_code: string; onClose: () => void }) {
  const qc = useQueryClient();
  const { selected } = useProject();
  const [form, setForm] = useState({
    job_code: "",
    job_version: 1,
    source_layer: "bronze" as TxLayer,
    target_layer: "silver" as TxLayer,
    target_table: "",
    write_mode: "merge" as TxWriteMode,
    primary_key_csv: "",
    partition_csv: "",
    schedule_cron: "",
    block_on_dq_fail: true,
  });

  const m = useMutation({
    mutationFn: () =>
      api.createTxJob({
        project_code,
        job_code: form.job_code,
        job_version: form.job_version,
        source_layer: form.source_layer,
        target_layer: form.target_layer,
        target_catalog: selected?.default_catalog ?? "",
        target_schema: form.target_layer,
        target_table: form.target_table,
        write_mode: form.write_mode,
        primary_key_cols: form.primary_key_csv.split(",").map(s => s.trim()).filter(Boolean),
        partition_cols: form.partition_csv.split(",").map(s => s.trim()).filter(Boolean),
        schedule_cron: form.schedule_cron || null,
        block_on_dq_fail: form.block_on_dq_fail,
        git_sha: null,
        is_active: true,
      } as Parameters<typeof api.createTxJob>[0]),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["txJobs", project_code] });
      onClose();
    },
  });

  return (
    <div className="fixed inset-0 bg-navy/40 flex items-center justify-center z-40">
      <div className="card-pad w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold text-ink">New transformation job</h2>
          <button onClick={onClose}><X className="h-5 w-5 text-graphite-muted" /></button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Job code</label>
            <input className="input font-mono"
                   value={form.job_code}
                   onChange={(e) => setForm({ ...form, job_code: e.target.value })}
                   placeholder="silver_orders" />
          </div>
          <div>
            <label className="label">Version</label>
            <input className="input font-mono" type="number" min={1}
                   value={form.job_version}
                   onChange={(e) => setForm({ ...form, job_version: Number(e.target.value) })} />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 mt-3">
          <div>
            <label className="label">Source layer</label>
            <select className="input" value={form.source_layer}
                    onChange={(e) => setForm({ ...form, source_layer: e.target.value as TxLayer })}>
              {LAYERS.map(l => <option key={l} value={l}>{l}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Target layer</label>
            <select className="input" value={form.target_layer}
                    onChange={(e) => setForm({ ...form, target_layer: e.target.value as TxLayer })}>
              {LAYERS.map(l => <option key={l} value={l}>{l}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Write mode</label>
            <select className="input" value={form.write_mode}
                    onChange={(e) => setForm({ ...form, write_mode: e.target.value as TxWriteMode })}>
              {WRITE_MODES.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>
        </div>

        <div className="mt-3">
          <label className="label">Target table name</label>
          <input className="input font-mono"
                 value={form.target_table}
                 onChange={(e) => setForm({ ...form, target_table: e.target.value })}
                 placeholder="silver_orders" />
          <p className="text-xs text-graphite-muted mt-1">
            Will be written to <code>{selected?.default_catalog}.{form.target_layer}.{form.target_table || "…"}</code>
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3 mt-3">
          <div>
            <label className="label">Primary key cols (csv)</label>
            <input className="input font-mono"
                   value={form.primary_key_csv}
                   onChange={(e) => setForm({ ...form, primary_key_csv: e.target.value })}
                   placeholder="order_id" />
          </div>
          <div>
            <label className="label">Partition cols (csv)</label>
            <input className="input font-mono"
                   value={form.partition_csv}
                   onChange={(e) => setForm({ ...form, partition_csv: e.target.value })}
                   placeholder="order_date" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mt-3">
          <div>
            <label className="label">Schedule cron (optional)</label>
            <input className="input font-mono"
                   value={form.schedule_cron}
                   onChange={(e) => setForm({ ...form, schedule_cron: e.target.value })}
                   placeholder="0 */6 * * *" />
          </div>
          <div className="flex items-end">
            <label className="inline-flex items-center gap-2 text-sm">
              <input type="checkbox" checked={form.block_on_dq_fail}
                     onChange={(e) => setForm({ ...form, block_on_dq_fail: e.target.checked })} />
              Block publish if DQ fails
            </label>
          </div>
        </div>

        {m.isError && <div className="mt-3 text-sm text-danger">Failed: {(m.error as Error).message}</div>}

        <div className="mt-5 flex justify-end gap-2">
          <button className="btn-secondary" onClick={onClose}>Cancel</button>
          <button className="btn-primary"
                  disabled={!form.job_code || !form.target_table || m.isPending}
                  onClick={() => m.mutate()}>
            Create job
          </button>
        </div>
      </div>
    </div>
  );
}

export default function TxJobsPage() {
  const { selected } = useProject();
  const { can } = usePermissions();
  const qc = useQueryClient();
  const code = selected?.project_code;
  const canWrite = !!code && can("tx_job.write", { project_code: code });
  const [creating, setCreating] = useState(false);

  const { data: jobs = [], isLoading } = useQuery({
    enabled: !!code,
    queryKey: ["txJobs", code],
    queryFn: () => api.listTxJobs(code!),
  });

  const toggle = useMutation({
    mutationFn: ({ job_id, is_active }: { job_id: number; is_active: boolean }) =>
      api.setTxJobActive(job_id, is_active),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["txJobs", code] }),
  });

  if (!code) return null;

  return (
    <>
      <PageHeader
        title="Transformation jobs"
        subtitle={`tx_jobs for ${code}`}
        actions={
          canWrite && (
            <button className="btn-primary" onClick={() => setCreating(true)}>
              <Plus className="h-4 w-4" /> New job
            </button>
          )
        }
      />

      <div className="px-8 py-6 max-w-[1400px]">
        <div className="card overflow-hidden">
          {isLoading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading…</div>
          ) : jobs.length === 0 ? (
            <EmptyState icon={SettingsIcon} title="No jobs"
                        description="Define your first transformation job." />
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Job code</th>
                  <th>v.</th>
                  <th>Source → Target</th>
                  <th>Target FQN</th>
                  <th>Write mode</th>
                  <th>PK</th>
                  <th>Schedule</th>
                  <th>DQ block</th>
                  <th>Status</th>
                  <th className="w-32"></th>
                </tr>
              </thead>
              <tbody>
                {jobs.map((j) => (
                  <tr key={j.job_id}>
                    <td>
                      <Link to={`/transform/jobs/${j.job_id}/steps`}
                            className="font-mono text-[13px] text-teal-deep hover:underline">
                        {j.job_code}
                      </Link>
                    </td>
                    <td className="font-mono text-[12px]">{j.job_version}</td>
                    <td className="text-xs">
                      <Pill tone="neutral">{j.source_layer}</Pill>
                      <span className="mx-1">→</span>
                      <Pill tone="neutral">{j.target_layer}</Pill>
                    </td>
                    <td className="font-mono text-[12px]">
                      {j.target_catalog}.{j.target_schema}.{j.target_table}
                    </td>
                    <td><Pill tone="info">{j.write_mode}</Pill></td>
                    <td className="font-mono text-[12px]">{j.primary_key_cols.join(", ") || "—"}</td>
                    <td className="font-mono text-[12px]">{j.schedule_cron ?? "—"}</td>
                    <td>
                      {j.block_on_dq_fail
                        ? <Pill tone="danger">block</Pill>
                        : <Pill tone="neutral">warn-only</Pill>}
                    </td>
                    <td>
                      <Pill tone={j.is_active ? "success" : "neutral"}>
                        {j.is_active ? "Active" : "Disabled"}
                      </Pill>
                    </td>
                    <td className="text-right">
                      <Link to={`/transform/jobs/${j.job_id}/steps`}
                            className="btn-secondary text-xs">
                        <ListTree className="h-3.5 w-3.5" /> Steps
                      </Link>
                      {canWrite && (
                        <button className="btn-secondary text-xs ml-1"
                                onClick={() => toggle.mutate({ job_id: j.job_id, is_active: !j.is_active })}>
                          {j.is_active ? "Disable" : "Enable"}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {creating && <CreateJobDialog project_code={code} onClose={() => setCreating(false)} />}
    </>
  );
}
