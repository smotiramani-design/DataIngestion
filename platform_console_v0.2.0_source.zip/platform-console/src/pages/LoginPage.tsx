import { useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { ShieldCheck, LogIn } from "lucide-react";

import { useAuth } from "@/lib/auth/useAuth";

export default function LoginPage() {
  const { isAuthenticated, signIn } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();
  const useMock = import.meta.env.VITE_USE_MOCK === "true";

  useEffect(() => {
    if (isAuthenticated) {
      const from = (loc.state as { from?: { pathname: string } } | null)?.from?.pathname || "/dashboard";
      nav(from, { replace: true });
    }
  }, [isAuthenticated, nav, loc.state]);

  return (
    <div className="min-h-full flex items-center justify-center bg-navy">
      <div className="card-pad w-full max-w-md">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-md bg-navy flex items-center justify-center">
            <ShieldCheck className="h-5 w-5 text-teal-soft" />
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-[0.2em] text-graphite-muted font-semibold">
              DATA PLATFORM
            </div>
            <div className="text-lg font-semibold text-ink">Console</div>
          </div>
        </div>

        <p className="mt-6 text-sm text-graphite">
          Sign in with your corporate identity to manage feeds, validation rules,
          and transformation jobs across the platform.
        </p>

        <button
          onClick={() => signIn()}
          className="btn-primary mt-6 w-full justify-center"
        >
          <LogIn className="h-4 w-4" />
          Sign in with Microsoft Entra ID
        </button>

        {useMock && (
          <div className="mt-4 text-[11px] text-graphite-muted bg-surface-soft border border-surface-border rounded px-3 py-2">
            Mock mode is on. You're signed in automatically. Switch personas
            with <code className="font-mono">?as=platform_admin</code>,
            <code className="font-mono"> ?as=project_owner</code>, or
            <code className="font-mono"> ?as=business_user</code>.
          </div>
        )}
      </div>
    </div>
  );
}
