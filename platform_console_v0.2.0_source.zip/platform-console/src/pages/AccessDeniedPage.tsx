import { Link } from "react-router-dom";
import { ShieldAlert } from "lucide-react";

import { usePermissions } from "@/lib/auth/useAuth";
import { useProject } from "@/lib/projectContext";
import { ROLES } from "@/lib/auth/roles";

export default function AccessDeniedPage() {
  const { rolesFor, user } = usePermissions();
  const { selected } = useProject();
  const roles = rolesFor(selected?.project_code);

  return (
    <div className="min-h-full flex items-center justify-center">
      <div className="card-pad w-full max-w-lg text-center">
        <ShieldAlert className="h-10 w-10 text-warn mx-auto" />
        <h1 className="mt-3 text-lg font-semibold text-ink">Access denied</h1>
        <p className="mt-1 text-sm text-graphite-muted">
          You don't have permission for this page in
          {selected ? <span className="font-semibold"> {selected.project_code}</span> : " this project"}.
        </p>

        <div className="mt-6 rounded-md border border-surface-border bg-surface-soft p-4 text-left">
          <div className="text-[11px] uppercase tracking-wider font-semibold text-graphite-muted">
            Your roles
          </div>
          <div className="mt-1 text-sm text-ink">{user?.display_name}</div>
          <div className="mt-2 flex flex-wrap gap-1">
            {roles.length === 0 && (
              <span className="text-xs text-graphite-muted italic">
                No roles assigned for this project.
              </span>
            )}
            {roles.map((r) => (
              <span
                key={r}
                className={`pill ${ROLES[r]?.pill_class ?? "bg-surface-soft text-graphite"}`}
              >
                {ROLES[r]?.label ?? r}
              </span>
            ))}
          </div>
          <p className="mt-3 text-xs text-graphite-muted">
            Need access? Contact your project owner or the platform admin team.
          </p>
        </div>

        <Link to="/dashboard" className="btn-secondary mt-6 inline-flex">
          Back to dashboard
        </Link>
      </div>
    </div>
  );
}
