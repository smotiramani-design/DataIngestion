import { useQuery } from "@tanstack/react-query";
import { History } from "lucide-react";

import { api } from "@/api/client";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Pill } from "@/components/Pill";
import { useProject } from "@/lib/projectContext";

export default function AuditPage() {
  const { selected } = useProject();
  const code = selected?.project_code;

  const { data: entries = [], isLoading } = useQuery({
    enabled: !!code,
    queryKey: ["audit", code],
    queryFn: () => api.listAudit(code!, { limit: 500 }),
  });

  if (!code) return null;

  return (
    <>
      <PageHeader
        title="Audit log"
        subtitle={`Cross-framework events for ${code}`}
      />

      <div className="px-8 py-6 max-w-[1400px]">
        <div className="card overflow-hidden">
          {isLoading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading…</div>
          ) : entries.length === 0 ? (
            <EmptyState icon={History} title="No audit entries" />
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Time</th>
                  <th>Framework</th>
                  <th>v.</th>
                  <th>Event</th>
                  <th>Actor</th>
                  <th>Message</th>
                </tr>
              </thead>
              <tbody>
                {entries.map((e) => (
                  <tr key={e.audit_id}>
                    <td className="font-mono text-[12px]">{e.event_ts.replace("T", " ").slice(0, 19)}</td>
                    <td>
                      <Pill tone={
                        e.framework === "INGEST"    ? "info"    :
                        e.framework === "DQ"        ? "warn"    :
                        e.framework === "TRANSFORM" ? "success" : "neutral"
                      }>
                        {e.framework}
                      </Pill>
                    </td>
                    <td className="font-mono text-[12px]">{e.framework_version}</td>
                    <td className="font-mono text-[12px]">{e.event_type}</td>
                    <td className="text-[13px]">{e.actor}</td>
                    <td className="text-[13px]">{e.message}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}
