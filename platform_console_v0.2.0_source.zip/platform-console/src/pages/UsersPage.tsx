import { Users } from "lucide-react";

import { PageHeader } from "@/components/PageHeader";
import { ROLES } from "@/lib/auth/roles";
import { Pill } from "@/components/Pill";

export default function UsersPage() {
  return (
    <>
      <PageHeader
        title="Users & roles"
        subtitle="Role catalog — actual user-to-role assignments live in Entra ID"
      />

      <div className="px-8 py-6 max-w-[1400px] space-y-4">
        <div className="card-pad">
          <div className="flex items-start gap-3">
            <Users className="h-5 w-5 text-teal-deep mt-0.5 shrink-0" />
            <div>
              <h2 className="text-sm font-semibold text-ink">Where membership lives</h2>
              <p className="mt-1 text-sm text-graphite">
                Tenant-level role membership is managed in your Entra ID app
                registration ("App roles" + "Users and groups"). Per-project
                role assignments live in the platform's <code className="font-mono">project_user</code>
                {" "}table and are surfaced via the <code className="font-mono">extension_project_roles</code>
                {" "}custom claim. To grant somebody a role, edit those — not this page.
              </p>
            </div>
          </div>
        </div>

        <div className="card overflow-hidden">
          <div className="px-5 py-3 border-b border-surface-border">
            <h3 className="text-sm font-semibold">Role catalog</h3>
            <p className="text-xs text-graphite-muted mt-0.5">
              This catalog is the single source of truth for role → permission
              mapping in the UI. Add a role by editing
              {" "}<code className="font-mono">src/lib/auth/roles.ts</code>.
              Backend must mirror.
            </p>
          </div>
          <table className="data-table">
            <thead>
              <tr>
                <th>Role</th>
                <th>Description</th>
                <th>Permissions</th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(ROLES).map(([key, def]) => (
                <tr key={key}>
                  <td>
                    <span className={`pill ${def.pill_class}`}>{def.label}</span>
                    <div className="text-[11px] font-mono text-graphite-muted mt-1">{key}</div>
                  </td>
                  <td className="text-[13px]">{def.description}</td>
                  <td>
                    <div className="flex flex-wrap gap-1">
                      {def.permissions.map((p) => (
                        <span key={p} className="pill bg-surface-soft text-graphite border border-surface-border">
                          {p}
                        </span>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="card-pad">
          <h3 className="text-sm font-semibold mb-2">Adding a new role</h3>
          <ol className="text-sm text-graphite list-decimal pl-5 space-y-1">
            <li>Add the role in <code className="font-mono">ROLES</code> in
                {" "}<code className="font-mono">src/lib/auth/roles.ts</code>, granting
                the permissions it needs.</li>
            <li>Define a matching app role in your Entra ID app registration with
                the same string identifier.</li>
            <li>Mirror the same permissions on the backend authorization layer.</li>
            <li>Assign users / groups to the new role in Entra ID, or add per-project
                rows to <code className="font-mono">project_user</code> for project-scoped grants.</li>
          </ol>
        </div>

        <div className="text-xs text-graphite-muted">
          <Pill tone="warn">Heads up</Pill>
          <span className="ml-2">
            The UI is not a security boundary. The backend must independently
            enforce the same permissions matrix on every API call.
          </span>
        </div>
      </div>
    </>
  );
}
