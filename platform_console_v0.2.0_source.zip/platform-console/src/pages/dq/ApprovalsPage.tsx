import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ClipboardCheck, Check, X } from "lucide-react";

import { api } from "@/api/client";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Pill } from "@/components/Pill";
import { useProject } from "@/lib/projectContext";
import { usePermissions } from "@/lib/auth/useAuth";

export default function ApprovalsPage() {
  const { selected } = useProject();
  const { can } = usePermissions();
  const qc = useQueryClient();
  const code = selected?.project_code;
  const canApprove = !!code && can("dq_approve.write", { project_code: code });

  const { data: pending = [], isLoading } = useQuery({
    enabled: !!code,
    queryKey: ["pending", code],
    queryFn: () => api.listPendingApprovals(code!),
  });

  const approve = useMutation({
    mutationFn: async (rule_id: string) => {
      await api.setRuleStatus(rule_id, "APPROVED");
      return api.setRuleEnabled(rule_id, true);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pending", code] });
      qc.invalidateQueries({ queryKey: ["rules", code] });
    },
  });
  const reject = useMutation({
    mutationFn: (rule_id: string) => api.setRuleStatus(rule_id, "DEPRECATED"),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pending", code] });
      qc.invalidateQueries({ queryKey: ["rules", code] });
    },
  });

  if (!code) return null;

  return (
    <>
      <PageHeader
        title="Approvals"
        subtitle={`PROPOSED DQ rules awaiting review for ${code}`}
      />

      <div className="px-8 py-6 max-w-[1400px]">
        <div className="card overflow-hidden">
          {isLoading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading…</div>
          ) : pending.length === 0 ? (
            <EmptyState icon={ClipboardCheck} title="Nothing waiting"
                        description="No rules are currently in PROPOSED state." />
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Rule</th>
                  <th>Layer</th>
                  <th>Severity</th>
                  <th>Datasets</th>
                  <th>Owner</th>
                  <th className="w-44 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {pending.map((r) => (
                  <tr key={r.rule_id}>
                    <td>
                      <div className="font-mono text-[12px]">{r.rule_id}</div>
                      <div className="text-sm">{r.name}</div>
                    </td>
                    <td><Pill tone="neutral">{r.layer.replace("_", " ")}</Pill></td>
                    <td>
                      <Pill tone={r.severity === "BLOCK" ? "danger" : r.severity === "WARN" ? "warn" : "info"}>
                        {r.severity}
                      </Pill>
                    </td>
                    <td className="font-mono text-[12px] max-w-[260px] truncate">{r.datasets.join(", ")}</td>
                    <td className="text-[13px]">{r.owner}</td>
                    <td className="text-right">
                      {canApprove ? (
                        <div className="inline-flex gap-2">
                          <button
                            className="btn-primary text-xs"
                            disabled={approve.isPending}
                            onClick={() => approve.mutate(r.rule_id)}
                          >
                            <Check className="h-3.5 w-3.5" /> Approve
                          </button>
                          <button
                            className="btn-secondary text-xs"
                            disabled={reject.isPending}
                            onClick={() => reject.mutate(r.rule_id)}
                          >
                            <X className="h-3.5 w-3.5" /> Reject
                          </button>
                        </div>
                      ) : (
                        <span className="text-xs text-graphite-muted italic">read-only</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}
