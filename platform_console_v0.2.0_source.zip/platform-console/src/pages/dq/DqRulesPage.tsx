import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ShieldCheck, Plus, X } from "lucide-react";

import { api } from "@/api/client";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Pill } from "@/components/Pill";
import { useProject } from "@/lib/projectContext";
import { usePermissions } from "@/lib/auth/useAuth";
import type { DqCheckType, DqLayer, DqSeverity, DqStatus } from "@/types/dq";

const CHECK_TYPES: DqCheckType[] = [
  "SCHEMA", "ROW_COUNT_MIN", "ROW_COUNT_DRIFT", "NULL_PCT_MAX",
  "PRIMARY_KEY", "DOMAIN", "EXPRESSION", "REFERENTIAL_INTEGRITY", "AGGREGATE_PARITY",
];
const LAYERS: DqLayer[] = ["FILE", "BUSINESS_RULE", "POST_TRANSFORM"];
const SEVERITIES: DqSeverity[] = ["INFO", "WARN", "BLOCK"];

function severityTone(s: DqSeverity) {
  return s === "BLOCK" ? "danger" : s === "WARN" ? "warn" : "info";
}

function statusTone(s: DqStatus) {
  return s === "APPROVED" ? "success" : s === "PROPOSED" ? "warn" : s === "DEPRECATED" ? "neutral" : "info";
}

function CreateRuleDialog({
  project_code,
  canApprove,
  onClose,
}: {
  project_code: string;
  canApprove: boolean;
  onClose: () => void;
}) {
  const qc = useQueryClient();
  const [form, setForm] = useState({
    rule_id: "",
    name: "",
    description: "",
    layer: "BUSINESS_RULE" as DqLayer,
    check_type: "PRIMARY_KEY" as DqCheckType,
    severity: "BLOCK" as DqSeverity,
    datasets_csv: "",
    expression: "",
    params_json: "{}",
    owner: "",
  });

  const m = useMutation({
    mutationFn: () => {
      const datasets = form.datasets_csv.split(",").map((s) => s.trim()).filter(Boolean);
      let params: Record<string, string> = {};
      try { params = JSON.parse(form.params_json || "{}"); } catch { params = {}; }
      return api.createRule({
        rule_id: form.rule_id,
        project_code,
        name: form.name,
        description: form.description || null,
        layer: form.layer,
        check_type: form.check_type,
        severity: form.severity,
        datasets,
        expression: form.expression || null,
        params,
        owner: form.owner,
        // BU users can only PROPOSE; PO/PA can directly APPROVE
        status: canApprove ? "APPROVED" : "PROPOSED",
        enabled: canApprove,
      } as Parameters<typeof api.createRule>[0]);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["rules", project_code] });
      qc.invalidateQueries({ queryKey: ["pending", project_code] });
      onClose();
    },
  });

  return (
    <div className="fixed inset-0 bg-navy/40 flex items-center justify-center z-40">
      <div className="card-pad w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base font-semibold text-ink">New DQ rule</h2>
            <p className="text-xs text-graphite-muted">
              {canApprove
                ? "You can publish directly because you have rule.write."
                : "Will be saved as PROPOSED for a project owner to approve."}
            </p>
          </div>
          <button onClick={onClose}><X className="h-5 w-5 text-graphite-muted" /></button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Rule ID</label>
            <input className="input font-mono"
                   value={form.rule_id}
                   onChange={(e) => setForm({ ...form, rule_id: e.target.value })}
                   placeholder="B_FIN_0099" />
          </div>
          <div>
            <label className="label">Owner</label>
            <input className="input"
                   value={form.owner}
                   onChange={(e) => setForm({ ...form, owner: e.target.value })}
                   placeholder="team@corp" />
          </div>
        </div>

        <div className="mt-3">
          <label className="label">Name</label>
          <input className="input"
                 value={form.name}
                 onChange={(e) => setForm({ ...form, name: e.target.value })}
                 placeholder="silver.orders order_id is unique" />
        </div>

        <div className="mt-3">
          <label className="label">Description</label>
          <textarea className="input" rows={2}
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })} />
        </div>

        <div className="grid grid-cols-3 gap-3 mt-3">
          <div>
            <label className="label">Layer</label>
            <select className="input" value={form.layer}
                    onChange={(e) => setForm({ ...form, layer: e.target.value as DqLayer })}>
              {LAYERS.map((l) => <option key={l} value={l}>{l}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Check type</label>
            <select className="input" value={form.check_type}
                    onChange={(e) => setForm({ ...form, check_type: e.target.value as DqCheckType })}>
              {CHECK_TYPES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Severity</label>
            <select className="input" value={form.severity}
                    onChange={(e) => setForm({ ...form, severity: e.target.value as DqSeverity })}>
              {SEVERITIES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>

        <div className="mt-3">
          <label className="label">Datasets (comma-separated FQNs)</label>
          <input className="input font-mono"
                 value={form.datasets_csv}
                 onChange={(e) => setForm({ ...form, datasets_csv: e.target.value })}
                 placeholder="fin_prod.silver.silver_orders" />
        </div>

        {form.check_type === "EXPRESSION" && (
          <div className="mt-3">
            <label className="label">Expression (must evaluate to true)</label>
            <input className="input font-mono"
                   value={form.expression}
                   onChange={(e) => setForm({ ...form, expression: e.target.value })}
                   placeholder="amount &gt; 0 OR status = 'CANCELLED'" />
          </div>
        )}

        <div className="mt-3">
          <label className="label">Params (JSON)</label>
          <textarea className="input font-mono text-xs" rows={4}
                    value={form.params_json}
                    onChange={(e) => setForm({ ...form, params_json: e.target.value })} />
          <p className="text-xs text-graphite-muted mt-1">
            E.g. <code>{`{"columns":"order_id"}`}</code> for PRIMARY_KEY,
            {" "}<code>{`{"max_null_pct":"0.1","column":"order_id"}`}</code> for NULL_PCT_MAX.
          </p>
        </div>

        {m.isError && <div className="mt-3 text-sm text-danger">Failed: {(m.error as Error).message}</div>}

        <div className="mt-5 flex justify-end gap-2">
          <button className="btn-secondary" onClick={onClose}>Cancel</button>
          <button
            className="btn-primary"
            disabled={!form.rule_id || !form.name || !form.datasets_csv || m.isPending}
            onClick={() => m.mutate()}
          >
            {canApprove ? "Create & enable" : "Submit for approval"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function DqRulesPage() {
  const { selected } = useProject();
  const { can } = usePermissions();
  const qc = useQueryClient();
  const code = selected?.project_code;
  const [creating, setCreating] = useState(false);

  const canPropose = !!code && can("rule.propose", { project_code: code });
  const canWrite = !!code && can("rule.write", { project_code: code });
  const canApprove = !!code && can("dq_approve.write", { project_code: code });

  const { data: rules = [], isLoading } = useQuery({
    enabled: !!code,
    queryKey: ["rules", code],
    queryFn: () => api.listRules(code!),
  });

  const toggleEnabled = useMutation({
    mutationFn: ({ rule_id, enabled }: { rule_id: string; enabled: boolean }) =>
      api.setRuleEnabled(rule_id, enabled),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["rules", code] }),
  });

  if (!code) return null;

  return (
    <>
      <PageHeader
        title="DQ rules"
        subtitle={`Validation rules for ${code}`}
        actions={
          (canPropose || canWrite) && (
            <button className="btn-primary" onClick={() => setCreating(true)}>
              <Plus className="h-4 w-4" /> {canApprove ? "New rule" : "Propose rule"}
            </button>
          )
        }
      />

      <div className="px-8 py-6 max-w-[1400px]">
        <div className="card overflow-hidden">
          {isLoading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading…</div>
          ) : rules.length === 0 ? (
            <EmptyState icon={ShieldCheck} title="No rules"
                        description="No rules defined yet for this project." />
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Rule ID</th>
                  <th>Name</th>
                  <th>Layer</th>
                  <th>Check</th>
                  <th>Severity</th>
                  <th>Datasets</th>
                  <th>Status</th>
                  <th className="w-32"></th>
                </tr>
              </thead>
              <tbody>
                {rules.map((r) => (
                  <tr key={r.rule_id}>
                    <td className="font-mono text-[12px]">{r.rule_id}</td>
                    <td>
                      <div className="text-sm">{r.name}</div>
                      <div className="text-xs text-graphite-muted line-clamp-1">{r.description}</div>
                    </td>
                    <td><Pill tone="neutral">{r.layer.replace("_", " ")}</Pill></td>
                    <td><Pill tone="info">{r.check_type}</Pill></td>
                    <td><Pill tone={severityTone(r.severity)}>{r.severity}</Pill></td>
                    <td className="font-mono text-[12px] max-w-[260px] truncate">
                      {r.datasets.join(", ")}
                    </td>
                    <td>
                      <div className="flex flex-col gap-1">
                        <Pill tone={statusTone(r.status)}>{r.status}</Pill>
                        {!r.enabled && <Pill tone="neutral">disabled</Pill>}
                      </div>
                    </td>
                    <td className="text-right">
                      {canWrite && r.status === "APPROVED" && (
                        <button
                          className="btn-secondary text-xs"
                          onClick={() => toggleEnabled.mutate({ rule_id: r.rule_id, enabled: !r.enabled })}
                        >
                          {r.enabled ? "Disable" : "Enable"}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {creating && (
        <CreateRuleDialog
          project_code={code}
          canApprove={canWrite}
          onClose={() => setCreating(false)}
        />
      )}
    </>
  );
}
