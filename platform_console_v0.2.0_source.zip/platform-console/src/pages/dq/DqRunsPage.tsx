import { useQuery } from "@tanstack/react-query";
import { PlayCircle } from "lucide-react";

import { api } from "@/api/client";
import { PageHeader } from "@/components/PageHeader";
import { EmptyState } from "@/components/EmptyState";
import { Pill } from "@/components/Pill";
import { useProject } from "@/lib/projectContext";

export default function DqRunsPage() {
  const { selected } = useProject();
  const code = selected?.project_code;

  const { data: runs = [], isLoading } = useQuery({
    enabled: !!code,
    queryKey: ["dqRuns", code, "all"],
    queryFn: () => api.listDqRuns(code!, { limit: 200 }),
  });

  if (!code) return null;

  return (
    <>
      <PageHeader
        title="DQ validations"
        subtitle={`Validation runs for ${code} · v0.2 lineage triple visible`}
      />

      <div className="px-8 py-6 max-w-[1400px]">
        <div className="card overflow-hidden">
          {isLoading ? (
            <div className="p-8 text-sm text-graphite-muted">Loading…</div>
          ) : runs.length === 0 ? (
            <EmptyState icon={PlayCircle} title="No validation runs yet" />
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Run ID</th>
                  <th>Started</th>
                  <th>Triggered by</th>
                  <th>Upstream link</th>
                  <th className="text-right">Rules</th>
                  <th className="text-right">Records</th>
                  <th>Status</th>
                  <th>Block?</th>
                </tr>
              </thead>
              <tbody>
                {runs.map((r) => (
                  <tr key={r.run_id}>
                    <td className="font-mono text-[12px]">{r.run_id.slice(0, 12)}…</td>
                    <td className="font-mono text-[12px]">{r.start_ts.replace("T", " ").slice(0, 19)}</td>
                    <td>
                      <Pill tone="info">{r.triggering_framework ?? "LEGACY"}</Pill>
                    </td>
                    <td className="font-mono text-[12px]">
                      {r.ingest_run_id
                        ? <span title="ingest_run_id">⮬ {r.ingest_run_id}</span>
                        : r.tx_run_id
                          ? <span title="tx_run_id">⮬ {r.tx_run_id}</span>
                          : "—"}
                    </td>
                    <td className="text-right tabular-nums text-xs">
                      <div>{r.rules_evaluated ?? 0} eval</div>
                      <div className="text-graphite-muted">
                        {r.rules_passed ?? 0} pass · {r.rules_warned ?? 0} warn · {r.rules_failed ?? 0} fail
                      </div>
                    </td>
                    <td className="text-right tabular-nums">{r.records_checked?.toLocaleString() ?? "—"}</td>
                    <td>
                      <Pill tone={
                        r.status === "PASS" ? "success" :
                        r.status === "WARN" ? "warn" :
                        r.status === "RUNNING" ? "info" : "danger"
                      }>{r.status}</Pill>
                    </td>
                    <td>
                      {r.should_block_publish === true && <Pill tone="danger">BLOCK</Pill>}
                      {r.should_block_publish === false && <Pill tone="success">publish</Pill>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}
