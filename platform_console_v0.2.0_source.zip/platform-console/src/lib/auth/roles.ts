/**
 * Role and permission configuration.
 *
 * Roles are NOT hardcoded in components. Components ask `usePermissions()`
 * for action-level booleans (e.g. `can('rule.write')`). This file is the
 * single source of truth for the role -> permission mapping. To add a new
 * role, add it here; to grant or revoke a permission, edit the matrix.
 *
 * Backend should mirror this matrix when authorizing API calls — the UI
 * is not a security boundary, only a UX one.
 */

/**
 * Action surface across the three frameworks.
 *
 * Naming: <resource>.<action>
 * resources are scoped by namespace prefix (none = cross-cutting):
 *   project.*       — projects table & per-project access
 *   user.*          — user/role administration
 *   feed.*          — Ingestion FW: feed_config
 *   ingest_run.*    — Ingestion FW: audit_log read
 *   ingest_error.*  — Ingestion FW: error_log read
 *   rule.*          — DQ FW: dq_rules
 *   dq_run.*        — DQ FW: dq_validation_runs
 *   dq_approve.*    — DQ FW: approval workflow
 *   tx_job.*        — Transformation FW: tx_jobs
 *   tx_step.*       — Transformation FW: tx_steps
 *   tx_run.*        — Transformation FW: tx_runs
 *   audit.*         — cross-framework audit log
 */
export type Permission =
  // Project & user admin
  | "project.read"
  | "project.write"
  | "user.read"
  | "user.write"
  // Ingestion FW
  | "feed.read"
  | "feed.write"
  | "ingest_run.read"
  | "ingest_error.read"
  // DQ FW
  | "rule.read"
  | "rule.write"
  | "rule.propose"
  | "dq_run.read"
  | "dq_approve.write"
  // Transformation FW
  | "tx_job.read"
  | "tx_job.write"
  | "tx_step.read"
  | "tx_step.write"
  | "tx_run.read"
  // Cross-cutting
  | "audit.read"
  | "settings.write";

/** Role name -> set of permissions. */
export interface RoleDefinition {
  /** Display label for the UI badge. */
  label: string;
  /** Tooltip / one-line description shown in role-management screens. */
  description: string;
  /** Color class applied to the role pill. */
  pill_class: string;
  /** Granted permissions. */
  permissions: ReadonlyArray<Permission>;
}

/**
 * Built-in roles. Add new roles by inserting a key + definition here. The
 * runtime accepts any string in token claims, so unknown roles will just
 * grant no permissions until you map them.
 */
export const ROLES: Record<string, RoleDefinition> = {
  platform_admin: {
    label: "Platform Admin",
    description: "Full read/write across every framework, every project. Can assign roles.",
    pill_class: "bg-navy text-white",
    permissions: [
      "project.read", "project.write",
      "user.read", "user.write",
      "feed.read", "feed.write",
      "ingest_run.read", "ingest_error.read",
      "rule.read", "rule.write", "rule.propose",
      "dq_run.read", "dq_approve.write",
      "tx_job.read", "tx_job.write",
      "tx_step.read", "tx_step.write",
      "tx_run.read",
      "audit.read", "settings.write",
    ],
  },
  project_owner: {
    label: "Project Owner",
    description: "Read/write across all three frameworks within their assigned projects. Approves DQ rules.",
    pill_class: "bg-teal text-white",
    permissions: [
      "project.read",
      "user.read",
      "feed.read", "feed.write",
      "ingest_run.read", "ingest_error.read",
      "rule.read", "rule.write", "rule.propose",
      "dq_run.read", "dq_approve.write",
      "tx_job.read", "tx_job.write",
      "tx_step.read", "tx_step.write",
      "tx_run.read",
      "audit.read",
    ],
  },
  business_user: {
    label: "Business User",
    description: "Reads everywhere, proposes new DQ rules and edits feeds within their assigned projects. Cannot approve.",
    pill_class: "bg-amber text-ink",
    permissions: [
      "project.read",
      "feed.read", "feed.write",
      "ingest_run.read", "ingest_error.read",
      "rule.read", "rule.propose",
      "dq_run.read",
      "tx_job.read",
      "tx_step.read",
      "tx_run.read",
      "audit.read",
    ],
  },
};

export type RoleName = keyof typeof ROLES | string;

/**
 * Resolve the union of permissions for a list of roles, ignoring unknown
 * roles. Roles outside ROLES grant no permissions.
 */
export function permissionsFor(roles: ReadonlyArray<RoleName>): Set<Permission> {
  const out = new Set<Permission>();
  for (const r of roles) {
    const def = ROLES[r];
    if (!def) continue;
    for (const p of def.permissions) out.add(p);
  }
  return out;
}
