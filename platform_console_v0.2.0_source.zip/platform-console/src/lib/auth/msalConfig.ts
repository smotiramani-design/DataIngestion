import { PublicClientApplication, type Configuration, LogLevel } from "@azure/msal-browser";

/**
 * MSAL configuration for Entra ID (Azure AD) sign-in.
 *
 * Single-page app type. The redirect URI must be registered in your app
 * registration. The API scope must match the resource you call from this
 * SPA (the platform backend, exposed as an Entra App with the
 * `access_as_user` scope).
 *
 * In mock mode (VITE_USE_MOCK=true) MSAL is never initialized — see
 * `useAuth()` for the mock path.
 */
const env = import.meta.env;

export const msalConfig: Configuration = {
  auth: {
    clientId: env.VITE_AUTH_CLIENT_ID || "00000000-0000-0000-0000-000000000000",
    authority: `https://login.microsoftonline.com/${env.VITE_AUTH_TENANT_ID || "common"}`,
    redirectUri: env.VITE_AUTH_REDIRECT_URI || window.location.origin,
    postLogoutRedirectUri: env.VITE_AUTH_REDIRECT_URI || window.location.origin,
    navigateToLoginRequestUrl: true,
  },
  cache: {
    cacheLocation: "sessionStorage",   // safer than localStorage for tokens
    storeAuthStateInCookie: false,
  },
  system: {
    loggerOptions: {
      logLevel: LogLevel.Warning,
      piiLoggingEnabled: false,
      loggerCallback: (level, message) => {
        if (level === LogLevel.Error) console.error(`[msal] ${message}`);
        else if (level === LogLevel.Warning) console.warn(`[msal] ${message}`);
      },
    },
  },
};

export const apiScope = env.VITE_AUTH_API_SCOPE || "openid profile";

/** Login request — the scopes we ask the user to consent to. */
export const loginRequest = {
  scopes: ["openid", "profile", "email", apiScope],
};

/** Token request — the scope to silently acquire for API calls. */
export const tokenRequest = {
  scopes: [apiScope],
};

/** Singleton instance. Imported by main.tsx and wrapped in MsalProvider. */
export const msalInstance = new PublicClientApplication(msalConfig);
