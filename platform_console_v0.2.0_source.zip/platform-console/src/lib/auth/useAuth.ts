import { useMsal } from "@azure/msal-react";
import { useCallback, useMemo } from "react";

import type { AppUser } from "@/types/common";
import { permissionsFor, ROLES, type Permission, type RoleName } from "./roles";
import { loginRequest } from "./msalConfig";

const USE_MOCK = import.meta.env.VITE_USE_MOCK === "true";

/**
 * Mock user for local dev when VITE_USE_MOCK=true. Cycles through roles
 * via the ?as=role-name query parameter so engineers can flip personas
 * without re-authing:
 *   /?as=platform_admin
 *   /?as=project_owner
 *   /?as=business_user
 *
 * Per-project role assignments are also part of the mock so we can
 * exercise the project-scoped pieces of the permission model.
 */
function getMockUser(): AppUser {
  const url = new URL(window.location.href);
  const asRole = url.searchParams.get("as") || "platform_admin";
  const role = ROLES[asRole] ? asRole : "platform_admin";

  // Project assignments simulate what would come from a project_user table.
  const project_roles: Record<string, string[]> =
    role === "platform_admin"
      ? { FIN: ["platform_admin"], MKT: ["platform_admin"], OPS: ["platform_admin"] }
      : role === "project_owner"
        ? { FIN: ["project_owner"], MKT: ["business_user"] }
        : { FIN: ["business_user"], MKT: ["business_user"] };

  return {
    email:        `${role}@example.com`,
    display_name: ROLES[role]?.label ?? role,
    oid:          `mock-${role}`,
    roles:        [role],
    project_roles,
  };
}

/**
 * Resolve the active AppUser from MSAL state (or the mock).
 *
 * In real mode we read the ID-token claims:
 *   - `roles` → tenant-level roles
 *   - `extension_project_roles` → optional custom claim for per-project mapping
 *
 * Backends that own the project_user table should issue an enriched JWT.
 */
function useAppUser(): AppUser | null {
  const { accounts } = useMsal();

  return useMemo<AppUser | null>(() => {
    if (USE_MOCK) return getMockUser();
    const acct = accounts[0];
    if (!acct) return null;

    const claims = (acct.idTokenClaims ?? {}) as Record<string, unknown>;
    const tenantRoles = Array.isArray(claims.roles) ? (claims.roles as string[]) : [];

    // Custom claim shape: extension_project_roles = '{"FIN":["project_owner"]}'
    let project_roles: Record<string, string[]> = {};
    const raw = claims.extension_project_roles;
    if (typeof raw === "string") {
      try { project_roles = JSON.parse(raw); } catch { /* ignore */ }
    } else if (raw && typeof raw === "object") {
      project_roles = raw as Record<string, string[]>;
    }

    return {
      email:        (claims.preferred_username as string) || acct.username,
      display_name: acct.name || (claims.name as string) || acct.username,
      oid:          (claims.oid as string) || acct.localAccountId,
      roles:        tenantRoles,
      project_roles,
    };
  }, [accounts]);
}

/** Sign in / sign out actions. */
export function useAuth() {
  const { instance } = useMsal();
  const user = useAppUser();
  const isAuthenticated = USE_MOCK ? true : Boolean(user);

  const signIn = useCallback(async () => {
    if (USE_MOCK) return;
    await instance.loginRedirect(loginRequest);
  }, [instance]);

  const signOut = useCallback(async () => {
    if (USE_MOCK) {
      const url = new URL(window.location.href);
      url.searchParams.set("as", "");
      window.location.href = url.toString();
      return;
    }
    await instance.logoutRedirect();
  }, [instance]);

  return { user, isAuthenticated, signIn, signOut };
}

/**
 * Permission API.
 *
 * Components ask `can('rule.write', { project_code })` rather than
 * inspecting role names. This keeps role-to-permission mapping in one
 * place (`roles.ts`).
 *
 * `project_code` is optional — when provided, the user's project-scoped
 * roles are unioned with their tenant-level roles. Most permissions
 * resolve via project-scoped roles; tenant-level grants apply
 * cross-project (e.g. platform_admin).
 */
export interface PermissionContext {
  project_code?: string;
}

export function usePermissions() {
  const user = useAppUser();

  const can = useCallback(
    (perm: Permission, ctx: PermissionContext = {}): boolean => {
      if (!user) return false;
      const roles: RoleName[] = [...user.roles];
      if (ctx.project_code && user.project_roles[ctx.project_code]) {
        roles.push(...user.project_roles[ctx.project_code]);
      }
      const granted = permissionsFor(roles);
      return granted.has(perm);
    },
    [user],
  );

  /** Returns the union of role names active for a given project context. */
  const rolesFor = useCallback(
    (project_code?: string): string[] => {
      if (!user) return [];
      const roles = [...user.roles];
      if (project_code && user.project_roles[project_code]) {
        roles.push(...user.project_roles[project_code]);
      }
      return Array.from(new Set(roles));
    },
    [user],
  );

  return { can, rolesFor, user };
}
