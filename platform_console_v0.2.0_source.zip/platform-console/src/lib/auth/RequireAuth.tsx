import { Navigate, useLocation } from "react-router-dom";
import type { ReactNode } from "react";

import { useAuth, usePermissions } from "./useAuth";
import type { Permission } from "./roles";

/** Block rendering until the user has signed in. */
export function RequireAuth({ children }: { children: ReactNode }) {
  const { isAuthenticated } = useAuth();
  const location = useLocation();
  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }
  return <>{children}</>;
}

/**
 * Block rendering unless the user has at least one of the given permissions
 * in the supplied context (typically the currently-selected project).
 *
 * For action-level checks use the `usePermissions().can(...)` hook directly
 * to hide/disable buttons.
 */
export function RequirePerm({
  perm,
  project_code,
  children,
}: {
  perm: Permission | Permission[];
  project_code?: string;
  children: ReactNode;
}) {
  const { can, user } = usePermissions();
  if (!user) return <Navigate to="/login" replace />;
  const perms = Array.isArray(perm) ? perm : [perm];
  const ok = perms.some((p) => can(p, { project_code }));
  if (!ok) return <Navigate to="/access-denied" replace />;
  return <>{children}</>;
}
