import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";

import { api } from "@/api/client";
import type { Project } from "@/types/common";

interface ProjectContextValue {
  projects: Project[];
  selected: Project | null;
  setSelected: (project_code: string) => void;
  loading: boolean;
}

const ProjectContext = createContext<ProjectContextValue | undefined>(undefined);

const STORAGE_KEY = "platform-console.selected-project";

export function ProjectProvider({ children }: { children: ReactNode }) {
  const { data: projects = [], isLoading } = useQuery({
    queryKey: ["projects"],
    queryFn: () => api.listProjects(),
    staleTime: 60_000,
  });

  const [selectedCode, setSelectedCode] = useState<string | null>(() => {
    return typeof window !== "undefined"
      ? window.localStorage.getItem(STORAGE_KEY)
      : null;
  });

  // Pick first project on initial load if nothing stored / stored value gone.
  useEffect(() => {
    if (projects.length === 0) return;
    const stillExists = selectedCode && projects.some((p) => p.project_code === selectedCode);
    if (!stillExists) {
      setSelectedCode(projects[0].project_code);
    }
  }, [projects, selectedCode]);

  const setSelected = (project_code: string) => {
    setSelectedCode(project_code);
    if (typeof window !== "undefined") {
      window.localStorage.setItem(STORAGE_KEY, project_code);
    }
  };

  const selected = useMemo(
    () => projects.find((p) => p.project_code === selectedCode) ?? null,
    [projects, selectedCode],
  );

  return (
    <ProjectContext.Provider
      value={{ projects, selected, setSelected, loading: isLoading }}
    >
      {children}
    </ProjectContext.Provider>
  );
}

export function useProject() {
  const ctx = useContext(ProjectContext);
  if (!ctx) throw new Error("useProject must be used inside <ProjectProvider>");
  return ctx;
}
