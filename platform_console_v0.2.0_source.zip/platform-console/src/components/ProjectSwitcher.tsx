import { useState, useRef, useEffect } from "react";
import { Building2, Check, ChevronDown } from "lucide-react";
import clsx from "clsx";

import { useProject } from "@/lib/projectContext";
import { usePermissions } from "@/lib/auth/useAuth";
import { ROLES } from "@/lib/auth/roles";

export function ProjectSwitcher() {
  const { projects, selected, setSelected, loading } = useProject();
  const { rolesFor } = usePermissions();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  // Close on outside click
  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const activeRoles = selected ? rolesFor(selected.project_code) : [];

  return (
    <div ref={ref} className="relative px-3 py-3 border-b border-white/10">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        disabled={loading || projects.length === 0}
        className="w-full flex items-center justify-between gap-2 px-2 py-2 rounded-md
                   text-left bg-white/5 hover:bg-white/10 transition-colors
                   disabled:opacity-50"
      >
        <div className="flex items-center gap-2 min-w-0">
          <Building2 className="h-4 w-4 text-teal-soft shrink-0" />
          <div className="min-w-0">
            <div className="text-[11px] uppercase tracking-wider text-slate-400">Project</div>
            <div className="text-sm text-white truncate">
              {selected?.project_code ?? "—"}
            </div>
          </div>
        </div>
        <ChevronDown className={clsx("h-4 w-4 text-slate-400 transition-transform",
                                     open && "rotate-180")} />
      </button>

      {/* Roles for this project */}
      {selected && activeRoles.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1">
          {activeRoles.map((r) => {
            const def = ROLES[r];
            return (
              <span
                key={r}
                className={clsx(
                  "inline-flex items-center text-[10px] font-semibold px-1.5 py-0.5 rounded",
                  def?.pill_class ?? "bg-white/10 text-slate-300",
                )}
              >
                {def?.label ?? r}
              </span>
            );
          })}
        </div>
      )}

      {open && (
        <div className="absolute left-3 right-3 top-full mt-1 z-30
                        bg-white text-ink rounded-md shadow-card border border-surface-border
                        max-h-72 overflow-auto">
          {projects.map((p) => {
            const isActive = p.project_code === selected?.project_code;
            return (
              <button
                key={p.project_code}
                onClick={() => { setSelected(p.project_code); setOpen(false); }}
                className={clsx(
                  "w-full flex items-center justify-between gap-2 px-3 py-2 text-sm",
                  "hover:bg-surface-soft text-left",
                  isActive && "bg-surface-soft",
                )}
              >
                <div>
                  <div className="font-medium">{p.project_code}</div>
                  <div className="text-xs text-graphite-muted">{p.project_name}</div>
                </div>
                {isActive && <Check className="h-4 w-4 text-teal" />}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
