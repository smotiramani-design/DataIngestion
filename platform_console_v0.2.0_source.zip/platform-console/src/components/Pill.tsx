import clsx from "clsx";
import type { ReactNode } from "react";

type Tone = "neutral" | "success" | "warn" | "danger" | "info" | "ink";

const tonePalette: Record<Tone, string> = {
  neutral: "bg-surface-soft text-graphite border border-surface-border",
  success: "bg-success-soft text-success",
  warn:    "bg-warn-soft    text-warn",
  danger:  "bg-danger-soft  text-danger",
  info:    "bg-teal/10      text-teal-deep",
  ink:     "bg-navy         text-white",
};

export function Pill({
  tone = "neutral",
  children,
  className,
}: {
  tone?: Tone;
  children: ReactNode;
  className?: string;
}) {
  return (
    <span className={clsx("pill", tonePalette[tone], className)}>{children}</span>
  );
}
