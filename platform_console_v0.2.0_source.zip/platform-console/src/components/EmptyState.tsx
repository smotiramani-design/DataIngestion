import type { LucideIcon } from "lucide-react";

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
}: {
  icon: LucideIcon;
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="text-center py-12 px-6">
      <Icon className="mx-auto h-9 w-9 text-graphite-muted/60" />
      <h3 className="mt-3 text-sm font-semibold text-ink">{title}</h3>
      {description && (
        <p className="mt-1 text-sm text-graphite-muted max-w-md mx-auto">{description}</p>
      )}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}
