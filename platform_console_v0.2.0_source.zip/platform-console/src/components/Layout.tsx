import { Outlet, NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  Settings as SettingsIcon,
  Database,
  AlertTriangle,
  ShieldCheck,
  ClipboardCheck,
  Cog,
  GitBranch,
  History,
  PlayCircle,
  Users,
  LogOut,
} from "lucide-react";
import clsx from "clsx";
import type { LucideIcon } from "lucide-react";

import { ProjectSwitcher } from "@/components/ProjectSwitcher";
import { useAuth, usePermissions } from "@/lib/auth/useAuth";
import { useProject } from "@/lib/projectContext";
import type { Permission } from "@/lib/auth/roles";

interface NavItem {
  to: string;
  label: string;
  icon: LucideIcon;
  perm: Permission;
}

interface NavSection {
  label: string;
  items: NavItem[];
}

const NAV: NavSection[] = [
  {
    label: "Overview",
    items: [
      { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard, perm: "project.read" },
      { to: "/projects",  label: "Projects",  icon: Database,        perm: "project.read" },
    ],
  },
  {
    label: "Ingestion",
    items: [
      { to: "/ingest/feeds",  label: "Feeds",       icon: Cog,            perm: "feed.read" },
      { to: "/ingest/runs",   label: "Runs",        icon: PlayCircle,     perm: "ingest_run.read" },
      { to: "/ingest/errors", label: "Errors",      icon: AlertTriangle,  perm: "ingest_error.read" },
    ],
  },
  {
    label: "Data Quality",
    items: [
      { to: "/dq/rules",      label: "Rules",       icon: ShieldCheck,    perm: "rule.read" },
      { to: "/dq/runs",       label: "Validations", icon: PlayCircle,     perm: "dq_run.read" },
      { to: "/dq/approvals",  label: "Approvals",   icon: ClipboardCheck, perm: "dq_approve.write" },
    ],
  },
  {
    label: "Transformation",
    items: [
      { to: "/transform/jobs",    label: "Jobs",     icon: SettingsIcon, perm: "tx_job.read" },
      { to: "/transform/runs",    label: "Runs",     icon: PlayCircle,   perm: "tx_run.read" },
      { to: "/transform/lineage", label: "Lineage",  icon: GitBranch,    perm: "tx_run.read" },
    ],
  },
  {
    label: "Platform",
    items: [
      { to: "/audit",    label: "Audit Log",  icon: History,       perm: "audit.read" },
      { to: "/users",    label: "Users",      icon: Users,         perm: "user.read" },
      { to: "/settings", label: "Settings",   icon: SettingsIcon,  perm: "settings.write" },
    ],
  },
];

export default function Layout() {
  const { user, signOut } = useAuth();
  const { can } = usePermissions();
  const { selected } = useProject();
  const useMock = import.meta.env.VITE_USE_MOCK === "true";

  return (
    <div className="flex h-full">
      {/* ===== Sidebar ===== */}
      <aside className="w-60 bg-navy text-white flex flex-col shrink-0">
        <div className="px-5 py-5 border-b border-white/10">
          <div className="text-xs tracking-[0.2em] text-teal-soft font-semibold">
            DATA PLATFORM
          </div>
          <div className="text-xs text-slate-400 mt-1">Console v0.2.0</div>
        </div>

        <ProjectSwitcher />

        <nav className="flex-1 overflow-y-auto py-2">
          {NAV.map((section) => {
            const visible = section.items.filter((it) =>
              can(it.perm, { project_code: selected?.project_code }));
            if (visible.length === 0) return null;
            return (
              <div key={section.label} className="mb-1">
                <div className="px-5 py-1.5 text-[10px] uppercase tracking-[0.18em]
                                text-slate-500 font-semibold">
                  {section.label}
                </div>
                {visible.map(({ to, label, icon: Icon }) => (
                  <NavLink
                    key={to}
                    to={to}
                    end
                    className={({ isActive }) =>
                      clsx(
                        "flex items-center gap-3 px-5 py-2 text-sm transition-colors",
                        isActive
                          ? "bg-white/10 text-white border-l-2 border-teal"
                          : "text-slate-300 hover:text-white hover:bg-white/5 border-l-2 border-transparent",
                      )
                    }
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span>{label}</span>
                  </NavLink>
                ))}
              </div>
            );
          })}
        </nav>

        {/* User footer */}
        <div className="border-t border-white/10 px-5 py-3 text-xs">
          <div className="text-slate-400 truncate">{user?.email ?? "—"}</div>
          <div className="text-white truncate">{user?.display_name ?? "—"}</div>
          <button
            onClick={() => signOut()}
            className="mt-2 inline-flex items-center gap-1.5 text-slate-400 hover:text-white"
          >
            <LogOut className="h-3.5 w-3.5" /> Sign out
          </button>
          {useMock && (
            <div className="mt-2 inline-flex items-center text-[10px] uppercase tracking-wider
                            font-semibold text-amber bg-amber/10 rounded px-1.5 py-0.5">
              MOCK
            </div>
          )}
        </div>
      </aside>

      {/* ===== Main ===== */}
      <main className="flex-1 overflow-auto bg-surface">
        <Outlet />
      </main>
    </div>
  );
}
