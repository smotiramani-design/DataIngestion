import { msalInstance, tokenRequest } from "@/lib/auth/msalConfig";
import type { PlatformApi, AuditEntry } from "@/api/types";
import type { Project } from "@/types/common";
import type { Feed, IngestRun, IngestError } from "@/types/ingest";
import type { DqRule, DqValidationRun, DqValidationError, DqStatus } from "@/types/dq";
import type { TxJob, TxStep, TxRun, TxLineageRow } from "@/types/transform";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "";

/** Acquire a fresh access token via MSAL silent flow. Falls back to redirect. */
async function getAccessToken(): Promise<string> {
  const accts = msalInstance.getAllAccounts();
  if (accts.length === 0) {
    await msalInstance.loginRedirect(tokenRequest);
    throw new Error("redirecting to sign-in");
  }
  const result = await msalInstance.acquireTokenSilent({
    ...tokenRequest,
    account: accts[0],
  });
  return result.accessToken;
}

/** Build query string from an opts object, dropping undefined keys. */
function qs(params: Record<string, unknown> | undefined): string {
  if (!params) return "";
  const entries = Object.entries(params).filter(([, v]) => v !== undefined && v !== null);
  if (entries.length === 0) return "";
  return "?" + entries.map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`).join("&");
}

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const token = await getAccessToken();
  const headers: Record<string, string> = {
    Authorization: `Bearer ${token}`,
    Accept: "application/json",
  };
  if (body !== undefined) headers["Content-Type"] = "application/json";

  const res = await fetch(`${API_BASE_URL}${path}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`${method} ${path} failed: ${res.status} ${res.statusText} ${text}`);
  }
  if (res.status === 204) return undefined as unknown as T;
  return res.json() as Promise<T>;
}

const get  = <T>(path: string) => request<T>("GET", path);
const post = <T>(path: string, body: unknown) => request<T>("POST", path, body);
const put  = <T>(path: string, body: unknown) => request<T>("PUT", path, body);

export const httpClient: PlatformApi = {
  // ---- projects ---------------------------------------------------------
  listProjects: () => get<Project[]>(`/api/v1/projects`),

  // ---- ingestion --------------------------------------------------------
  listFeeds: (project_code, opts) =>
    get<Feed[]>(`/api/v1/ingest/projects/${project_code}/feeds${qs(opts)}`),
  getFeed: (feed_id) => get<Feed>(`/api/v1/ingest/feeds/${feed_id}`),
  createFeed: (input) => post<Feed>(`/api/v1/ingest/feeds`, input),
  updateFeed: (feed_id, patch) => put<Feed>(`/api/v1/ingest/feeds/${feed_id}`, patch),
  setFeedActive: (feed_id, is_active) =>
    put<Feed>(`/api/v1/ingest/feeds/${feed_id}/active`, { is_active }),

  listIngestRuns: (project_code, opts) =>
    get<IngestRun[]>(`/api/v1/ingest/projects/${project_code}/runs${qs(opts)}`),
  listIngestErrors: (project_code, opts) =>
    get<IngestError[]>(`/api/v1/ingest/projects/${project_code}/errors${qs(opts)}`),

  // ---- DQ ---------------------------------------------------------------
  listRules: (project_code, opts) =>
    get<DqRule[]>(`/api/v1/dq/projects/${project_code}/rules${qs(opts)}`),
  getRule: (rule_id) => get<DqRule>(`/api/v1/dq/rules/${rule_id}`),
  createRule: (input) => post<DqRule>(`/api/v1/dq/rules`, input),
  updateRule: (rule_id, patch) => put<DqRule>(`/api/v1/dq/rules/${rule_id}`, patch),
  setRuleStatus: (rule_id, status: DqStatus) =>
    put<DqRule>(`/api/v1/dq/rules/${rule_id}/status`, { status }),
  setRuleEnabled: (rule_id, enabled) =>
    put<DqRule>(`/api/v1/dq/rules/${rule_id}/enabled`, { enabled }),

  listDqRuns: (project_code, opts) =>
    get<DqValidationRun[]>(`/api/v1/dq/projects/${project_code}/runs${qs(opts)}`),
  listDqErrors: (project_code, opts) =>
    get<DqValidationError[]>(`/api/v1/dq/projects/${project_code}/errors${qs(opts)}`),
  listPendingApprovals: (project_code) =>
    get<DqRule[]>(`/api/v1/dq/projects/${project_code}/approvals`),

  // ---- Transformation ---------------------------------------------------
  listTxJobs: (project_code, opts) =>
    get<TxJob[]>(`/api/v1/tx/projects/${project_code}/jobs${qs(opts)}`),
  getTxJob: (job_id) => get<TxJob>(`/api/v1/tx/jobs/${job_id}`),
  createTxJob: (input) => post<TxJob>(`/api/v1/tx/jobs`, input),
  updateTxJob: (job_id, patch) => put<TxJob>(`/api/v1/tx/jobs/${job_id}`, patch),
  setTxJobActive: (job_id, is_active) =>
    put<TxJob>(`/api/v1/tx/jobs/${job_id}/active`, { is_active }),

  listTxSteps: (job_id) => get<TxStep[]>(`/api/v1/tx/jobs/${job_id}/steps`),
  upsertTxStep: (input) => post<TxStep>(`/api/v1/tx/steps`, input),

  listTxRuns: (project_code, opts) =>
    get<TxRun[]>(`/api/v1/tx/projects/${project_code}/runs${qs(opts)}`),
  listTxLineage: (project_code, opts) =>
    get<TxLineageRow[]>(`/api/v1/tx/projects/${project_code}/lineage${qs(opts)}`),

  // ---- audit ------------------------------------------------------------
  listAudit: (project_code, opts) =>
    get<AuditEntry[]>(`/api/v1/audit/projects/${project_code}${qs(opts)}`),
};
