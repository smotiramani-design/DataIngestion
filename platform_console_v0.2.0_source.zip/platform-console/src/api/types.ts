/**
 * API contract.
 *
 * Every page calls this interface. Two implementations:
 *   - mockClient: in-memory data, simulated latency. Used when VITE_USE_MOCK=true.
 *   - httpClient: real backend, bearer-token authenticated via MSAL.
 *
 * Selection happens in `client.ts` so pages don't care which backend they
 * are using. Function shapes never differ between mock and real.
 */

import type { Project } from "@/types/common";
import type { Feed, IngestRun, IngestError } from "@/types/ingest";
import type {
  DqRule, DqValidationRun, DqValidationError, DqStatus,
} from "@/types/dq";
import type {
  TxJob, TxStep, TxRun, TxLineageRow,
} from "@/types/transform";

export interface ListOptions {
  limit?: number;
  offset?: number;
  [key: string]: unknown;
}

export interface PlatformApi {
  // ---- projects ---------------------------------------------------------
  listProjects(): Promise<Project[]>;

  // ---- ingestion FW -----------------------------------------------------
  listFeeds(project_code: string, opts?: ListOptions): Promise<Feed[]>;
  getFeed(feed_id: number): Promise<Feed>;
  createFeed(input: Omit<Feed, "feed_id" | "created_at" | "updated_at" | "project_id">): Promise<Feed>;
  updateFeed(feed_id: number, input: Partial<Feed>): Promise<Feed>;
  setFeedActive(feed_id: number, is_active: boolean): Promise<Feed>;

  listIngestRuns(project_code: string, opts?: ListOptions): Promise<IngestRun[]>;
  listIngestErrors(project_code: string, opts?: ListOptions): Promise<IngestError[]>;

  // ---- DQ FW ------------------------------------------------------------
  listRules(project_code: string, opts?: ListOptions): Promise<DqRule[]>;
  getRule(rule_id: string): Promise<DqRule>;
  createRule(input: Omit<DqRule, "created_at" | "updated_at" | "current_version" | "project_id">): Promise<DqRule>;
  updateRule(rule_id: string, input: Partial<DqRule>): Promise<DqRule>;
  setRuleStatus(rule_id: string, status: DqStatus): Promise<DqRule>;
  setRuleEnabled(rule_id: string, enabled: boolean): Promise<DqRule>;

  listDqRuns(project_code: string, opts?: ListOptions): Promise<DqValidationRun[]>;
  listDqErrors(project_code: string, opts?: ListOptions): Promise<DqValidationError[]>;
  listPendingApprovals(project_code: string): Promise<DqRule[]>;

  // ---- Transformation FW ------------------------------------------------
  listTxJobs(project_code: string, opts?: ListOptions): Promise<TxJob[]>;
  getTxJob(job_id: number): Promise<TxJob>;
  createTxJob(input: Omit<TxJob, "job_id" | "created_at" | "updated_at" | "project_id">): Promise<TxJob>;
  updateTxJob(job_id: number, input: Partial<TxJob>): Promise<TxJob>;
  setTxJobActive(job_id: number, is_active: boolean): Promise<TxJob>;

  listTxSteps(job_id: number): Promise<TxStep[]>;
  upsertTxStep(input: Partial<TxStep> & Pick<TxStep, "job_id" | "step_order" | "step_name" | "step_type">): Promise<TxStep>;

  listTxRuns(project_code: string, opts?: ListOptions): Promise<TxRun[]>;
  listTxLineage(project_code: string, opts?: ListOptions): Promise<TxLineageRow[]>;

  // ---- audit ------------------------------------------------------------
  listAudit(project_code: string, opts?: ListOptions): Promise<AuditEntry[]>;
}

/** Cross-framework audit log row, normalized for display. */
export interface AuditEntry {
  audit_id: string;
  framework: "INGEST" | "TRANSFORM" | "DQ" | "PLATFORM";
  project_code: string;
  event_ts: string;
  event_type: string;
  actor: string;
  message: string;
  framework_version: string;
}
