import type { PlatformApi, AuditEntry, ListOptions } from "@/api/types";
import type { Feed } from "@/types/ingest";
import type { DqRule } from "@/types/dq";
import type { TxJob, TxStep } from "@/types/transform";

import * as seed from "./data";

/** Simulate API latency. */
const delay = (ms = 120) => new Promise((res) => setTimeout(res, ms));

/** Apply offset/limit to an array. */
function paginate<T>(arr: T[], opts?: ListOptions): T[] {
  const offset = opts?.offset ?? 0;
  const limit = opts?.limit ?? 1000;
  return arr.slice(offset, offset + limit);
}

/**
 * Mutable in-memory state. Wrapping `seed` arrays in a shallow copy each
 * time keeps page-level sorting from accidentally mutating the seed.
 */
const state = {
  projects: [...seed.projects],
  feeds:    [...seed.feeds],
  ingestRuns:    [...seed.ingestRuns],
  ingestErrors:  [...seed.ingestErrors],
  dqRules:       [...seed.dqRules],
  dqRuns:        [...seed.dqRuns],
  dqErrors:      [...seed.dqErrors],
  txJobs:        [...seed.txJobs],
  txSteps:       [...seed.txSteps],
  txRuns:        [...seed.txRuns],
  txLineage:     [...seed.txLineage],
  audit:         [...seed.audit],
};

let nextFeedId  = 1000;
let nextStepId  = 1000;
let nextJobId   = 1000;

function projectIdFor(project_code: string): number {
  const p = state.projects.find((p) => p.project_code === project_code);
  if (!p) throw new Error(`Unknown project_code: ${project_code}`);
  return p.project_id;
}

export const mockClient: PlatformApi = {
  // ========================================================================
  // Projects
  // ========================================================================
  async listProjects() {
    await delay();
    return [...state.projects];
  },

  // ========================================================================
  // Ingestion
  // ========================================================================
  async listFeeds(project_code, opts) {
    await delay();
    return paginate(state.feeds.filter((f) => f.project_code === project_code), opts);
  },
  async getFeed(feed_id) {
    await delay();
    const found = state.feeds.find((f) => f.feed_id === feed_id);
    if (!found) throw new Error(`feed_id ${feed_id} not found`);
    return { ...found };
  },
  async createFeed(input) {
    await delay();
    const project_id = projectIdFor(input.project_code);
    const newFeed: Feed = {
      ...input,
      feed_id: nextFeedId++,
      project_id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    state.feeds.unshift(newFeed);
    return { ...newFeed };
  },
  async updateFeed(feed_id, patch) {
    await delay();
    const idx = state.feeds.findIndex((f) => f.feed_id === feed_id);
    if (idx === -1) throw new Error(`feed_id ${feed_id} not found`);
    state.feeds[idx] = { ...state.feeds[idx], ...patch, updated_at: new Date().toISOString() };
    return { ...state.feeds[idx] };
  },
  async setFeedActive(feed_id, is_active) {
    return this.updateFeed(feed_id, { is_active });
  },
  async listIngestRuns(project_code, opts) {
    await delay();
    return paginate(
      [...state.ingestRuns].filter((r) => r.project_code === project_code)
        .sort((a, b) => b.start_ts.localeCompare(a.start_ts)),
      opts,
    );
  },
  async listIngestErrors(project_code, opts) {
    await delay();
    return paginate(
      [...state.ingestErrors].filter((e) => e.project_code === project_code)
        .sort((a, b) => b.error_ts.localeCompare(a.error_ts)),
      opts,
    );
  },

  // ========================================================================
  // DQ
  // ========================================================================
  async listRules(project_code, opts) {
    await delay();
    return paginate(state.dqRules.filter((r) => r.project_code === project_code), opts);
  },
  async getRule(rule_id) {
    await delay();
    const r = state.dqRules.find((x) => x.rule_id === rule_id);
    if (!r) throw new Error(`rule_id ${rule_id} not found`);
    return { ...r };
  },
  async createRule(input) {
    await delay();
    const project_id = projectIdFor(input.project_code);
    const rule: DqRule = {
      ...input,
      project_id,
      current_version: 1,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    state.dqRules.unshift(rule);
    return { ...rule };
  },
  async updateRule(rule_id, patch) {
    await delay();
    const idx = state.dqRules.findIndex((x) => x.rule_id === rule_id);
    if (idx === -1) throw new Error(`rule_id ${rule_id} not found`);
    state.dqRules[idx] = { ...state.dqRules[idx], ...patch, updated_at: new Date().toISOString() };
    return { ...state.dqRules[idx] };
  },
  async setRuleStatus(rule_id, status) {
    return this.updateRule(rule_id, { status });
  },
  async setRuleEnabled(rule_id, enabled) {
    return this.updateRule(rule_id, { enabled });
  },
  async listDqRuns(project_code, opts) {
    await delay();
    return paginate(
      [...state.dqRuns].filter((r) => r.project_code === project_code)
        .sort((a, b) => b.start_ts.localeCompare(a.start_ts)),
      opts,
    );
  },
  async listDqErrors(project_code, opts) {
    await delay();
    return paginate(
      [...state.dqErrors].filter((e) => e.project_code === project_code)
        .sort((a, b) => b.error_ts.localeCompare(a.error_ts)),
      opts,
    );
  },
  async listPendingApprovals(project_code) {
    await delay();
    return state.dqRules.filter(
      (r) => r.project_code === project_code && r.status === "PROPOSED",
    );
  },

  // ========================================================================
  // Transformation
  // ========================================================================
  async listTxJobs(project_code, opts) {
    await delay();
    return paginate(state.txJobs.filter((j) => j.project_code === project_code), opts);
  },
  async getTxJob(job_id) {
    await delay();
    const j = state.txJobs.find((x) => x.job_id === job_id);
    if (!j) throw new Error(`job_id ${job_id} not found`);
    return { ...j };
  },
  async createTxJob(input) {
    await delay();
    const project_id = projectIdFor(input.project_code);
    const job: TxJob = {
      ...input,
      project_id,
      job_id: nextJobId++,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    state.txJobs.unshift(job);
    return { ...job };
  },
  async updateTxJob(job_id, patch) {
    await delay();
    const idx = state.txJobs.findIndex((x) => x.job_id === job_id);
    if (idx === -1) throw new Error(`job_id ${job_id} not found`);
    state.txJobs[idx] = { ...state.txJobs[idx], ...patch, updated_at: new Date().toISOString() };
    return { ...state.txJobs[idx] };
  },
  async setTxJobActive(job_id, is_active) {
    return this.updateTxJob(job_id, { is_active });
  },
  async listTxSteps(job_id) {
    await delay();
    return [...state.txSteps].filter((s) => s.job_id === job_id)
      .sort((a, b) => a.step_order - b.step_order);
  },
  async upsertTxStep(input) {
    await delay();
    const idx = state.txSteps.findIndex(
      (s) => s.job_id === input.job_id && s.step_order === input.step_order,
    );
    if (idx >= 0) {
      state.txSteps[idx] = { ...state.txSteps[idx], ...input } as TxStep;
      return { ...state.txSteps[idx] };
    }
    const job = state.txJobs.find((j) => j.job_id === input.job_id);
    if (!job) throw new Error(`job_id ${input.job_id} not found`);
    const step: TxStep = {
      step_id: nextStepId++,
      job_id: input.job_id,
      project_id: job.project_id,
      step_order: input.step_order,
      step_name: input.step_name,
      step_type: input.step_type,
      input_alias: input.input_alias ?? null,
      output_alias: input.output_alias ?? null,
      config: input.config ?? {},
      depends_on_step_ids: input.depends_on_step_ids ?? [],
      error_strategy: input.error_strategy ?? "fail",
      expected_min_rows: input.expected_min_rows ?? null,
      expected_max_rows: input.expected_max_rows ?? null,
      enabled: input.enabled ?? true,
    };
    state.txSteps.push(step);
    return { ...step };
  },
  async listTxRuns(project_code, opts) {
    await delay();
    return paginate(
      [...state.txRuns].filter((r) => r.project_code === project_code)
        .sort((a, b) => b.started_at.localeCompare(a.started_at)),
      opts,
    );
  },
  async listTxLineage(project_code, opts) {
    await delay();
    const projId = projectIdFor(project_code);
    return paginate(
      [...state.txLineage].filter((l) => l.project_id === projId)
        .sort((a, b) => b.captured_at.localeCompare(a.captured_at)),
      opts,
    );
  },

  // ========================================================================
  // Audit
  // ========================================================================
  async listAudit(project_code, opts) {
    await delay();
    const arr: AuditEntry[] = [...state.audit].filter((a) => a.project_code === project_code)
      .sort((a, b) => b.event_ts.localeCompare(a.event_ts));
    return paginate(arr, opts);
  },
};
