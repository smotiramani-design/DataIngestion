import type { Project } from "@/types/common";
import type { Feed, IngestRun, IngestError } from "@/types/ingest";
import type { DqRule, DqValidationRun, DqValidationError } from "@/types/dq";
import type { TxJob, TxStep, TxRun, TxLineageRow } from "@/types/transform";
import type { AuditEntry } from "@/api/types";

export const projects: Project[] = [
  {
    project_id: 1, project_code: "FIN", project_name: "Finance",
    default_catalog: "fin_prod",
    bronze_schema: "bronze", silver_schema: "silver", gold_schema: "gold",
    alert_email: "fin-data-platform@corp", owner_team: "fin-platform",
    ingest_framework_version: "0.2.0",
    tx_framework_version: "0.2.0",
    dq_framework_version: "0.2.0",
    is_active: true,
  },
  {
    project_id: 2, project_code: "MKT", project_name: "Marketing",
    default_catalog: "mkt_prod",
    bronze_schema: "bronze", silver_schema: "silver", gold_schema: "gold",
    alert_email: "mkt-analytics@corp", owner_team: "mkt-analytics",
    ingest_framework_version: "0.2.0",
    tx_framework_version: "0.2.0",
    dq_framework_version: "0.2.0",
    is_active: true,
  },
  {
    project_id: 3, project_code: "OPS", project_name: "Operations",
    default_catalog: "ops_prod",
    bronze_schema: "bronze", silver_schema: "silver", gold_schema: "gold",
    alert_email: "ops-data@corp", owner_team: "ops-platform",
    ingest_framework_version: "0.1.5",   // intentionally older to highlight in UI
    tx_framework_version: "0.2.0",
    dq_framework_version: "0.2.0",
    is_active: true,
  },
];

const now = new Date();
const iso = (offsetMin: number) => new Date(now.getTime() - offsetMin * 60_000).toISOString();

// ---------------------------------------------------------------------------
// Ingestion fixtures
// ---------------------------------------------------------------------------
export const feeds: Feed[] = [
  {
    feed_id: 100, project_id: 1, project_code: "FIN", feed_name: "orders_csv",
    source_type: "CSV", source_table: null, target_bronze_table: "fin_prod.bronze.orders",
    event_time_column: "event_ts", is_active: true,
    created_at: iso(60 * 24 * 30), updated_at: iso(60 * 6), created_by: "akhil@corp",
  },
  {
    feed_id: 101, project_id: 1, project_code: "FIN", feed_name: "customers_jdbc",
    source_type: "RDBMS", source_table: "crm.customers",
    target_bronze_table: "fin_prod.bronze.customers",
    event_time_column: "updated_at", is_active: true,
    created_at: iso(60 * 24 * 60), updated_at: iso(60 * 12), created_by: "akhil@corp",
  },
  {
    feed_id: 200, project_id: 2, project_code: "MKT", feed_name: "campaigns_api",
    source_type: "API", source_table: null,
    target_bronze_table: "mkt_prod.bronze.campaigns",
    event_time_column: "synced_at", is_active: true,
    created_at: iso(60 * 24 * 14), updated_at: iso(60 * 4), created_by: "mkt-eng@corp",
  },
  {
    feed_id: 300, project_id: 3, project_code: "OPS", feed_name: "fleet_xml",
    source_type: "XML", source_table: null,
    target_bronze_table: "ops_prod.bronze.fleet_events",
    event_time_column: "event_ts", is_active: false,
    created_at: iso(60 * 24 * 90), updated_at: iso(60 * 24 * 7), created_by: "ops-eng@corp",
  },
];

export const ingestRuns: IngestRun[] = [
  {
    run_id: "ing-r-001", project_id: 1, project_code: "FIN", feed_id: 100,
    feed_name: "orders_csv",
    start_ts: iso(15), end_ts: iso(13), status: "success",
    rows_in: 42_310, rows_out: 42_298, duration_sec: 118,
    target_table: "fin_prod.bronze.orders", max_event_ts: iso(14),
    error_message: null, framework_version: "0.2.0",
  },
  {
    run_id: "ing-r-002", project_id: 1, project_code: "FIN", feed_id: 101,
    feed_name: "customers_jdbc",
    start_ts: iso(40), end_ts: iso(35), status: "success",
    rows_in: 8_204, rows_out: 8_204, duration_sec: 311,
    target_table: "fin_prod.bronze.customers", max_event_ts: iso(36),
    error_message: null, framework_version: "0.2.0",
  },
  {
    run_id: "ing-r-003", project_id: 2, project_code: "MKT", feed_id: 200,
    feed_name: "campaigns_api",
    start_ts: iso(60), end_ts: iso(58), status: "failed",
    rows_in: null, rows_out: null, duration_sec: 121,
    target_table: null, max_event_ts: null,
    error_message: "401 Unauthorized from upstream API", framework_version: "0.2.0",
  },
];

export const ingestErrors: IngestError[] = [
  {
    error_id: 1, project_id: 2, project_code: "MKT",
    run_id: "ing-r-003", feed_name: "campaigns_api",
    error_ts: iso(58), error_type: "AuthError",
    error_message: "401 Unauthorized from upstream API",
    raw_record: null,
  },
];

// ---------------------------------------------------------------------------
// DQ fixtures
// ---------------------------------------------------------------------------
export const dqRules: DqRule[] = [
  {
    rule_id: "F_FIN_0001", project_id: 1, project_code: "FIN", current_version: 1,
    name: "orders bronze schema",
    description: "Bronze orders must have the canonical column set.",
    layer: "FILE", check_type: "SCHEMA", severity: "BLOCK",
    datasets: ["fin_prod.bronze.orders"], expression: null,
    params: { expected_columns: "order_id,customer_id,amount,status,event_ts" },
    owner: "akhil@corp", status: "APPROVED", enabled: true,
    created_at: iso(60 * 24 * 30), updated_at: iso(60 * 24 * 7),
  },
  {
    rule_id: "B_FIN_0010", project_id: 1, project_code: "FIN", current_version: 2,
    name: "silver.orders order_id is unique",
    description: "Primary key in silver layer.",
    layer: "BUSINESS_RULE", check_type: "PRIMARY_KEY", severity: "BLOCK",
    datasets: ["fin_prod.silver.silver_orders"], expression: null,
    params: { columns: "order_id" },
    owner: "akhil@corp", status: "APPROVED", enabled: true,
    created_at: iso(60 * 24 * 60), updated_at: iso(60 * 24 * 14),
  },
  {
    rule_id: "P_FIN_0020", project_id: 1, project_code: "FIN", current_version: 1,
    name: "fct_sales total = silver.orders sum",
    description: "Sum of amount in fct_sales must equal sum in silver.orders within tolerance.",
    layer: "POST_TRANSFORM", check_type: "AGGREGATE_PARITY", severity: "BLOCK",
    datasets: ["fin_prod.gold.gold_fct_sales", "fin_prod.silver.silver_orders"],
    expression: null,
    params: {
      left_table: "fin_prod.gold.gold_fct_sales", left_agg: "sum(amount)",
      right_table: "fin_prod.silver.silver_orders", right_agg: "sum(amount)",
      filter: "status IN ('PAID','SHIPPED','DELIVERED')",
      tolerance_pct: "0.001",
    },
    owner: "akhil@corp", status: "PROPOSED", enabled: false,
    created_at: iso(60 * 6), updated_at: iso(60 * 6),
  },
  {
    rule_id: "B_MKT_0001", project_id: 2, project_code: "MKT", current_version: 1,
    name: "campaigns.id is unique",
    layer: "BUSINESS_RULE", check_type: "PRIMARY_KEY", severity: "BLOCK",
    datasets: ["mkt_prod.silver.silver_campaigns"], expression: null,
    params: { columns: "campaign_id" },
    description: "Marketing campaign IDs must be unique in silver.",
    owner: "mkt-eng@corp", status: "APPROVED", enabled: true,
    created_at: iso(60 * 24 * 30), updated_at: iso(60 * 24 * 14),
  },
];

export const dqRuns: DqValidationRun[] = [
  {
    run_id: "dq-r-001", project_id: 1, project_code: "FIN",
    trigger_type: "INGESTION", trigger_ref: "adf-pipe-1234",
    triggering_framework: "INGEST",
    ingest_run_id: "ing-r-001", tx_run_id: null,
    start_ts: iso(13), end_ts: iso(12), status: "PASS",
    rules_evaluated: 3, rules_passed: 3, rules_warned: 0, rules_failed: 0,
    records_checked: 42_298, duration_sec: 41,
    should_block_publish: false, framework_version: "0.2.0",
  },
  {
    run_id: "dq-r-002", project_id: 1, project_code: "FIN",
    trigger_type: "TRANSFORM", trigger_ref: "tx-r-999",
    triggering_framework: "TRANSFORM",
    ingest_run_id: null, tx_run_id: "tx-r-999",
    start_ts: iso(8), end_ts: iso(7), status: "WARN",
    rules_evaluated: 4, rules_passed: 3, rules_warned: 1, rules_failed: 0,
    records_checked: 91_240, duration_sec: 56,
    should_block_publish: false, framework_version: "0.2.0",
  },
];

export const dqErrors: DqValidationError[] = [
  {
    error_id: 1, project_id: 1, project_code: "FIN", run_id: "dq-r-002",
    rule_id: "P_FIN_0021", rule_version: 1,
    dataset: "fin_prod.gold.gold_fct_sales",
    error_ts: iso(7), severity: "WARN",
    failure_count: 1, sample_count: 0, raw_record: null,
    error_message: "Row count dropped 6.4% from 1240312 to 1160987",
  },
];

// ---------------------------------------------------------------------------
// Transformation fixtures
// ---------------------------------------------------------------------------
export const txJobs: TxJob[] = [
  {
    job_id: 100, project_id: 1, project_code: "FIN",
    job_code: "silver_orders", job_version: 1,
    source_layer: "bronze", target_layer: "silver",
    target_catalog: "fin_prod", target_schema: "silver", target_table: "silver_orders",
    write_mode: "merge",
    primary_key_cols: ["order_id"], partition_cols: ["order_date"],
    schedule_cron: "0 */6 * * *", block_on_dq_fail: true,
    git_sha: "abc1234", is_active: true,
    created_at: iso(60 * 24 * 30), updated_at: iso(60 * 12),
  },
  {
    job_id: 101, project_id: 1, project_code: "FIN",
    job_code: "silver_dim_customer", job_version: 1,
    source_layer: "bronze", target_layer: "silver",
    target_catalog: "fin_prod", target_schema: "silver", target_table: "dim_customer",
    write_mode: "merge",
    primary_key_cols: ["customer_id"], partition_cols: [],
    schedule_cron: "0 0 * * *", block_on_dq_fail: true,
    git_sha: "def5678", is_active: true,
    created_at: iso(60 * 24 * 30), updated_at: iso(60 * 24 * 4),
  },
  {
    job_id: 102, project_id: 1, project_code: "FIN",
    job_code: "gold_fct_sales_daily", job_version: 1,
    source_layer: "silver", target_layer: "gold",
    target_catalog: "fin_prod", target_schema: "gold", target_table: "fct_sales_daily",
    write_mode: "overwrite",
    primary_key_cols: ["sale_date", "customer_id"], partition_cols: ["sale_date"],
    schedule_cron: "0 6 * * *", block_on_dq_fail: true,
    git_sha: "ghi9012", is_active: true,
    created_at: iso(60 * 24 * 14), updated_at: iso(60 * 8),
  },
];

export const txSteps: TxStep[] = [
  {
    step_id: 1, job_id: 100, project_id: 1, step_order: 1,
    step_name: "read_bronze_orders", step_type: "read_delta",
    input_alias: null, output_alias: "raw_orders",
    config: { table_fqn: "fin_prod.bronze.orders" },
    depends_on_step_ids: [], error_strategy: "fail",
    expected_min_rows: null, expected_max_rows: null, enabled: true,
  },
  {
    step_id: 2, job_id: 100, project_id: 1, step_order: 2,
    step_name: "cleanse_orders", step_type: "cleanse",
    input_alias: "raw_orders", output_alias: "cleansed_orders",
    config: { trim_cols: ["status"], cast: { amount: "decimal(18,2)" } },
    depends_on_step_ids: [], error_strategy: "fail",
    expected_min_rows: null, expected_max_rows: null, enabled: true,
  },
  {
    step_id: 3, job_id: 100, project_id: 1, step_order: 3,
    step_name: "dedup_orders", step_type: "dedup",
    input_alias: "cleansed_orders", output_alias: "deduped_orders",
    config: { business_key: ["order_id"], order_by: "event_ts DESC", keep: "first" },
    depends_on_step_ids: [], error_strategy: "fail",
    expected_min_rows: null, expected_max_rows: null, enabled: true,
  },
  {
    step_id: 4, job_id: 100, project_id: 1, step_order: 4,
    step_name: "write_silver_orders", step_type: "write_delta",
    input_alias: "deduped_orders", output_alias: null,
    config: { merge_on: ["order_id"], partition_cols: ["order_date"] },
    depends_on_step_ids: [], error_strategy: "fail",
    expected_min_rows: null, expected_max_rows: null, enabled: true,
  },
];

export const txRuns: TxRun[] = [
  {
    tx_run_id: "tx-r-999", project_id: 1, project_code: "FIN",
    job_id: 100, job_code: "silver_orders", job_version: 1,
    adf_pipeline_run_id: "adf-pipe-1234", triggered_by: "upstream",
    upstream_run_id: "ing-r-001",
    effective_date: now.toISOString().slice(0, 10),
    dry_run: false, override_target: null,
    started_at: iso(11), ended_at: iso(8), status: "success",
    rows_read: 42_298, rows_written: 41_802, rows_rejected: 496,
    duration_sec: 173,
    dq_verdict: "warn", dq_run_id: "dq-r-002",
    should_block_publish: false,
    error_message: null,
  },
];

export const txLineage: TxLineageRow[] = [
  {
    lineage_id: 1, tx_run_id: "tx-r-999", project_id: 1, job_id: 100,
    src_table_fqn: "fin_prod.bronze.orders",
    tgt_table_fqn: "fin_prod.silver.silver_orders",
    transform_type: "merge", captured_at: iso(8),
  },
];

// ---------------------------------------------------------------------------
// Cross-framework audit
// ---------------------------------------------------------------------------
export const audit: AuditEntry[] = [
  {
    audit_id: "a-1", framework: "INGEST", project_code: "FIN",
    event_ts: iso(13), event_type: "RUN_END",
    actor: "adf", message: "ingest run ing-r-001 finished status=success",
    framework_version: "0.2.0",
  },
  {
    audit_id: "a-2", framework: "TRANSFORM", project_code: "FIN",
    event_ts: iso(8), event_type: "RUN_END",
    actor: "adf", message: "tx run tx-r-999 finished status=success",
    framework_version: "0.2.0",
  },
  {
    audit_id: "a-3", framework: "DQ", project_code: "FIN",
    event_ts: iso(7), event_type: "RUN_END",
    actor: "transform_framework",
    message: "dq run dq-r-002 finished status=WARN (triggering_framework=TRANSFORM)",
    framework_version: "0.2.0",
  },
];
