import type { PlatformApi } from "@/api/types";
import { mockClient } from "@/api/mock/mockClient";
import { httpClient } from "@/api/httpClient";

const USE_MOCK = import.meta.env.VITE_USE_MOCK === "true";

export const api: PlatformApi = USE_MOCK ? mockClient : httpClient;
