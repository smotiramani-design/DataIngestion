# Data Platform Console

Unified config-authoring console for the three platform frameworks:

- **Ingestion FW** v0.2.0 — feeds, audit log, errors
- **DQ FW** v0.2.0 — rules, validation runs, approvals
- **Transformation FW** v0.2.0 — jobs, steps, runs, lineage

Single sign-on via **Microsoft Entra ID**, with RBAC enforced both at the
route level and at the action level (button hide / disable). The UI is **not
a security boundary**; the backend must mirror the same permission matrix
on every API call.

## Stack

- React 18 + Vite 6 + TypeScript (strict)
- Tailwind 3 (navy / teal palette matching the prior 1-FW consoles)
- React Router v6
- TanStack Query v5
- @azure/msal-react v2 + @azure/msal-browser v3
- recharts, lucide-react

## Getting started

```bash
cp .env.example .env.local
# Edit .env.local — at minimum set VITE_USE_MOCK=true to skip Entra in dev.
npm install
npm run dev   # http://localhost:5173
```

For a production build:

```bash
npm run build && npm run preview
```

## Mock mode

`VITE_USE_MOCK=true` skips MSAL entirely and uses an in-memory mock backend
seeded with three projects (FIN, MKT, OPS) and v0.2-shaped fixtures across
all three frameworks. Switch personas without re-authing via the
`?as=` query parameter:

- `?as=platform_admin` (default; full access to all three projects)
- `?as=project_owner` (owner of FIN, business user of MKT)
- `?as=business_user` (business user of FIN and MKT)

Roles are taken from `src/lib/auth/useAuth.ts → getMockUser()`. Edit it to
mirror your own org's role distribution while testing.

## Configuring Entra ID

In your Entra tenant:

1. **App registration** of type *Single-page application*. The redirect URI
   must match `VITE_AUTH_REDIRECT_URI` (e.g. `https://platform.example.com/`).
2. **Expose an API** with at least one scope (e.g. `access_as_user`). The
   full scope identifier (`api://{client-id}/access_as_user`) goes into
   `VITE_AUTH_API_SCOPE`.
3. **App roles** — define one app role per platform role:
   - `platform_admin`
   - `project_owner`
   - `business_user`
   - …plus any you add (see "Adding a new role" below).
4. **Token configuration** — add an optional claim called
   `extension_project_roles` to the ID token (or shape your own custom claim
   matching the same name). The backend issues this claim by joining
   the `project_user` table; its value is a JSON object of the form
   `{"FIN": ["project_owner"], "MKT": ["business_user"]}`.
5. **API permissions** — grant the SPA the scope it exposes.
6. **Users and groups** — assign tenant-level app roles. Per-project grants
   are managed via the platform's `project_user` table, *not* in Entra.

Set the matching environment variables in `.env.local`:

```
VITE_AUTH_CLIENT_ID=<the SPA client ID>
VITE_AUTH_TENANT_ID=<your tenant GUID>
VITE_AUTH_REDIRECT_URI=https://platform.example.com/
VITE_AUTH_API_SCOPE=api://<client-id>/access_as_user
VITE_API_BASE_URL=https://platform-api.example.com
VITE_USE_MOCK=false
```

## RBAC model

### Where roles are defined

`src/lib/auth/roles.ts` is the single source of truth. It declares:

1. The `Permission` union — the action surface across all three frameworks.
2. The `ROLES` map — role-key → permissions.

Components never check role names directly. They ask the
`usePermissions().can(perm, { project_code })` hook for action booleans.
This means changing a permission grant is a one-line edit and never
ripples through pages.

### Built-in roles

| Role             | Description                                                                                  |
| ---------------- | -------------------------------------------------------------------------------------------- |
| `platform_admin` | Full read/write across every framework, every project. Can approve DQ rules. Manages users.  |
| `project_owner`  | Read/write on assigned projects across Ingest, DQ, Transform. Approves DQ rules.             |
| `business_user`  | Read everywhere; write feeds within assigned projects; *propose* (not approve) DQ rules.     |

### How a permission check resolves

For a given (user, project_code) tuple:

1. Take the user's tenant-level roles from the JWT `roles` claim.
2. Union with the user's project-level roles for `project_code`
   from the `extension_project_roles` claim.
3. Resolve each role's granted permissions via the `ROLES` map.
4. The user has the permission iff any of their roles grants it.

This means a user can be `business_user` in MKT and `project_owner` in FIN
simultaneously, and the UI gates correctly per project.

### Adding a new role

1. Add the role to `ROLES` in `src/lib/auth/roles.ts`. Keep the key short
   and snake_case; pick a Tailwind pill class for visual identification.
2. Define a matching app role in your Entra ID app registration with the
   *same string identifier*.
3. Mirror the new role's permissions on the backend authorization layer.
4. Assign users to the role in Entra (tenant-wide) and/or in
   `project_user` (project-scoped).

No other code changes are needed in the console. Sidebar nav, route
guards, and action buttons all read from the `Permission` union via
`usePermissions()`.

## Architecture

```
src/
├── api/
│   ├── client.ts         # dispatcher: mock vs http based on VITE_USE_MOCK
│   ├── types.ts          # PlatformApi interface (every page calls through this)
│   ├── httpClient.ts     # real backend; bearer-token authenticated via MSAL
│   └── mock/
│       ├── data.ts       # seed fixtures (3 projects, v0.2-shaped lineage)
│       └── mockClient.ts # in-memory implementation
├── components/
│   ├── Layout.tsx        # sidebar, top bar, project switcher; nav items hidden by perms
│   ├── ProjectSwitcher.tsx
│   ├── PageHeader.tsx
│   ├── EmptyState.tsx
│   └── Pill.tsx
├── lib/
│   ├── auth/
│   │   ├── roles.ts          # source-of-truth for role/permission matrix
│   │   ├── msalConfig.ts     # MSAL singleton
│   │   ├── useAuth.ts        # useAuth + usePermissions hooks
│   │   └── RequireAuth.tsx   # <RequireAuth> + <RequirePerm> route gates
│   └── projectContext.tsx    # selected-project provider, persisted to localStorage
├── pages/
│   ├── DashboardPage.tsx     # cross-framework KPIs
│   ├── ProjectsPage.tsx      # project registry (read-only across all FWs)
│   ├── AuditPage.tsx         # cross-framework audit log
│   ├── UsersPage.tsx         # role catalog (membership lives in Entra)
│   ├── SettingsPage.tsx      # project identity + framework versions
│   ├── LoginPage.tsx
│   ├── AccessDeniedPage.tsx
│   ├── ingest/   FeedsPage, IngestRunsPage, IngestErrorsPage
│   ├── dq/       DqRulesPage, DqRunsPage, ApprovalsPage
│   └── transform/ TxJobsPage, TxStepsPage, TxRunsPage, TxLineagePage
├── styles/globals.css        # Tailwind directives + utility classes
├── types/        common, ingest, dq, transform — typed surface for every API call
├── App.tsx                   # route table with permission gates
└── main.tsx                  # MsalProvider + QueryClientProvider + ProjectProvider root
```

## Route map

| Path                                  | Permission required  | Notes                            |
| ------------------------------------- | -------------------- | -------------------------------- |
| `/login`                              | —                    | Sign-in entry point              |
| `/dashboard`                          | `project.read`       | Cross-framework KPIs             |
| `/projects`                           | `project.read`       | Read-only project registry       |
| `/ingest/feeds`                       | `feed.read`          | Create/edit gated by `feed.write` |
| `/ingest/runs`                        | `ingest_run.read`    | audit_log v0.2 with `target_table`+`max_event_ts` |
| `/ingest/errors`                      | `ingest_error.read`  | error_log                        |
| `/dq/rules`                           | `rule.read`          | Propose vs approve gated by role |
| `/dq/runs`                            | `dq_run.read`        | Shows v0.2 lineage triple        |
| `/dq/approvals`                       | `dq_approve.write`   | Project Owner + Platform Admin   |
| `/transform/jobs`                     | `tx_job.read`        | Create/edit gated by `tx_job.write` |
| `/transform/jobs/:jobId/steps`        | `tx_step.read`       | Step editor                      |
| `/transform/runs`                     | `tx_run.read`        | tx_runs with `dq_verdict`+`should_block_publish` |
| `/transform/lineage`                  | `tx_run.read`        | src→tgt mapping                  |
| `/audit`                              | `audit.read`         | Cross-framework events           |
| `/users`                              | `user.read`          | Role catalog (PA only by default)|
| `/settings`                           | `settings.write`     | Project identity (PA only by default)|
| `/access-denied`                      | (auth only)          | Lands here on RBAC failure       |

## v0.2 alignment

Every page that displays platform run rows surfaces the v0.2 cross-framework
lineage fields:

- **Ingestion runs** show `target_table` and `max_event_ts`.
- **DQ runs** show `triggering_framework`, the upstream pointer
  (`ingest_run_id` or `tx_run_id`), and `should_block_publish`.
- **Transform runs** show `upstream_run_id`, `dq_verdict`, `dq_run_id`, and
  `should_block_publish`.

The mock data exercises the canonical chain ingest-r-001 → tx-r-999 → dq-r-002
so that the linkage is visible end-to-end without a backend.

## Backend contract

The `httpClient` expects REST endpoints under `/api/v1/`:

```
GET  /api/v1/projects
GET  /api/v1/ingest/projects/:project_code/feeds
POST /api/v1/ingest/feeds
GET  /api/v1/dq/projects/:project_code/rules
PUT  /api/v1/dq/rules/:rule_id/status
GET  /api/v1/tx/projects/:project_code/jobs
GET  /api/v1/tx/jobs/:job_id/steps
GET  /api/v1/audit/projects/:project_code
…
```

See `src/api/httpClient.ts` for the full surface. Bearer token is acquired
silently via MSAL on every request; refresh is automatic.

## Design notes

- The visual language matches the two prior 1-FW consoles: navy sidebar
  (`#0B2545`), teal accents (`#00A6A6`), surface off-white panels, mono
  fonts for IDs and table FQNs.
- Sidebar nav items are auto-hidden when the user lacks the required
  permission for the *currently-selected* project. Switch projects in the
  sidebar dropdown to re-evaluate.
- Active project is persisted in `localStorage` under
  `platform-console.selected-project`.
- The mock client simulates 120ms of latency per call so loading skeletons
  and disabled states actually fire in dev.
