/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        navy:    { DEFAULT: "#0B2545", deep: "#0B2545", mid: "#13315C", soft: "#1C7293" },
        teal:    { DEFAULT: "#00A6A6", deep: "#008A8A", soft: "#5EEAD4" },
        amber:   { DEFAULT: "#F4B860" },
        ink:     { DEFAULT: "#0B2545" },
        graphite: { DEFAULT: "#334155", muted: "#64748B" },
        surface: {
          DEFAULT: "#F4F7FB",
          soft:    "#EEF2F8",
          border:  "#D6E1EE",
        },
        success: { DEFAULT: "#10B981", soft: "#ECFDF5" },
        warn:    { DEFAULT: "#F59E0B", soft: "#FEF3C7" },
        danger:  { DEFAULT: "#DC2626", soft: "#FEE2E2" },
      },
      fontFamily: {
        sans: ["'Söhne'", "Inter", "system-ui", "-apple-system", "sans-serif"],
        mono: ["'JetBrains Mono'", "ui-monospace", "Consolas", "monospace"],
      },
      boxShadow: {
        soft: "0 1px 2px 0 rgb(11 37 69 / 0.04), 0 1px 3px 0 rgb(11 37 69 / 0.06)",
        card: "0 4px 12px -2px rgb(11 37 69 / 0.08), 0 2px 6px -2px rgb(11 37 69 / 0.04)",
      },
    },
  },
  plugins: [],
};
