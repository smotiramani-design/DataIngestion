-- =============================================================================
-- Sample feed_config rows — one per supported source pattern.
-- Run after sql/01_create_control_tables.sql.
--
-- These are illustrative templates. Replace placeholders (URLs, JDBC strings,
-- secret references) before running against a real environment. In production,
-- credentials should come from dbutils.secrets.get(...) — never hard-coded.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1. REST API (cursor-paginated, bearer auth)
-- -----------------------------------------------------------------------------
INSERT INTO ingest_platform.control.feed_config
    (feed_name, source_type, source_location, source_options,
     target_table, schema_definition, load_mode, watermark_column,
     schedule_cron, sla_minutes, owner, is_active)
VALUES (
    'customers_api',
    'API',
    'https://api.example.com/v2/customers',
    map(
        'auth_type',     'bearer',
        'auth_token',    '{{secrets/ingest/customers_api_token}}',
        'pagination',    'cursor',
        'cursor_field',  'meta.next_cursor',
        'cursor_param',  'cursor',
        'records_path',  'data',
        'timeout_seconds', '30',
        'max_retries',   '5'
    ),
    'ingest_platform.bronze.customers_api',
    NULL,
    'INCREMENTAL',
    'updated_at',
    '0 */15 * * * ?',     -- every 15 min
    15,
    'customer-data-team@example.com',
    TRUE
);

-- -----------------------------------------------------------------------------
-- 2. Oracle (JDBC, partitioned read, INCREMENTAL on updated_at)
-- -----------------------------------------------------------------------------
INSERT INTO ingest_platform.control.feed_config
    (feed_name, source_type, source_location, source_options,
     target_table, schema_definition, load_mode, watermark_column,
     schedule_cron, sla_minutes, owner, is_active)
VALUES (
    'orders_oracle',
    'RDBMS',
    'jdbc:oracle:thin:@//oracle-prod.example.com:1521/ORCL',
    map(
        'driver',           'oracle.jdbc.OracleDriver',
        'user',             '{{secrets/ingest/oracle_user}}',
        'password',         '{{secrets/ingest/oracle_password}}',
        'dbtable',          'SALES.ORDERS',
        'fetch_size',       '20000',
        'partition_column', 'ORDER_ID',
        'lower_bound',      '1',
        'upper_bound',      '50000000',
        'num_partitions',   '8',
        'count_check_enabled', 'true'
    ),
    'ingest_platform.bronze.orders_oracle',
    NULL,
    'INCREMENTAL',
    'UPDATED_AT',
    '0 0 */1 * * ?',      -- hourly
    60,
    'sales-data-team@example.com',
    TRUE
);

-- -----------------------------------------------------------------------------
-- 3. SQL Server (full reload, smaller dimension table)
-- -----------------------------------------------------------------------------
INSERT INTO ingest_platform.control.feed_config
    (feed_name, source_type, source_location, source_options,
     target_table, schema_definition, load_mode, watermark_column,
     schedule_cron, sla_minutes, owner, is_active)
VALUES (
    'product_dim_mssql',
    'RDBMS',
    'jdbc:sqlserver://mssql-prod.example.com:1433;database=Catalog;encrypt=true',
    map(
        'driver',   'com.microsoft.sqlserver.jdbc.SQLServerDriver',
        'user',     '{{secrets/ingest/mssql_user}}',
        'password', '{{secrets/ingest/mssql_password}}',
        'dbtable',  'dbo.product_dim'
    ),
    'ingest_platform.bronze.product_dim',
    NULL,
    'FULL',
    NULL,
    '0 0 2 * * ?',        -- daily 2am
    240,
    'catalog-team@example.com',
    TRUE
);

-- -----------------------------------------------------------------------------
-- 4. JSON (Auto Loader streaming from ADLS)
-- -----------------------------------------------------------------------------
INSERT INTO ingest_platform.control.feed_config
    (feed_name, source_type, source_location, source_options,
     target_table, schema_definition, load_mode, watermark_column,
     schedule_cron, sla_minutes, owner, is_active)
VALUES (
    'billing_events_json',
    'JSON',
    'abfss://landing@datalake.dfs.core.windows.net/billing/events/',
    map(
        'streaming',       'true',
        'multiline',       'false',
        'schema_location', 'abfss://landing@datalake.dfs.core.windows.net/_schemas/billing_events/'
    ),
    'ingest_platform.bronze.billing_events',
    NULL,
    'INCREMENTAL',
    NULL,
    NULL,                 -- continuous via DLT
    30,
    'billing-team@example.com',
    TRUE
);

-- -----------------------------------------------------------------------------
-- 5. Excel — single tab
-- -----------------------------------------------------------------------------
INSERT INTO ingest_platform.control.feed_config
    (feed_name, source_type, source_location, source_options,
     target_table, schema_definition, load_mode, watermark_column,
     schedule_cron, sla_minutes, owner, is_active)
VALUES (
    'forecast_excel',
    'EXCEL',
    'abfss://landing@datalake.dfs.core.windows.net/finance/forecast/forecast_2026.xlsx',
    map(
        'header',        'true',
        'infer_schema',  'true',
        'data_address',  'A1'
    ),
    'ingest_platform.bronze.forecast',
    NULL,
    'FULL',
    NULL,
    '0 0 6 * * MON',      -- Mondays 6am
    60,
    'finance-team@example.com',
    TRUE
);

-- -----------------------------------------------------------------------------
-- 6. Excel — multi-tab (all tabs union'd into one Bronze table with _sheet_name)
-- -----------------------------------------------------------------------------
INSERT INTO ingest_platform.control.feed_config
    (feed_name, source_type, source_location, source_options,
     target_table, schema_definition, load_mode, watermark_column,
     schedule_cron, sla_minutes, owner, is_active)
VALUES (
    'regional_sales_excel',
    'EXCEL',
    'abfss://landing@datalake.dfs.core.windows.net/sales/regional/regional_sales.xlsx',
    map(
        'header',       'true',
        'infer_schema', 'true',
        'sheets',       'NorthAmerica,EMEA,APAC,LATAM'
    ),
    'ingest_platform.bronze.regional_sales',
    NULL,
    'FULL',
    NULL,
    '0 0 5 * * ?',
    120,
    'sales-data-team@example.com',
    TRUE
);

-- -----------------------------------------------------------------------------
-- 7. CSV (with header, comma-separated, PERMISSIVE)
-- -----------------------------------------------------------------------------
INSERT INTO ingest_platform.control.feed_config
    (feed_name, source_type, source_location, source_options,
     target_table, schema_definition, load_mode, watermark_column,
     schedule_cron, sla_minutes, owner, is_active)
VALUES (
    'transactions_csv',
    'CSV',
    'abfss://landing@datalake.dfs.core.windows.net/payments/transactions/',
    map(
        'streaming',     'true',
        'header',        'true',
        'infer_schema',  'true',
        'encoding',      'UTF-8',
        'schema_location', 'abfss://landing@datalake.dfs.core.windows.net/_schemas/transactions/'
    ),
    'ingest_platform.bronze.transactions',
    NULL,
    'INCREMENTAL',
    NULL,
    NULL,                 -- continuous
    30,
    'payments-team@example.com',
    TRUE
);

-- -----------------------------------------------------------------------------
-- 8. Pipe-delimited (vendor file)
-- -----------------------------------------------------------------------------
INSERT INTO ingest_platform.control.feed_config
    (feed_name, source_type, source_location, source_options,
     target_table, schema_definition, load_mode, watermark_column,
     schedule_cron, sla_minutes, owner, is_active)
VALUES (
    'vendor_extract_pipe',
    'DELIMITED',
    'abfss://landing@datalake.dfs.core.windows.net/vendors/acme/',
    map(
        'delimiter',    '|',
        'header',       'true',
        'quote',        '"',
        'escape',       '\\',
        'encoding',     'UTF-8'
    ),
    'ingest_platform.bronze.vendor_acme',
    NULL,
    'FULL',
    NULL,
    '0 30 4 * * ?',
    60,
    'vendor-ops@example.com',
    TRUE
);

-- -----------------------------------------------------------------------------
-- 9. Fixed-length (mainframe ledger extract)
-- -----------------------------------------------------------------------------
INSERT INTO ingest_platform.control.feed_config
    (feed_name, source_type, source_location, source_options,
     target_table, schema_definition, load_mode, watermark_column,
     schedule_cron, sla_minutes, owner, is_active)
VALUES (
    'ledger_fixed',
    'FIXED',
    'abfss://landing@datalake.dfs.core.windows.net/mainframe/ledger/',
    map(),
    'ingest_platform.bronze.ledger',
    -- Position spec lives in schema_definition for FIXED feeds.
    -- start positions are 1-indexed (matches mainframe conventions).
    '{
        "fields": [
            {"name": "account_id",   "start": 1,  "length": 12, "type": "string", "trim": true},
            {"name": "txn_date",     "start": 13, "length": 8,  "type": "date",   "format": "yyyyMMdd"},
            {"name": "txn_code",     "start": 21, "length": 4,  "type": "string", "trim": true},
            {"name": "amount",       "start": 25, "length": 15, "type": "decimal","scale": 2, "precision": 18},
            {"name": "currency",     "start": 40, "length": 3,  "type": "string", "trim": true},
            {"name": "description",  "start": 43, "length": 60, "type": "string", "trim": true}
        ]
    }',
    'INCREMENTAL',
    NULL,
    '0 0 3 * * ?',
    180,
    'finance-ops@example.com',
    TRUE
);
