"""
Quarantine drain — copies DLT-quarantined rows into error_log.

Project-scoped: each project's DLT pipeline writes its own quarantine
tables, and each project gets its own scheduled drain Job. Idempotent —
only copies quarantine rows whose ingest_run_id has not yet appeared in
error_log for that feed.
"""

from __future__ import annotations

import argparse
import logging
import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pyspark.sql import SparkSession


log = logging.getLogger(__name__)


def drain_one(
    spark: "SparkSession",
    project_id: int,
    feed_name: str,
    feed_id: int,
    silver_table_fqn: str,
) -> int:
    """
    Drain one feed's quarantine table.

    silver_table_fqn is the fully-qualified Silver table name; the
    quarantine table convention is `<silver_table_fqn>_quarantine`.

    Returns rows written to error_log.
    """
    from pyspark.sql.functions import to_json, struct
    from ingestion_framework.audit import ErrorService

    qtable = f"{silver_table_fqn}_quarantine"
    try:
        qdf = spark.table(qtable)
    except Exception:
        log.info("No quarantine table for feed=%s — skipping", feed_name)
        return 0

    if qdf.rdd.isEmpty():
        return 0

    error_table = ErrorService.DEFAULT_TABLE

    # Anti-join against already-logged rows for this feed
    already = (spark.table(error_table)
               .where(f"feed_id = {feed_id} AND error_type = 'DQ'")
               .select("run_id"))

    new_rows = qdf.join(
        already,
        qdf["_ingest_run_id"] == already["run_id"],
        how="leftanti",
    )
    if new_rows.rdd.isEmpty():
        return 0

    payload = (new_rows
               .withColumn("raw_record", to_json(struct(*[c for c in new_rows.columns])))
               .selectExpr(
                   f"CAST({int(project_id)} AS BIGINT) AS project_id",
                   "_ingest_run_id AS run_id",
                   f"CAST({int(feed_id)} AS BIGINT) AS feed_id",
                   "current_timestamp() AS error_ts",
                   "'DQ' AS error_type",
                   "'WARN' AS error_severity",
                   "raw_record",
                   "'silver_expectation' AS expectation_name",
                   "'Quarantined by DLT expectation' AS error_message",
                   "CAST(NULL AS STRING) AS stack_trace",
                   "FALSE AS resolved_flag",
                   "CAST(NULL AS TIMESTAMP) AS resolved_ts",
                   "CAST(NULL AS STRING) AS resolved_by",
               ))

    written = payload.count()
    payload.write.mode("append").saveAsTable(error_table)
    log.info("Drained %d rows from %s -> error_log", written, qtable)
    return written


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Drain DLT quarantine tables to error_log (project-scoped).",
    )
    parser.add_argument("--project", required=True,
                        help="project_code — only this project's feeds will be drained")
    parser.add_argument("--feed", default=None,
                        help="Optional single feed name (default: all active feeds in project)")
    parser.add_argument("--log-level", default="INFO")
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=getattr(logging, args.log_level.upper()),
        format="%(asctime)s %(levelname)-7s %(name)s — %(message)s",
    )

    from pyspark.sql import SparkSession
    from ingestion_framework.config import ConfigRepository

    spark = SparkSession.builder.getOrCreate()
    repo = ConfigRepository(spark)

    project = repo.get_project(args.project)
    if args.feed:
        feeds = [repo.get_feed(args.project, args.feed)]
    else:
        feeds = repo.list_active_feeds(project_code=args.project)

    total = 0
    for f in feeds:
        try:
            silver_fqn = project.silver_table_name(f.feed_name)
            total += drain_one(
                spark=spark,
                project_id=project.project_id,
                feed_name=f.feed_name,
                feed_id=f.feed_id,
                silver_table_fqn=silver_fqn,
            )
        except Exception:
            log.exception("Drain failed for feed=%s", f.feed_name)

    print(f"Drained {total} quarantine rows for project '{args.project}'")
    return 0


if __name__ == "__main__":
    sys.exit(main())
