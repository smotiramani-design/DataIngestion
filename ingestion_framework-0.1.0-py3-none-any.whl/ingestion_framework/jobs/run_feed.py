"""
Job entry point — run one feed within one project.

Designed to be used as the Python script for a Databricks Job:

    ingest-run-feed --project finance --feed orders_oracle

Or directly from a notebook:

    from ingestion_framework.jobs.run_feed import run
    run(project_code="finance", feed_name="orders_oracle", triggered_by="manual")
"""

from __future__ import annotations

import argparse
import logging
import sys


def run(project_code: str, feed_name: str, triggered_by: str = "manual") -> str:
    """Execute one feed and return its run_id."""
    from pyspark.sql import SparkSession
    from ingestion_framework.engine import IngestionEngine

    spark = SparkSession.builder.getOrCreate()
    engine = IngestionEngine(spark)
    return engine.run(
        project_code=project_code,
        feed_name=feed_name,
        triggered_by=triggered_by,
    )


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Run one ingestion feed.")
    parser.add_argument("--project", required=True,
                        help="project_code from the projects table")
    parser.add_argument("--feed", required=True,
                        help="feed_name from feed_config (within the given project)")
    parser.add_argument("--triggered-by", default="schedule",
                        choices=["schedule", "manual", "api"],
                        help="Who/what kicked off this run")
    parser.add_argument("--log-level", default="INFO")
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=getattr(logging, args.log_level.upper()),
        format="%(asctime)s %(levelname)-7s %(name)s — %(message)s",
    )

    try:
        run_id = run(
            project_code=args.project,
            feed_name=args.feed,
            triggered_by=args.triggered_by,
        )
        print(f"OK  project={args.project}  feed={args.feed}  run_id={run_id}")
        return 0
    except Exception as exc:
        print(f"FAIL project={args.project}  feed={args.feed}  error={exc}",
              file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
