"""
Run every active feed.

Typical use: a single orchestration Job that wakes on a cron, fans out across
all active feeds, and exits non-zero only if at least one failed.

Per-feed isolation: a failure in one feed does NOT stop the others — each is
run in its own thread, and the engine guarantees error_log + audit_log are
updated regardless.
"""

from __future__ import annotations

import argparse
import logging
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    from pyspark.sql import SparkSession
    from ingestion_framework.config import FeedConfig


log = logging.getLogger(__name__)


def _run_one(spark: "SparkSession", feed: "FeedConfig", triggered_by: str) -> Tuple[str, str, str]:
    """Returns (feed_name, status, run_id_or_error)."""
    from ingestion_framework.engine import IngestionEngine
    try:
        engine = IngestionEngine(spark)
        run_id = engine.run(feed_name=feed.feed_name, triggered_by=triggered_by)
        return (feed.feed_name, "SUCCESS", run_id)
    except Exception as exc:
        log.exception("Feed failed: %s", feed.feed_name)
        return (feed.feed_name, "FAILED", str(exc))


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Run all active feeds.")
    parser.add_argument("--source-type", default=None,
                        help="Optional filter: only feeds with this source_type")
    parser.add_argument("--max-parallel", type=int, default=4,
                        help="How many feeds to run concurrently")
    parser.add_argument("--triggered-by", default="schedule")
    parser.add_argument("--log-level", default="INFO")
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=getattr(logging, args.log_level.upper()),
        format="%(asctime)s %(levelname)-7s %(name)s — %(message)s",
    )

    # Deferred imports — keeps --help fast and pyspark-free.
    from pyspark.sql import SparkSession
    from ingestion_framework.config import ConfigRepository

    spark = SparkSession.builder.getOrCreate()
    repo = ConfigRepository(spark)
    feeds = repo.list_active(source_type=args.source_type)
    if not feeds:
        print("No active feeds found.", file=sys.stderr)
        return 0

    print(f"Running {len(feeds)} feeds (max parallel={args.max_parallel})")

    results: List[Tuple[str, str, str]] = []
    with ThreadPoolExecutor(max_workers=args.max_parallel) as pool:
        futures = [pool.submit(_run_one, spark, f, args.triggered_by) for f in feeds]
        for fut in as_completed(futures):
            results.append(fut.result())

    # Summary
    print("\n=== Summary ===")
    failed = 0
    for name, status, detail in sorted(results):
        marker = "✓" if status == "SUCCESS" else "✗"
        print(f"  {marker} {name:<30}  {status:<8}  {detail}")
        if status != "SUCCESS":
            failed += 1

    print(f"\n{len(results) - failed} succeeded, {failed} failed")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
