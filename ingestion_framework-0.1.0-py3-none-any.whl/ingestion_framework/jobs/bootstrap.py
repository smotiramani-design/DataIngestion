"""
Bootstrap — provisions the platform's control tables.

Runs the DDL shipped inside the wheel. Idempotent (CREATE TABLE IF NOT
EXISTS throughout), so safe to re-run after DDL changes.

Project rows are NOT created here — onboarding a new project is a
deliberate, governed action that goes through INSERT statements (typically
via the operator console's admin pane or a separate Asset Bundle target).
"""

from __future__ import annotations

from importlib.resources import files


def main() -> None:
    from pyspark.sql import SparkSession

    spark = SparkSession.builder.getOrCreate()

    # Load DDL from inside the installed wheel
    ddl_text = (files("ingestion_framework") / "sql" / "01_create_control_tables.sql").read_text()
    statements = _split_ddl(ddl_text)

    print(f"Executing {len(statements)} DDL statements...")
    for i, stmt in enumerate(statements, 1):
        preview = stmt.replace("\n", " ").strip()[:80]
        print(f"  [{i:2d}/{len(statements)}] {preview}...")
        spark.sql(stmt)

    print("Bootstrap complete. Next: insert at least one row into "
          "ingest_platform.control.projects before running any feeds.")


def _split_ddl(text: str) -> list[str]:
    """Split a multi-statement SQL file into executable chunks."""
    lines = [ln for ln in text.splitlines() if not ln.strip().startswith("--")]
    cleaned = "\n".join(lines)

    statements = []
    for raw in cleaned.split(";"):
        stmt = raw.strip()
        if stmt:
            statements.append(stmt)
    return statements


if __name__ == "__main__":
    main()
