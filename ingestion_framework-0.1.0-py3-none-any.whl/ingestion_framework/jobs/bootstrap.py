"""
Bootstrap notebook — provisions the ingestion framework's control tables.

Runs the DDL shipped inside the wheel (sql/01_create_control_tables.sql)
against the configured catalog. Idempotent — uses CREATE TABLE IF NOT EXISTS
throughout, so re-running on an existing deployment is safe.

Invoked by the `ingest_bootstrap` Job in resources/jobs.yml. Run once after
initial bundle deploy, then again only when the DDL changes.
"""

from importlib.resources import files


def main() -> None:
    # Deferred import — keeps installation/--help working without pyspark.
    from pyspark.sql import SparkSession

    spark = SparkSession.builder.getOrCreate()

    # Load DDL from inside the installed wheel
    ddl_text = (files("ingestion_framework") / "sql" / "01_create_control_tables.sql").read_text()

    # Strip line comments and split on `;` — Databricks SQL doesn't accept
    # multi-statement strings via spark.sql(), so we execute one at a time.
    statements = _split_ddl(ddl_text)

    print(f"Executing {len(statements)} DDL statements...")
    for i, stmt in enumerate(statements, 1):
        preview = stmt.replace("\n", " ").strip()[:80]
        print(f"  [{i:2d}/{len(statements)}] {preview}...")
        spark.sql(stmt)

    print("Bootstrap complete.")


def _split_ddl(text: str) -> list[str]:
    """Split a multi-statement SQL file into executable chunks."""
    # Drop full-line comments
    lines = [ln for ln in text.splitlines() if not ln.strip().startswith("--")]
    cleaned = "\n".join(lines)

    statements = []
    for raw in cleaned.split(";"):
        stmt = raw.strip()
        if stmt:
            statements.append(stmt)
    return statements


if __name__ == "__main__":
    main()
