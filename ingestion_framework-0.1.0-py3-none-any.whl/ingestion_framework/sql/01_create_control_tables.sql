-- =============================================================================
-- Data Ingestion Framework — Control Tables
-- =============================================================================
-- These three Delta tables are the operational backbone of the framework:
--   * feed_config — declarative definition of every feed (source of truth)
--   * audit_log   — one row per pipeline run (lineage + counts)
--   * error_log   — one row per quarantined / rejected record or exception
--
-- All tables live under a dedicated catalog/schema so RBAC can be granted
-- separately from data tables.
-- =============================================================================

CREATE CATALOG IF NOT EXISTS ingest_platform;
CREATE SCHEMA IF NOT EXISTS ingest_platform.control;

-- -----------------------------------------------------------------------------
-- feed_config
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ingest_platform.control.feed_config (
    feed_id              BIGINT GENERATED ALWAYS AS IDENTITY,
    feed_name            STRING  NOT NULL,
    source_type          STRING  NOT NULL,   -- API | RDBMS | JSON | EXCEL | CSV | DELIMITED | FIXED
    source_location      STRING  NOT NULL,   -- URL, JDBC string, ADLS / S3 path, or volume mount
    source_options       MAP<STRING, STRING>,-- auth, delimiter, sheet list, fixed-width spec, paging
    target_table         STRING  NOT NULL,   -- catalog.schema.table (Bronze)
    schema_definition    STRING,             -- JSON describing columns & types; for FIXED also positions
    load_mode            STRING  NOT NULL,   -- FULL | INCREMENTAL | CDC | UPSERT
    watermark_column     STRING,             -- column tracked for INCREMENTAL
    schedule_cron        STRING,             -- DLT pipeline schedule
    sla_minutes          INT,                -- freshness SLA — used for alerting
    owner                STRING  NOT NULL,
    is_active            BOOLEAN NOT NULL DEFAULT TRUE,
    created_ts           TIMESTAMP NOT NULL DEFAULT current_timestamp(),
    updated_ts           TIMESTAMP NOT NULL DEFAULT current_timestamp(),
    CONSTRAINT pk_feed_config PRIMARY KEY (feed_id),
    CONSTRAINT chk_source_type CHECK (source_type IN ('API','RDBMS','JSON','EXCEL','CSV','DELIMITED','FIXED')),
    CONSTRAINT chk_load_mode   CHECK (load_mode   IN ('FULL','INCREMENTAL','CDC','UPSERT'))
)
USING DELTA
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Unique business key (one row per feed_name)
CREATE INDEX IF NOT EXISTS idx_feed_config_name
    ON ingest_platform.control.feed_config (feed_name);

-- -----------------------------------------------------------------------------
-- audit_log — one row per pipeline run
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ingest_platform.control.audit_log (
    run_id                 STRING    NOT NULL,
    feed_id                BIGINT    NOT NULL,
    pipeline_id            STRING,
    start_ts               TIMESTAMP NOT NULL,
    end_ts                 TIMESTAMP,
    status                 STRING    NOT NULL,  -- RUNNING | SUCCESS | FAILED | PARTIAL
    source_record_count    BIGINT,
    bronze_count           BIGINT,
    silver_count           BIGINT,
    quarantine_count       BIGINT,
    reconciliation_status  STRING,              -- PASS | FAIL | NA
    duration_seconds       INT,
    triggered_by           STRING,              -- schedule | manual | api
    error_summary          STRING,
    CONSTRAINT pk_audit_log PRIMARY KEY (run_id),
    CONSTRAINT chk_audit_status CHECK (status IN ('RUNNING','SUCCESS','FAILED','PARTIAL'))
)
USING DELTA
PARTITIONED BY (feed_id)
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact'   = 'true'
);

-- -----------------------------------------------------------------------------
-- error_log — one row per quarantined / rejected record OR exception event
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ingest_platform.control.error_log (
    error_id           BIGINT GENERATED ALWAYS AS IDENTITY,
    run_id             STRING    NOT NULL,
    feed_id            BIGINT    NOT NULL,
    error_ts           TIMESTAMP NOT NULL,
    error_type         STRING    NOT NULL,   -- SCHEMA | DQ | CONNECTIVITY | RUNTIME | CONFIG
    error_severity     STRING    NOT NULL,   -- WARN | ERROR | FATAL
    raw_record         STRING,               -- full source row that failed
    expectation_name   STRING,               -- DLT rule that fired
    error_message      STRING,
    stack_trace        STRING,
    resolved_flag      BOOLEAN   NOT NULL DEFAULT FALSE,
    resolved_ts        TIMESTAMP,
    resolved_by        STRING,
    CONSTRAINT pk_error_log PRIMARY KEY (error_id),
    CONSTRAINT chk_error_type     CHECK (error_type     IN ('SCHEMA','DQ','CONNECTIVITY','RUNTIME','CONFIG')),
    CONSTRAINT chk_error_severity CHECK (error_severity IN ('WARN','ERROR','FATAL'))
)
USING DELTA
PARTITIONED BY (feed_id)
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact'   = 'true'
);

-- -----------------------------------------------------------------------------
-- Helpful views
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW ingest_platform.control.v_active_feeds AS
SELECT * FROM ingest_platform.control.feed_config WHERE is_active = TRUE;

CREATE OR REPLACE VIEW ingest_platform.control.v_recent_runs AS
SELECT a.*, f.feed_name, f.source_type, f.target_table
FROM   ingest_platform.control.audit_log a
JOIN   ingest_platform.control.feed_config f USING (feed_id)
WHERE  a.start_ts >= current_timestamp() - INTERVAL 7 DAYS
ORDER BY a.start_ts DESC;

CREATE OR REPLACE VIEW ingest_platform.control.v_open_errors AS
SELECT e.*, f.feed_name, f.target_table
FROM   ingest_platform.control.error_log e
JOIN   ingest_platform.control.feed_config f USING (feed_id)
WHERE  e.resolved_flag = FALSE;
