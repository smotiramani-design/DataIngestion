"""
Configuration model & repository.

`FeedConfig` is a typed snapshot of a single row in the `feed_config` Delta
table. `ConfigRepository` is the only place that reads/writes that table — the
rest of the framework receives a `FeedConfig` instance and never queries the
config table directly.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any

from pyspark.sql import SparkSession, Row


# ---------------------------------------------------------------------------
# Typed model
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class FeedConfig:
    """A single feed definition, mirroring the feed_config table."""

    feed_id: int
    feed_name: str
    source_type: str          # API | RDBMS | JSON | EXCEL | CSV | DELIMITED | FIXED
    source_location: str
    source_options: Dict[str, str]
    target_table: str
    schema_definition: Optional[str]
    load_mode: str            # FULL | INCREMENTAL | CDC | UPSERT
    watermark_column: Optional[str]
    schedule_cron: Optional[str]
    sla_minutes: Optional[int]
    owner: str
    is_active: bool

    # ------ convenience accessors --------------------------------------------
    def opt(self, key: str, default: Optional[str] = None) -> Optional[str]:
        """Read a value from source_options with a default."""
        if not self.source_options:
            return default
        return self.source_options.get(key, default)

    def opt_int(self, key: str, default: Optional[int] = None) -> Optional[int]:
        v = self.opt(key)
        return int(v) if v is not None else default

    def opt_bool(self, key: str, default: bool = False) -> bool:
        v = self.opt(key)
        if v is None:
            return default
        return v.lower() in ("true", "1", "yes", "y")

    def schema_json(self) -> Optional[Dict[str, Any]]:
        """Parse schema_definition as JSON, returning None if absent/blank."""
        if not self.schema_definition:
            return None
        return json.loads(self.schema_definition)

    @classmethod
    def from_row(cls, row: Row) -> "FeedConfig":
        d = row.asDict(recursive=True)
        return cls(
            feed_id=d["feed_id"],
            feed_name=d["feed_name"],
            source_type=d["source_type"],
            source_location=d["source_location"],
            source_options=dict(d.get("source_options") or {}),
            target_table=d["target_table"],
            schema_definition=d.get("schema_definition"),
            load_mode=d["load_mode"],
            watermark_column=d.get("watermark_column"),
            schedule_cron=d.get("schedule_cron"),
            sla_minutes=d.get("sla_minutes"),
            owner=d["owner"],
            is_active=bool(d["is_active"]),
        )


# ---------------------------------------------------------------------------
# Repository
# ---------------------------------------------------------------------------
class ConfigRepository:
    """Read access to the feed_config Delta table."""

    DEFAULT_TABLE = "ingest_platform.control.feed_config"

    def __init__(self, spark: SparkSession, table: str = DEFAULT_TABLE):
        self.spark = spark
        self.table = table

    # ------ lookups ----------------------------------------------------------
    def get_by_name(self, feed_name: str) -> FeedConfig:
        df = (self.spark.table(self.table)
              .where("feed_name = :n AND is_active = TRUE", {"n": feed_name}))
        rows = df.limit(2).collect()
        if not rows:
            raise LookupError(f"No active feed_config row for feed_name='{feed_name}'")
        if len(rows) > 1:
            raise ValueError(f"Ambiguous feed_config: more than one active row for '{feed_name}'")
        return FeedConfig.from_row(rows[0])

    def get_by_id(self, feed_id: int) -> FeedConfig:
        df = self.spark.table(self.table).where(f"feed_id = {int(feed_id)}")
        rows = df.limit(1).collect()
        if not rows:
            raise LookupError(f"No feed_config row for feed_id={feed_id}")
        return FeedConfig.from_row(rows[0])

    def list_active(self, source_type: Optional[str] = None) -> List[FeedConfig]:
        df = self.spark.table(self.table).where("is_active = TRUE")
        if source_type:
            df = df.where(f"source_type = '{source_type}'")
        return [FeedConfig.from_row(r) for r in df.collect()]
