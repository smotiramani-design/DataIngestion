"""
Configuration model & repository — multi-project edition.

Every operational lookup goes through a project, never globally. The
framework is shared infrastructure; one project's feed_config row is not
visible to another project's pipeline runs.

Rationale for project scoping at this layer:
  * Two projects can both have a feed named "customers" without colliding —
    feed_name is unique within a project, not globally.
  * The console / Job runner can filter by project without joining views.
  * If we later move to Unity Catalog row-level security, this is exactly
    the column the policies will key on.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Dict, List, Optional, Any

from pyspark.sql import SparkSession, Row


# ---------------------------------------------------------------------------
# Project — the new top-level entity
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Project:
    """A consuming project that owns 1..N feeds."""

    project_id: int
    project_code: str
    project_name: str
    description: Optional[str]
    default_catalog: str
    bronze_schema: str
    silver_schema: str
    gold_schema: str
    default_secret_scope: Optional[str]
    alert_email: str
    pagerduty_service: Optional[str]
    framework_version: str
    owner_team: str
    cost_center: Optional[str]
    is_active: bool

    def bronze_table_name(self, feed_name: str) -> str:
        """Default Bronze table location: <catalog>.<bronze_schema>.<feed_name>."""
        return f"{self.default_catalog}.{self.bronze_schema}.{feed_name}"

    def silver_table_name(self, feed_name: str) -> str:
        return f"{self.default_catalog}.{self.silver_schema}.silver_{feed_name}"

    def gold_table_name(self, feed_name: str) -> str:
        return f"{self.default_catalog}.{self.gold_schema}.gold_{feed_name}"

    @classmethod
    def from_row(cls, row: Row) -> "Project":
        d = row.asDict(recursive=True)
        return cls(
            project_id=d["project_id"],
            project_code=d["project_code"],
            project_name=d["project_name"],
            description=d.get("description"),
            default_catalog=d["default_catalog"],
            bronze_schema=d["bronze_schema"],
            silver_schema=d["silver_schema"],
            gold_schema=d["gold_schema"],
            default_secret_scope=d.get("default_secret_scope"),
            alert_email=d["alert_email"],
            pagerduty_service=d.get("pagerduty_service"),
            framework_version=d["framework_version"],
            owner_team=d["owner_team"],
            cost_center=d.get("cost_center"),
            is_active=bool(d["is_active"]),
        )


# ---------------------------------------------------------------------------
# Feed config — now project-scoped
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class FeedConfig:
    """A single feed definition, mirroring the feed_config table."""

    feed_id: int
    project_id: int                # NEW — owning project
    feed_name: str
    source_type: str
    source_location: str
    source_options: Dict[str, str]
    target_table: Optional[str]    # NEW — nullable; falls back to project default
    schema_definition: Optional[str]
    load_mode: str
    watermark_column: Optional[str]
    schedule_cron: Optional[str]
    sla_minutes: Optional[int]
    owner: str
    is_active: bool

    # ------ option helpers (unchanged) ---------------------------------------
    def opt(self, key: str, default: Optional[str] = None) -> Optional[str]:
        if not self.source_options:
            return default
        return self.source_options.get(key, default)

    def opt_int(self, key: str, default: Optional[int] = None) -> Optional[int]:
        v = self.opt(key)
        return int(v) if v is not None else default

    def opt_bool(self, key: str, default: bool = False) -> bool:
        v = self.opt(key)
        if v is None:
            return default
        return v.lower() in ("true", "1", "yes", "y")

    def schema_json(self) -> Optional[Dict[str, Any]]:
        if not self.schema_definition:
            return None
        return json.loads(self.schema_definition)

    # ------ resolve the effective target table ------------------------------
    def resolved_target_table(self, project: Project) -> str:
        """
        Return the fully-qualified Bronze table name.

        If the feed_config row has an explicit target_table, use it. Otherwise
        derive from the owning project's default catalog + bronze schema.
        This keeps day-to-day onboarding minimal — operators rarely override.
        """
        if self.target_table:
            return self.target_table
        return project.bronze_table_name(self.feed_name)

    @classmethod
    def from_row(cls, row: Row) -> "FeedConfig":
        d = row.asDict(recursive=True)
        return cls(
            feed_id=d["feed_id"],
            project_id=d["project_id"],
            feed_name=d["feed_name"],
            source_type=d["source_type"],
            source_location=d["source_location"],
            source_options=dict(d.get("source_options") or {}),
            target_table=d.get("target_table"),
            schema_definition=d.get("schema_definition"),
            load_mode=d["load_mode"],
            watermark_column=d.get("watermark_column"),
            schedule_cron=d.get("schedule_cron"),
            sla_minutes=d.get("sla_minutes"),
            owner=d["owner"],
            is_active=bool(d["is_active"]),
        )


# ---------------------------------------------------------------------------
# Repository — every lookup is project-scoped
# ---------------------------------------------------------------------------
class ConfigRepository:
    """Read access to projects + feed_config Delta tables."""

    DEFAULT_PROJECT_TABLE = "ingest_platform.control.projects"
    DEFAULT_FEED_TABLE = "ingest_platform.control.feed_config"

    def __init__(
        self,
        spark: SparkSession,
        project_table: str = DEFAULT_PROJECT_TABLE,
        feed_table: str = DEFAULT_FEED_TABLE,
    ):
        self.spark = spark
        self.project_table = project_table
        self.feed_table = feed_table

    # ------ projects ---------------------------------------------------------
    def get_project(self, project_code: str) -> Project:
        """Look up a project by its short code (e.g. 'finance')."""
        rows = (self.spark.table(self.project_table)
                .where("project_code = :c AND is_active = TRUE", {"c": project_code})
                .limit(2).collect())
        if not rows:
            raise LookupError(f"No active project with code='{project_code}'")
        if len(rows) > 1:
            raise ValueError(f"Multiple active rows for project_code='{project_code}'")
        return Project.from_row(rows[0])

    def get_project_by_id(self, project_id: int) -> Project:
        rows = (self.spark.table(self.project_table)
                .where(f"project_id = {int(project_id)}").limit(1).collect())
        if not rows:
            raise LookupError(f"No project with project_id={project_id}")
        return Project.from_row(rows[0])

    def list_projects(self, active_only: bool = True) -> List[Project]:
        df = self.spark.table(self.project_table)
        if active_only:
            df = df.where("is_active = TRUE")
        return [Project.from_row(r) for r in df.collect()]

    # ------ feeds (always project-scoped) -----------------------------------
    def get_feed(self, project_code: str, feed_name: str) -> FeedConfig:
        """
        Look up a feed by (project_code, feed_name). Both are required —
        feed_name alone is ambiguous because the same name may exist in
        multiple projects.
        """
        project = self.get_project(project_code)
        rows = (self.spark.table(self.feed_table)
                .where("project_id = :pid AND feed_name = :n AND is_active = TRUE",
                       {"pid": project.project_id, "n": feed_name})
                .limit(2).collect())
        if not rows:
            raise LookupError(
                f"No active feed '{feed_name}' in project '{project_code}'"
            )
        if len(rows) > 1:
            raise ValueError(
                f"Ambiguous feed_config: multiple active rows for "
                f"({project_code}, {feed_name})"
            )
        return FeedConfig.from_row(rows[0])

    def list_active_feeds(
        self,
        project_code: Optional[str] = None,
        source_type: Optional[str] = None,
    ) -> List[FeedConfig]:
        """
        List active feeds. If project_code is given, scope to that project
        only — this is the typical path. Without it, returns feeds across
        all projects (used by the platform-admin "all projects" view).
        """
        df = self.spark.table(self.feed_table).where("is_active = TRUE")
        if project_code is not None:
            project = self.get_project(project_code)
            df = df.where(f"project_id = {project.project_id}")
        if source_type:
            df = df.where(f"source_type = '{source_type}'")
        return [FeedConfig.from_row(r) for r in df.collect()]
