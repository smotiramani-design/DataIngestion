"""
Audit and Error services.

Every pipeline run writes:
  * exactly one row to audit_log (start → update on completion)
  * 0..N rows to error_log (one per quarantined record OR exception event)

These services are the *only* code path that mutates the control tables.
"""

from __future__ import annotations

import traceback
from datetime import datetime
from typing import Optional, Iterable, Dict, Any

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType, IntegerType,
    TimestampType, BooleanType,
)
from pyspark.sql.functions import lit, current_timestamp


# =============================================================================
# Audit
# =============================================================================
class AuditService:
    """Manages audit_log rows for each pipeline run."""

    DEFAULT_TABLE = "ingest_platform.control.audit_log"

    _SCHEMA = StructType([
        StructField("run_id",                StringType(),    False),
        StructField("feed_id",               LongType(),      False),
        StructField("pipeline_id",           StringType(),    True),
        StructField("start_ts",              TimestampType(), False),
        StructField("end_ts",                TimestampType(), True),
        StructField("status",                StringType(),    False),
        StructField("source_record_count",   LongType(),      True),
        StructField("bronze_count",          LongType(),      True),
        StructField("silver_count",          LongType(),      True),
        StructField("quarantine_count",      LongType(),      True),
        StructField("reconciliation_status", StringType(),    True),
        StructField("duration_seconds",      IntegerType(),   True),
        StructField("triggered_by",          StringType(),    True),
        StructField("error_summary",         StringType(),    True),
    ])

    def __init__(self, spark: SparkSession, table: str = DEFAULT_TABLE):
        self.spark = spark
        self.table = table

    # ------ lifecycle --------------------------------------------------------
    def start_run(
        self,
        run_id: str,
        feed_id: int,
        pipeline_id: Optional[str] = None,
        triggered_by: str = "schedule",
    ) -> None:
        """Insert the initial RUNNING row."""
        row = [(
            run_id, feed_id, pipeline_id, datetime.utcnow(), None,
            "RUNNING", None, None, None, None, None, None, triggered_by, None,
        )]
        df = self.spark.createDataFrame(row, schema=self._SCHEMA)
        df.write.mode("append").saveAsTable(self.table)

    def complete_run(
        self,
        run_id: str,
        status: str,
        source_count: Optional[int] = None,
        bronze_count: Optional[int] = None,
        silver_count: Optional[int] = None,
        quarantine_count: Optional[int] = None,
        reconciliation_status: Optional[str] = None,
        error_summary: Optional[str] = None,
    ) -> None:
        """MERGE the final state of the run."""
        if status not in ("SUCCESS", "FAILED", "PARTIAL"):
            raise ValueError(f"Invalid terminal status: {status}")

        # Build the SET clause dynamically — only update fields we have values for.
        # We always set end_ts, status, and duration_seconds.
        sets = [
            "t.end_ts = current_timestamp()",
            f"t.status = '{status}'",
            "t.duration_seconds = CAST(unix_timestamp(current_timestamp()) - unix_timestamp(t.start_ts) AS INT)",
        ]
        if source_count is not None:      sets.append(f"t.source_record_count = {int(source_count)}")
        if bronze_count is not None:      sets.append(f"t.bronze_count = {int(bronze_count)}")
        if silver_count is not None:      sets.append(f"t.silver_count = {int(silver_count)}")
        if quarantine_count is not None:  sets.append(f"t.quarantine_count = {int(quarantine_count)}")
        if reconciliation_status:         sets.append(f"t.reconciliation_status = '{reconciliation_status}'")
        if error_summary:
            safe = error_summary.replace("'", "''")[:4000]
            sets.append(f"t.error_summary = '{safe}'")

        sql = f"""
            UPDATE {self.table} AS t
            SET    {', '.join(sets)}
            WHERE  t.run_id = '{run_id}'
        """
        self.spark.sql(sql)


# =============================================================================
# Errors
# =============================================================================
class ErrorService:
    """Writes rows to error_log."""

    DEFAULT_TABLE = "ingest_platform.control.error_log"

    _SCHEMA = StructType([
        StructField("run_id",           StringType(),    False),
        StructField("feed_id",          LongType(),      False),
        StructField("error_ts",         TimestampType(), False),
        StructField("error_type",       StringType(),    False),
        StructField("error_severity",   StringType(),    False),
        StructField("raw_record",       StringType(),    True),
        StructField("expectation_name", StringType(),    True),
        StructField("error_message",    StringType(),    True),
        StructField("stack_trace",      StringType(),    True),
        StructField("resolved_flag",    BooleanType(),   False),
        StructField("resolved_ts",      TimestampType(), True),
        StructField("resolved_by",      StringType(),    True),
    ])

    def __init__(self, spark: SparkSession, table: str = DEFAULT_TABLE):
        self.spark = spark
        self.table = table

    # ------ single error -----------------------------------------------------
    def log_exception(
        self,
        run_id: str,
        feed_id: int,
        error_type: str,
        severity: str,
        message: str,
        exc: Optional[BaseException] = None,
        raw_record: Optional[str] = None,
    ) -> None:
        """Log a single exception or framework-level error."""
        stack = ""
        if exc is not None:
            stack = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        row = [(
            run_id, feed_id, datetime.utcnow(), error_type, severity,
            raw_record, None, message[:4000], stack[:8000], False, None, None,
        )]
        df = self.spark.createDataFrame(row, schema=self._SCHEMA)
        df.write.mode("append").saveAsTable(self.table)

    # ------ batch (quarantined records) --------------------------------------
    def log_quarantined_records(
        self,
        run_id: str,
        feed_id: int,
        quarantine_df: DataFrame,
        expectation_name: str,
    ) -> int:
        """
        Persist quarantined records (one per row in quarantine_df) to error_log.
        Returns the count written.
        """
        if quarantine_df.rdd.isEmpty():
            return 0

        cnt = quarantine_df.count()
        # Serialize each row to JSON for raw_record
        from pyspark.sql.functions import to_json, struct
        enriched = (quarantine_df
                    .withColumn("raw_record", to_json(struct([quarantine_df[c] for c in quarantine_df.columns])))
                    .selectExpr(
                        f"'{run_id}' AS run_id",
                        f"CAST({int(feed_id)} AS BIGINT) AS feed_id",
                        "current_timestamp() AS error_ts",
                        "'DQ' AS error_type",
                        "'WARN' AS error_severity",
                        "raw_record",
                        f"'{expectation_name}' AS expectation_name",
                        f"'Failed expectation: {expectation_name}' AS error_message",
                        "CAST(NULL AS STRING) AS stack_trace",
                        "FALSE AS resolved_flag",
                        "CAST(NULL AS TIMESTAMP) AS resolved_ts",
                        "CAST(NULL AS STRING) AS resolved_by",
                    ))
        enriched.write.mode("append").saveAsTable(self.table)
        return cnt
