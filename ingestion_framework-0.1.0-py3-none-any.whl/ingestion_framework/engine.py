"""
Ingestion engine — the orchestrator (multi-project edition).

Every run is bound to a (project_code, feed_name) pair. The engine:

  1. Looks up the Project (catalog, schemas, alert routing, framework version)
  2. Looks up the FeedConfig within that project
  3. Opens an audit_log row stamped with project_id + framework_version
  4. Resolves the effective Bronze target table from project defaults
  5. For INCREMENTAL feeds, reads the prior watermark from Bronze
  6. Builds the right Connector and calls read()
  7. Stamps every Bronze row with ingestion metadata (run_id, project, feed)
  8. Appends to Bronze (never drops a record)
  9. Reconciles source vs Bronze counts when the connector supports it
 10. Closes the audit_log row with terminal status + counts
 11. On any exception, writes to error_log and marks the run FAILED

The engine is the only place that decides what "success" means, which
metadata columns Bronze gets, and how exceptions translate to error_log
rows. Connectors stay focused on reading their source faithfully.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from typing import Optional

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import current_timestamp, lit, input_file_name

from ingestion_framework import __version__ as FRAMEWORK_VERSION
from ingestion_framework.config import FeedConfig, Project, ConfigRepository
from ingestion_framework.audit import AuditService, ErrorService
from ingestion_framework.connectors import get_connector


log = logging.getLogger(__name__)


class IngestionEngine:
    """Orchestrates a single feed's run, scoped to one project."""

    def __init__(
        self,
        spark: SparkSession,
        config_repo: Optional[ConfigRepository] = None,
        audit: Optional[AuditService] = None,
        errors: Optional[ErrorService] = None,
    ):
        self.spark = spark
        self.config_repo = config_repo or ConfigRepository(spark)
        self.audit = audit or AuditService(spark)
        self.errors = errors or ErrorService(spark)

    # ------------------------------------------------------------------ public
    def run(
        self,
        project_code: str,
        feed_name: str,
        triggered_by: str = "manual",
    ) -> str:
        """
        Execute one ingestion run for (project_code, feed_name).

        Returns the run_id. Always finalizes audit/error logs, even on
        failure. Re-raises the underlying exception after logging so callers
        can decide policy (e.g. fail the Job vs continue with other feeds).
        """
        run_id = self._new_run_id()
        project: Optional[Project] = None
        cfg: Optional[FeedConfig] = None

        # Stage 1 — resolve project + feed config (these errors can't be
        # written to audit_log because we don't have a project_id yet).
        try:
            project = self.config_repo.get_project(project_code)
            cfg = self.config_repo.get_feed(project_code, feed_name)
        except Exception as exc:
            self.errors.log_exception(
                run_id=run_id,
                project_id=project.project_id if project else 0,
                feed_id=cfg.feed_id if cfg else 0,
                error_type="CONFIG",
                severity="FATAL",
                message=f"Could not resolve config for ({project_code}, {feed_name}): {exc}",
                exc=exc,
            )
            raise

        # Stage 2 — open the audit row and execute.
        self.audit.start_run(
            run_id=run_id,
            project_id=project.project_id,
            feed_id=cfg.feed_id,
            framework_version=FRAMEWORK_VERSION,
            triggered_by=triggered_by,
        )

        try:
            self._execute_run(run_id, project, cfg)
            return run_id
        except Exception as exc:
            log.exception(
                "Ingestion failed: project=%s feed=%s run_id=%s",
                project_code, feed_name, run_id,
            )
            self.errors.log_exception(
                run_id=run_id,
                project_id=project.project_id,
                feed_id=cfg.feed_id,
                error_type=self._classify_error(exc),
                severity="ERROR",
                message=str(exc),
                exc=exc,
            )
            self.audit.complete_run(
                run_id=run_id,
                status="FAILED",
                error_summary=str(exc)[:4000],
            )
            raise

    # ----------------------------------------------------------------- internal
    def _execute_run(self, run_id: str, project: Project, cfg: FeedConfig) -> None:
        """Happy-path run: source read → Bronze write → reconcile."""

        # -- Resolve effective target table (from feed override or project default)
        target_table = cfg.resolved_target_table(project)

        # -- Build connector
        connector_cls = get_connector(cfg.source_type)
        connector = connector_cls(self.spark, cfg)

        # -- Resolve incremental watermark, if applicable
        if cfg.load_mode == "INCREMENTAL" and cfg.watermark_column:
            wm = self._resolve_watermark(cfg, target_table)
            if hasattr(connector, "last_watermark"):
                connector.last_watermark = wm

        # -- Pre-flight expected count (optional; only some connectors support)
        expected = connector.expected_count()

        # -- Read source
        src_df = connector.read()

        # -- Add ingestion metadata
        bronze_df = self._with_ingest_metadata(
            src_df, run_id=run_id, project=project, cfg=cfg,
        )

        # -- Write Bronze (append-only; preserves every record)
        bronze_count = self._write_bronze(bronze_df, target_table)

        # -- Reconcile
        recon_status: Optional[str] = None
        if expected is not None:
            recon_status = "PASS" if bronze_count == expected else "FAIL"
            if recon_status == "FAIL":
                self.errors.log_exception(
                    run_id=run_id,
                    project_id=project.project_id,
                    feed_id=cfg.feed_id,
                    error_type="RUNTIME",
                    severity="ERROR",
                    message=f"Reconciliation FAIL: source={expected}, bronze={bronze_count}",
                )

        # -- Close audit
        terminal_status = "PARTIAL" if recon_status == "FAIL" else "SUCCESS"
        self.audit.complete_run(
            run_id=run_id,
            status=terminal_status,
            source_count=expected,
            bronze_count=bronze_count,
            reconciliation_status=recon_status or "NA",
        )

    # ----------------------------------------------------------------- helpers
    @staticmethod
    def _new_run_id() -> str:
        # Sortable run IDs help when scanning audit_log
        return datetime.utcnow().strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:8]

    def _with_ingest_metadata(
        self, df: DataFrame, run_id: str, project: Project, cfg: FeedConfig,
    ) -> DataFrame:
        """Stamp every row with metadata Bronze needs for lineage & replay."""
        out = (df
               .withColumn("_ingest_run_id",         lit(run_id))
               .withColumn("_ingest_project_id",     lit(project.project_id))
               .withColumn("_ingest_project_code",   lit(project.project_code))
               .withColumn("_ingest_feed_id",        lit(cfg.feed_id))
               .withColumn("_ingest_feed_name",      lit(cfg.feed_name))
               .withColumn("_ingest_source_type",    lit(cfg.source_type))
               .withColumn("_ingest_framework_ver",  lit(FRAMEWORK_VERSION))
               .withColumn("_ingest_ts",             current_timestamp()))
        # input_file_name() works for file-based sources; harmless otherwise
        try:
            out = out.withColumn("_ingest_source_file", input_file_name())
        except Exception:
            pass
        return out

    def _write_bronze(self, df: DataFrame, target_table: str) -> int:
        """Append to the Bronze Delta table. Returns row count written."""
        writer = (df.write
                  .format("delta")
                  .mode("append")
                  .option("mergeSchema", "true"))
        writer.saveAsTable(target_table)
        # We can't read back the count cheaply from append, so count the input.
        # For very large feeds this triggers re-evaluation; consider caching.
        return df.count()

    def _resolve_watermark(
        self, cfg: FeedConfig, target_table: str,
    ) -> Optional[str]:
        """Return MAX(watermark_column) from the existing Bronze table, or None."""
        try:
            df = self.spark.table(target_table)
        except Exception:
            return None  # First run — table doesn't exist yet
        if cfg.watermark_column not in df.columns:
            return None
        row = df.selectExpr(f"MAX({cfg.watermark_column}) AS wm").collect()
        if not row or row[0]["wm"] is None:
            return None
        return str(row[0]["wm"])

    @staticmethod
    def _classify_error(exc: BaseException) -> str:
        """Best-effort mapping of exception type to error_log.error_type."""
        name = type(exc).__name__.lower()
        msg = str(exc).lower()
        if any(k in name + msg for k in ("connection", "timeout", "auth", "http", "jdbc")):
            return "CONNECTIVITY"
        if "schema" in msg or "AnalysisException" in name:
            return "SCHEMA"
        if isinstance(exc, (LookupError, ValueError)):
            return "CONFIG"
        return "RUNTIME"
