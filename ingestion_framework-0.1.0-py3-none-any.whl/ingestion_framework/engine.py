"""
Ingestion engine — the orchestrator.

Responsibility flow per run:

  1. Open audit_log row (status=RUNNING)
  2. Look up FeedConfig
  3. For INCREMENTAL feeds, resolve the prior watermark
  4. Build the right Connector and call read()
  5. Add ingestion metadata columns
  6. Write to the Bronze Delta table (append-only — never drops a record)
  7. Reconcile counts (source -> bronze) when the connector supports it
  8. Update the audit_log row with final counts and status
  9. On any exception, record FATAL/ERROR in error_log and mark FAILED

The engine is the *only* place that decides:
  - what 'success' means (status transitions)
  - which metadata columns Bronze gets
  - how exceptions translate to error_log rows

Connectors stay focused on reading their source faithfully.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from typing import Optional

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import current_timestamp, lit, input_file_name

from ingestion_framework.config import FeedConfig, ConfigRepository
from ingestion_framework.audit import AuditService, ErrorService
from ingestion_framework.connectors import get_connector
from ingestion_framework.connectors.rdbms_connector import RdbmsConnector


log = logging.getLogger(__name__)


class IngestionEngine:
    """Orchestrates a single feed's run from source to Bronze."""

    def __init__(
        self,
        spark: SparkSession,
        config_repo: Optional[ConfigRepository] = None,
        audit: Optional[AuditService] = None,
        errors: Optional[ErrorService] = None,
    ):
        self.spark = spark
        self.config_repo = config_repo or ConfigRepository(spark)
        self.audit = audit or AuditService(spark)
        self.errors = errors or ErrorService(spark)

    # ------------------------------------------------------------------ public
    def run(self, feed_name: str, triggered_by: str = "manual") -> str:
        """
        Execute one ingestion run for `feed_name`.
        Returns the run_id. Always finalizes audit/error logs, even on failure.
        """
        run_id = self._new_run_id()
        cfg: Optional[FeedConfig] = None

        try:
            cfg = self.config_repo.get_by_name(feed_name)
        except Exception as exc:
            # We can't open audit_log without feed_id, so log as a CONFIG error
            # against feed_id=0 (sentinel for un-resolvable feeds).
            self.errors.log_exception(
                run_id=run_id, feed_id=0,
                error_type="CONFIG", severity="FATAL",
                message=f"Could not load config for feed_name='{feed_name}': {exc}",
                exc=exc,
            )
            raise

        # Open audit row
        self.audit.start_run(
            run_id=run_id, feed_id=cfg.feed_id,
            pipeline_id=None, triggered_by=triggered_by,
        )

        try:
            self._execute_run(run_id, cfg)
            return run_id
        except Exception as exc:
            log.exception("Ingestion failed for feed=%s run_id=%s", feed_name, run_id)
            self.errors.log_exception(
                run_id=run_id, feed_id=cfg.feed_id,
                error_type=self._classify_error(exc),
                severity="ERROR",
                message=str(exc),
                exc=exc,
            )
            self.audit.complete_run(
                run_id=run_id, status="FAILED",
                error_summary=str(exc)[:4000],
            )
            raise

    # ----------------------------------------------------------------- internal
    def _execute_run(self, run_id: str, cfg: FeedConfig) -> None:
        """The happy-path run — source read, Bronze write, reconcile."""
        # -- Build connector
        connector_cls = get_connector(cfg.source_type)
        connector = connector_cls(self.spark, cfg)

        # -- Resolve incremental watermark, if applicable
        if cfg.load_mode == "INCREMENTAL" and cfg.watermark_column:
            wm = self._resolve_watermark(cfg)
            if hasattr(connector, "last_watermark"):
                connector.last_watermark = wm

        # -- Pre-flight expected count (optional; only some connectors support)
        expected = connector.expected_count()

        # -- Read source
        src_df = connector.read()

        # -- Add ingestion metadata
        bronze_df = self._with_ingest_metadata(src_df, run_id=run_id, cfg=cfg)

        # -- Write Bronze (append-only; preserves every record)
        bronze_count = self._write_bronze(bronze_df, cfg)

        # -- Reconcile
        recon_status: Optional[str] = None
        if expected is not None:
            recon_status = "PASS" if bronze_count == expected else "FAIL"
            if recon_status == "FAIL":
                self.errors.log_exception(
                    run_id=run_id, feed_id=cfg.feed_id,
                    error_type="RUNTIME", severity="ERROR",
                    message=f"Reconciliation FAIL: source={expected}, bronze={bronze_count}",
                )

        # -- Close audit
        terminal_status = "PARTIAL" if recon_status == "FAIL" else "SUCCESS"
        self.audit.complete_run(
            run_id=run_id,
            status=terminal_status,
            source_count=expected,
            bronze_count=bronze_count,
            reconciliation_status=recon_status or "NA",
        )

    # ----------------------------------------------------------------- helpers
    @staticmethod
    def _new_run_id() -> str:
        # Sortable run IDs help when scanning audit_log
        return datetime.utcnow().strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:8]

    def _with_ingest_metadata(self, df: DataFrame, run_id: str, cfg: FeedConfig) -> DataFrame:
        """Stamp every row with the metadata Bronze needs for lineage & replay."""
        out = (df
               .withColumn("_ingest_run_id",     lit(run_id))
               .withColumn("_ingest_feed_id",    lit(cfg.feed_id))
               .withColumn("_ingest_feed_name",  lit(cfg.feed_name))
               .withColumn("_ingest_source_type", lit(cfg.source_type))
               .withColumn("_ingest_ts",         current_timestamp()))
        # input_file_name() works for file-based sources; harmless otherwise
        try:
            out = out.withColumn("_ingest_source_file", input_file_name())
        except Exception:
            pass
        return out

    def _write_bronze(self, df: DataFrame, cfg: FeedConfig) -> int:
        """Append to the Bronze Delta table. Returns row count written."""
        # Schema evolution is safer than failing — new columns flow through.
        writer = (df.write
                  .format("delta")
                  .mode("append")
                  .option("mergeSchema", "true"))
        writer.saveAsTable(cfg.target_table)
        # We can't read back the count cheaply from append, so count the input.
        # For very large feeds this triggers re-evaluation; consider caching.
        return df.count()

    def _resolve_watermark(self, cfg: FeedConfig) -> Optional[str]:
        """Return MAX(watermark_column) from the existing Bronze table, or None."""
        try:
            df = self.spark.table(cfg.target_table)
        except Exception:
            return None  # First run — table doesn't exist yet
        if cfg.watermark_column not in df.columns:
            return None
        row = df.selectExpr(f"MAX({cfg.watermark_column}) AS wm").collect()
        if not row or row[0]["wm"] is None:
            return None
        return str(row[0]["wm"])

    @staticmethod
    def _classify_error(exc: BaseException) -> str:
        """Best-effort mapping of exception type to error_log.error_type."""
        name = type(exc).__name__.lower()
        msg = str(exc).lower()
        if any(k in name + msg for k in ("connection", "timeout", "auth", "http", "jdbc")):
            return "CONNECTIVITY"
        if "schema" in msg or "AnalysisException" in name:
            return "SCHEMA"
        if isinstance(exc, (LookupError, ValueError)):
            return "CONFIG"
        return "RUNTIME"
