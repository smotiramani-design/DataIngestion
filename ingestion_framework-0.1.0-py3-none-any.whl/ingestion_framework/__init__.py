"""
Data Ingestion Framework
========================

A configuration-driven, source-agnostic ingestion framework for Databricks +
Delta Lake. Public entry points are exposed lazily so that importing this
package doesn't require pyspark to be installed (Databricks runtimes provide
pyspark separately).
"""

__version__ = "0.1.0"

# We avoid eager imports of submodules that depend on pyspark. Users can do:
#
#   from ingestion_framework.config import FeedConfig
#   from ingestion_framework.engine import IngestionEngine
#
# and the modules will pull pyspark in only when actually needed.

__all__ = [
    "__version__",
]
