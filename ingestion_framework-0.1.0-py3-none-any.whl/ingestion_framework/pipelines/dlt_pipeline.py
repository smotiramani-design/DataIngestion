"""
Delta Live Tables pipeline — config-driven Bronze → Silver → Gold,
scoped to a single project.

Each project has its own DLT pipeline. The pipeline reads
spark.conf.get('ingest.project_code') to know which project's feeds to
declare. This gives us:

  * Independent DLT lifecycles — start/stop/full-refresh per project
  * Independent compute attribution — Photon billing rolls up by project
  * Independent failure blast-radius
  * Independent target catalog (each project lands tables in its own catalog)

Tables declared, per active feed in the project:
  silver_<feed>           — typed, deduped, with @expect_or_quarantine
  silver_<feed>_quarantine — DLT-managed quarantine sink (drained to error_log
                              by the drain_quarantine Job)
  gold_<feed>             — business view (default: latest snapshot of Silver;
                              override per-feed via source_options['gold_sql'])

Bronze is populated by the IngestionEngine (run_feed / run_all_feeds Job),
not by DLT. DLT only handles Silver and Gold.

Usage in Asset Bundle:

    pipelines:
      ingest_dlt_pipeline_finance:
        ...
        configuration:
          ingest.project_code: finance
        libraries:
          - notebook:
              path: .../dlt_pipeline.py
"""

from __future__ import annotations

# These imports only succeed inside a DLT pipeline runtime. Stub-friendly try.
try:
    import dlt
except ImportError:  # local lint only
    class _DltStub:
        def table(self, **kw):     return lambda f: f
        def view(self, **kw):      return lambda f: f
        def expect(self, *a, **k): return lambda f: f
        def expect_all_or_drop(self, *a, **k):       return lambda f: f
        def expect_all_or_quarantine(self, *a, **k): return lambda f: f
        def expect_all_or_fail(self, *a, **k):       return lambda f: f
        def read(self, *a, **k):        raise RuntimeError("DLT runtime only")
        def read_stream(self, *a, **k): raise RuntimeError("DLT runtime only")
    dlt = _DltStub()

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, row_number
from pyspark.sql.window import Window

from ingestion_framework.config import ConfigRepository, FeedConfig, Project


spark = SparkSession.builder.getOrCreate()

# ---------------------------------------------------------------------------
# Pipeline binds to ONE project — must be supplied via Spark conf.
# In the Asset Bundle this is set in the pipeline's `configuration:` block.
# ---------------------------------------------------------------------------
PROJECT_CODE = spark.conf.get("ingest.project_code", "")
if not PROJECT_CODE:
    raise RuntimeError(
        "ingest.project_code must be set in the pipeline configuration "
        "(or via spark.conf.set('ingest.project_code', '<code>')) before "
        "this pipeline can declare any tables."
    )

_repo = ConfigRepository(spark)
_project: Project = _repo.get_project(PROJECT_CODE)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _silver_expectations(cfg: FeedConfig) -> dict:
    """
    Build the dict of expectations passed to @dlt.expect_all_or_quarantine.
    Pulls from source_options['expectations'] if present (JSON map of
    name -> SQL predicate); otherwise sensible defaults.
    """
    import json as _json
    raw = cfg.opt("expectations")
    if raw:
        return _json.loads(raw)
    # Default — at least require non-null _ingest_run_id
    return {
        "non_null_ingest_run_id": "_ingest_run_id IS NOT NULL",
    }


def _silver_dedupe(df: DataFrame, cfg: FeedConfig) -> DataFrame:
    """Dedup by business key when configured; otherwise pass through."""
    bkey = cfg.opt("business_key")
    if not bkey:
        return df
    keys = [k.strip() for k in bkey.split(",")]
    order = cfg.opt("dedupe_order", "_ingest_ts DESC")

    order_cols = []
    for parts in order.split(","):
        parts = parts.strip()
        col_name = parts.split()[0]
        if "DESC" in parts.upper():
            order_cols.append(col(col_name).desc())
        else:
            order_cols.append(col(col_name).asc())

    w = Window.partitionBy(*keys).orderBy(*order_cols)
    return (df.withColumn("_rn", row_number().over(w))
              .where("_rn = 1")
              .drop("_rn"))


# ---------------------------------------------------------------------------
# Per-feed table generation
# ---------------------------------------------------------------------------
def _declare_feed(cfg: FeedConfig) -> None:
    """Register Bronze (as source), Silver, and Gold tables for one feed."""

    feed = cfg.feed_name
    bronze_table = cfg.resolved_target_table(_project)

    # ---------------- BRONZE (read-through) ---------------------------------
    @dlt.table(
        name=f"bronze_{feed}_view",
        comment=f"[{_project.project_code}] Bronze passthrough for {feed} (from {bronze_table})",
    )
    def _bronze():
        return dlt.read_stream(bronze_table)

    # ---------------- SILVER ------------------------------------------------
    expectations = _silver_expectations(cfg)

    @dlt.table(
        name=f"silver_{feed}",
        comment=f"[{_project.project_code}] Silver — cleansed, typed, deduped {feed}",
        table_properties={
            "quality": "silver",
            "ingest.project_code": _project.project_code,
        },
    )
    @dlt.expect_all_or_quarantine(expectations)
    def _silver():
        df = dlt.read_stream(f"bronze_{feed}_view")
        df = _silver_dedupe(df, cfg)
        return df

    # ---------------- GOLD --------------------------------------------------
    gold_sql = cfg.opt("gold_sql")
    @dlt.table(
        name=f"gold_{feed}",
        comment=f"[{_project.project_code}] Gold — business view of {feed}",
        table_properties={
            "quality": "gold",
            "ingest.project_code": _project.project_code,
        },
    )
    def _gold():
        if gold_sql:
            return spark.sql(gold_sql)
        return dlt.read(f"silver_{feed}")


# ---------------------------------------------------------------------------
# Pipeline boot — declare tables for every active feed in THIS project
# ---------------------------------------------------------------------------
for _cfg in _repo.list_active_feeds(project_code=PROJECT_CODE):
    _declare_feed(_cfg)
