"""
Delta Live Tables pipeline — config-driven Bronze → Silver → Gold.

This module is meant to be the sole notebook attached to a DLT pipeline. At
pipeline boot it reads feed_config and dynamically declares one set of DLT
tables per active feed:

    bronze_<feed_name>      — raw + ingestion metadata (already populated by
                              IngestionEngine; DLT just registers it as a
                              streaming source)
    silver_<feed_name>      — typed, deduped, with @expect_or_quarantine
    gold_<feed_name>        — business view (defaults to a SCD-1 latest snapshot;
                              override per-feed by adding a `gold_sql` entry to
                              source_options)

Quarantined rows are persisted to `silver_<feed_name>_quarantine` so the
operator console can show them, then routed to error_log by a downstream job
that reads the quarantine table.

Usage:
    1. Create a DLT pipeline in Databricks
    2. Point it at this notebook
    3. Configure target schema = `ingest_platform.silver` (or your conv.)
    4. Add pipeline parameter `control_table` if you need to override default
"""

from __future__ import annotations

# These imports only succeed inside a DLT pipeline runtime. Stub-friendly try.
try:
    import dlt
except ImportError:  # local lint only
    class _DltStub:
        def table(self, **kw):     return lambda f: f
        def view(self, **kw):      return lambda f: f
        def expect(self, *a, **k): return lambda f: f
        def expect_or_drop(self, *a, **k):       return lambda f: f
        def expect_or_quarantine(self, *a, **k): return lambda f: f
        def expect_or_fail(self, *a, **k):       return lambda f: f
        def read(self, *a, **k):        raise RuntimeError("DLT runtime only")
        def read_stream(self, *a, **k): raise RuntimeError("DLT runtime only")
    dlt = _DltStub()

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, current_timestamp, row_number
from pyspark.sql.window import Window

from ingestion_framework.config import ConfigRepository


spark = SparkSession.builder.getOrCreate()
_repo = ConfigRepository(spark)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _silver_expectations(cfg) -> dict:
    """
    Build the dict of expectations passed to @dlt.expect_all_or_drop /
    @dlt.expect_all_or_quarantine. Pulls from source_options['expectations']
    if present (JSON map of name -> SQL predicate); otherwise sensible defaults.
    """
    import json as _json
    raw = cfg.opt("expectations")
    if raw:
        return _json.loads(raw)
    # Sensible defaults — at least require non-null _ingest_run_id
    return {
        "non_null_ingest_run_id": "_ingest_run_id IS NOT NULL",
    }


def _silver_dedupe(df: DataFrame, cfg) -> DataFrame:
    """Dedup by business key when configured; otherwise pass through."""
    bkey = cfg.opt("business_key")
    if not bkey:
        return df
    keys = [k.strip() for k in bkey.split(",")]
    order = cfg.opt("dedupe_order", "_ingest_ts DESC")
    w = Window.partitionBy(*keys).orderBy(*[
        col(parts.split()[0]).desc() if "DESC" in parts.upper() else col(parts.split()[0]).asc()
        for parts in order.split(",")
    ])
    return (df.withColumn("_rn", row_number().over(w))
              .where("_rn = 1")
              .drop("_rn"))


# ---------------------------------------------------------------------------
# Per-feed table generation
# ---------------------------------------------------------------------------
def _declare_feed(cfg) -> None:
    """Register Bronze (as source), Silver, and Gold tables for one feed."""

    feed = cfg.feed_name
    bronze_table = cfg.target_table  # already populated by IngestionEngine

    # ---------------- BRONZE (read-through) ---------------------------------
    @dlt.table(
        name=f"bronze_{feed}_view",
        comment=f"Bronze view for {feed} (passthrough from {bronze_table})",
    )
    def _bronze():
        return dlt.read_stream(bronze_table)

    # ---------------- SILVER ------------------------------------------------
    expectations = _silver_expectations(cfg)

    @dlt.table(
        name=f"silver_{feed}",
        comment=f"Silver — cleansed, typed, deduped {feed}",
        table_properties={"quality": "silver"},
    )
    @dlt.expect_all_or_quarantine(expectations)  # quarantine rather than drop
    def _silver():
        df = dlt.read_stream(f"bronze_{feed}_view")
        df = _silver_dedupe(df, cfg)
        return df

    # ---------------- GOLD --------------------------------------------------
    gold_sql = cfg.opt("gold_sql")
    @dlt.table(
        name=f"gold_{feed}",
        comment=f"Gold — business-ready view of {feed}",
        table_properties={"quality": "gold"},
    )
    def _gold():
        if gold_sql:
            # Custom Gold transform from config
            return spark.sql(gold_sql)
        # Default Gold = latest snapshot of Silver
        return dlt.read(f"silver_{feed}")


# ---------------------------------------------------------------------------
# Pipeline boot — declare tables for every active feed
# ---------------------------------------------------------------------------
for _cfg in _repo.list_active():
    _declare_feed(_cfg)
