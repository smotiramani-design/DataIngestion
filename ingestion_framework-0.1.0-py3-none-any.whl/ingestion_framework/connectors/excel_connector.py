"""
Excel connector — handles single-tab and multi-tab .xlsx / .xls files.

Multi-tab strategy:
  * If source_options['sheets'] is provided (comma-separated list), each sheet
    is read separately and union'd together with a `_sheet_name` metadata
    column so downstream consumers can filter or split by tab.
  * If source_options['multi_tab_routing'] is "true", the connector instead
    expects the engine to call read_sheet(sheet_name) for each sheet — used
    when each tab needs to land in a *different* Bronze table. The engine
    handles that fan-out using the related feed_config rows.

This implementation uses the `com.crealytics.spark-excel` package (the
de facto Spark-native option). It must be on the cluster's library path.
"""

from __future__ import annotations

from typing import List, Optional

from pyspark.sql import DataFrame
from pyspark.sql.functions import lit

from ingestion_framework.connectors.base import BaseConnector


class ExcelConnector(BaseConnector):
    SOURCE_TYPE = "EXCEL"

    EXCEL_FORMAT = "com.crealytics.spark.excel"

    def read(self) -> DataFrame:
        opts = self.cfg.source_options or {}
        sheets = self._sheet_list(opts)

        if not sheets:
            # Single-sheet mode — let spark-excel default to the first sheet
            return self._read_sheet(sheet_name=None)

        # Multi-sheet, single-target — union all tabs with a _sheet_name column
        dfs: List[DataFrame] = []
        for sheet in sheets:
            df = self._read_sheet(sheet_name=sheet).withColumn("_sheet_name", lit(sheet))
            dfs.append(df)

        unified = dfs[0]
        for df in dfs[1:]:
            # unionByName tolerates per-sheet column ordering differences
            unified = unified.unionByName(df, allowMissingColumns=True)
        return unified

    # ------ used by the engine when multi_tab_routing is enabled ------------
    def read_sheet(self, sheet_name: str) -> DataFrame:
        """Public hook for one-tab-per-target-table fan-out."""
        return self._read_sheet(sheet_name=sheet_name).withColumn("_sheet_name", lit(sheet_name))

    # ----------------------------------------------------------------- internals
    def _read_sheet(self, sheet_name: Optional[str]) -> DataFrame:
        opts = self.cfg.source_options or {}
        header = (opts.get("header", "true") or "true").lower()
        infer  = (opts.get("infer_schema", "true") or "true").lower()
        data_address = sheet_name + "!A1" if sheet_name else opts.get("data_address", "A1")

        reader = (self.spark.read
                  .format(self.EXCEL_FORMAT)
                  .option("header", header)
                  .option("inferSchema", infer)
                  .option("dataAddress", data_address)
                  .option("treatEmptyValuesAsNulls", "true")
                  # Don't fail on extra/missing columns at the header row
                  .option("addColorColumns", "false"))

        # Optional: limit rows read for sampling
        max_rows = opts.get("max_rows_per_sheet")
        if max_rows:
            reader = reader.option("maxRowsInMemory", max_rows)

        return reader.load(self.cfg.source_location)

    @staticmethod
    def _sheet_list(opts: dict) -> List[str]:
        raw = opts.get("sheets", "")
        if not raw:
            return []
        return [s.strip() for s in raw.split(",") if s.strip()]
