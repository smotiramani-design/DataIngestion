"""
Relational database connector (Oracle, SQL Server, etc.) via JDBC.

`source_location` is a JDBC URL.  `source_options` should provide:
  * driver        — JDBC driver class
  * user          — secret name or literal (prefer dbutils.secrets in prod)
  * password      — secret name or literal (prefer dbutils.secrets in prod)
  * dbtable       — table name OR a `(SELECT ...) t` subquery
  * num_partitions, partition_column, lower_bound, upper_bound — for parallel reads
  * fetch_size    — default 10_000

For INCREMENTAL load_mode, the framework injects a watermark predicate
into dbtable using the value persisted from the previous run (which the
engine resolves before calling read()).
"""

from __future__ import annotations

from typing import Optional

from pyspark.sql import DataFrame

from ingestion_framework.connectors.base import BaseConnector


class RdbmsConnector(BaseConnector):
    SOURCE_TYPE = "RDBMS"

    # The engine sets this before calling read() when load_mode=INCREMENTAL
    last_watermark: Optional[str] = None

    def read(self) -> DataFrame:
        opts = self.cfg.source_options or {}
        jdbc_url = self.cfg.source_location

        dbtable = self._build_dbtable(opts)

        reader = (self.spark.read
                  .format("jdbc")
                  .option("url", jdbc_url)
                  .option("dbtable", dbtable)
                  .option("driver", opts.get("driver", "oracle.jdbc.OracleDriver"))
                  .option("user", opts.get("user", ""))
                  .option("password", opts.get("password", ""))
                  .option("fetchsize", opts.get("fetch_size", "10000")))

        # Optional parallelism via numeric partition column
        if all(k in opts for k in ("partition_column", "lower_bound", "upper_bound", "num_partitions")):
            reader = (reader
                      .option("partitionColumn", opts["partition_column"])
                      .option("lowerBound", opts["lower_bound"])
                      .option("upperBound", opts["upper_bound"])
                      .option("numPartitions", opts["num_partitions"]))

        return reader.load()

    # --------------------------------------------------------------- helpers
    def _build_dbtable(self, opts: dict) -> str:
        """Wrap the table reference in a subquery if we need a watermark predicate."""
        base = opts.get("dbtable")
        if not base:
            raise ValueError("RDBMS feeds require source_options['dbtable']")

        if self.cfg.load_mode == "INCREMENTAL" and self.cfg.watermark_column and self.last_watermark:
            wm_col = self.cfg.watermark_column
            wm_val = self.last_watermark
            # Defensive quoting — caller is responsible for typed values in production
            predicate = f"{wm_col} > '{wm_val}'"
            # If base already looks like a subquery, push predicate into outer wrap
            if base.strip().startswith("("):
                return f"(SELECT * FROM {base} WHERE {predicate}) inc"
            return f"(SELECT * FROM {base} WHERE {predicate}) inc"
        return base

    def expected_count(self) -> Optional[int]:
        """Run a pre-flight COUNT(*) so we can reconcile after Bronze write."""
        opts = self.cfg.source_options or {}
        if not opts.get("count_check_enabled", "false").lower() == "true":
            return None
        # Wrap dbtable as a count subquery
        dbtable = self._build_dbtable(opts)
        cnt_sql = f"(SELECT COUNT(*) AS n FROM {dbtable}) c"
        df = (self.spark.read.format("jdbc")
              .option("url", self.cfg.source_location)
              .option("dbtable", cnt_sql)
              .option("driver", opts.get("driver", "oracle.jdbc.OracleDriver"))
              .option("user", opts.get("user", ""))
              .option("password", opts.get("password", ""))
              .load())
        return int(df.collect()[0]["n"])
