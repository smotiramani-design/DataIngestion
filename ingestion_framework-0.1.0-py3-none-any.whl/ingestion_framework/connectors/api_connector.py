"""
REST API connector.

Supports paginated GET endpoints with bearer-token or basic auth. Pagination
strategies handled:
  * page_number  — increments ?page= until empty response
  * cursor       — follows a cursor field returned in the response body
  * link_header  — follows RFC 5988 Link: <...>; rel="next"
  * none         — single request

Driver-side pagination is intentional: most source APIs don't expose enough
metadata for Spark to parallelize reads safely without losing or duplicating
records.
"""

from __future__ import annotations

import json
import time
from typing import Any, Dict, Iterator, List, Optional

import requests
from pyspark.sql import DataFrame

from ingestion_framework.connectors.base import BaseConnector


class ApiConnector(BaseConnector):
    SOURCE_TYPE = "API"

    DEFAULT_TIMEOUT = 30
    DEFAULT_MAX_RETRIES = 5
    DEFAULT_BACKOFF = 2.0

    # ---------------------------------------------------------------- public
    def read(self) -> DataFrame:
        records = list(self._iter_records())
        if not records:
            # Return an empty DF with whatever schema the caller expects;
            # passing an empty list to spark.read.json yields an inferred schema
            # which may break Bronze append. Use schema_definition if provided.
            schema = self.cfg.schema_json()
            if schema:
                from pyspark.sql.types import StructType
                return self.spark.createDataFrame([], StructType.fromJson(schema))
            return self.spark.createDataFrame([], "value STRING")  # placeholder

        # Use spark.read.json on a parallelized RDD — this preserves nested types.
        rdd = self.spark.sparkContext.parallelize([json.dumps(r) for r in records])
        return self.spark.read.json(rdd)

    # ---------------------------------------------------------------- internals
    def _iter_records(self) -> Iterator[Dict[str, Any]]:
        url = self.cfg.source_location
        strategy = (self.cfg.opt("pagination", "none") or "none").lower()
        records_path = self.cfg.opt("records_path")  # e.g. "data.items" — dotted JSONPath
        page_param = self.cfg.opt("page_param", "page")
        cursor_field = self.cfg.opt("cursor_field", "next_cursor")
        cursor_param = self.cfg.opt("cursor_param", "cursor")

        page = 1
        cursor: Optional[str] = None
        next_url: Optional[str] = url

        while next_url is not None:
            params: Dict[str, Any] = {}
            if strategy == "page_number":
                params[page_param] = page
            elif strategy == "cursor" and cursor:
                params[cursor_param] = cursor

            body = self._request_with_retry(next_url, params=params)

            page_records = self._extract_records(body, records_path)
            if not page_records:
                break

            for rec in page_records:
                yield rec

            # Decide whether we keep going
            if strategy == "page_number":
                page += 1
                # Stop when we hit an empty page (handled at top of loop next iter)
            elif strategy == "cursor":
                cursor = self._dotted_get(body, cursor_field)
                if not cursor:
                    next_url = None
            elif strategy == "link_header":
                # The retry helper attaches the response object for us
                next_url = self._link_header_next  # set as side effect
            else:  # 'none'
                next_url = None

    def _request_with_retry(self, url: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        timeout = int(self.cfg.opt_int("timeout_seconds", self.DEFAULT_TIMEOUT))
        max_retries = int(self.cfg.opt_int("max_retries", self.DEFAULT_MAX_RETRIES))
        backoff = float(self.cfg.opt("backoff_seconds", str(self.DEFAULT_BACKOFF)))

        headers = self._build_auth_headers()
        last_exc: Optional[BaseException] = None

        for attempt in range(1, max_retries + 1):
            try:
                resp = requests.get(url, params=params, headers=headers, timeout=timeout)
                # Honour Retry-After on 429 / 503
                if resp.status_code in (429, 503):
                    wait = float(resp.headers.get("Retry-After", backoff * attempt))
                    time.sleep(wait)
                    continue
                resp.raise_for_status()

                # Capture Link header for link_header pagination
                self._link_header_next = self._parse_link_next(resp.headers.get("Link", ""))
                return resp.json()
            except (requests.RequestException, ValueError) as exc:
                last_exc = exc
                if attempt >= max_retries:
                    raise
                time.sleep(backoff * (2 ** (attempt - 1)))  # exponential backoff

        # Defensive — shouldn't be reachable
        raise RuntimeError(f"API read failed after {max_retries} attempts: {last_exc}")

    # ---------------------------------------------------------------- helpers
    def _build_auth_headers(self) -> Dict[str, str]:
        headers = {"Accept": "application/json"}
        auth_type = (self.cfg.opt("auth_type", "none") or "none").lower()

        if auth_type == "bearer":
            # In production, resolve via dbutils.secrets.get(...)
            token = self.cfg.opt("auth_token", "")
            headers["Authorization"] = f"Bearer {token}"
        elif auth_type == "api_key":
            header_name = self.cfg.opt("auth_header", "X-API-Key")
            headers[header_name] = self.cfg.opt("auth_token", "")
        # OAuth client-credentials flow would acquire a token here.

        # Allow arbitrary additional headers via JSON in source_options['headers']
        extra = self.cfg.opt("headers")
        if extra:
            headers.update(json.loads(extra))
        return headers

    @staticmethod
    def _extract_records(body: Any, path: Optional[str]) -> List[Dict[str, Any]]:
        """Pull the list of records out of the response, given an optional dotted path."""
        if path is None:
            # Body is either a list or a single dict
            return body if isinstance(body, list) else [body]
        node = ApiConnector._dotted_get(body, path)
        if isinstance(node, list):
            return node
        if node is None:
            return []
        return [node]

    @staticmethod
    def _dotted_get(obj: Any, path: str) -> Any:
        cur = obj
        for part in path.split("."):
            if isinstance(cur, dict):
                cur = cur.get(part)
            else:
                return None
        return cur

    @staticmethod
    def _parse_link_next(link_header: str) -> Optional[str]:
        """Parse a single rel=next from an RFC 5988 Link header."""
        if not link_header:
            return None
        for part in link_header.split(","):
            if 'rel="next"' in part:
                start = part.find("<")
                end = part.find(">")
                if 0 <= start < end:
                    return part[start + 1:end].strip()
        return None
