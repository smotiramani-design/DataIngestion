"""
Delimited connector — same machinery as CSV but with an explicit, non-default
delimiter required (pipe, tab, semicolon, etc.).

source_options['delimiter'] is mandatory. Use literal "\\t" for tab.
"""

from __future__ import annotations

from pyspark.sql import DataFrame

from ingestion_framework.connectors.base import BaseConnector
from ingestion_framework.connectors.csv_connector import _read_text_file


class DelimitedConnector(BaseConnector):
    SOURCE_TYPE = "DELIMITED"

    def read(self) -> DataFrame:
        opts = self.cfg.source_options or {}
        if "delimiter" not in opts:
            raise ValueError(
                f"DELIMITED feed '{self.cfg.feed_name}' requires source_options['delimiter']. "
                "Use CSV source_type for comma-separated files."
            )
        return _read_text_file(self, default_delimiter=opts["delimiter"])
