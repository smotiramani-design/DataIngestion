"""
Base connector — abstract interface every source-type connector implements.

A connector's only responsibility is to return a Spark DataFrame that contains
*every* source record (no filtering, no dropping). The framework engine adds
ingestion metadata and writes to Bronze. DQ checks happen later in DLT.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

from pyspark.sql import SparkSession, DataFrame

from ingestion_framework.config import FeedConfig


class BaseConnector(ABC):
    """All source connectors implement this interface."""

    # The framework's contract: zero record loss. Connectors must NOT
    # filter, deduplicate, or transform — return source data faithfully.
    SOURCE_TYPE: str = ""  # set by subclasses; informational only

    def __init__(self, spark: SparkSession, cfg: FeedConfig):
        self.spark = spark
        self.cfg = cfg

    # ------------------------------------------------------------------ read
    @abstractmethod
    def read(self) -> DataFrame:
        """
        Read the source and return a DataFrame with every record.

        Implementations must:
          - Raise on connectivity / auth / parse failures (engine handles them)
          - NOT filter rows (zero record loss)
          - NOT dedupe (Silver handles that)
          - Preserve all source columns even if they're not in the target schema
        """
        ...

    # ------------------------------------------------------------------ helpers
    def expected_count(self) -> Optional[int]:
        """
        Optional — return the expected source row count, used for end-to-end
        reconciliation. Connectors that can cheaply count beforehand (e.g. a
        SQL `SELECT COUNT(*)` against a table or an API `total` field) should
        override. Default is None which disables strict reconciliation.
        """
        return None
