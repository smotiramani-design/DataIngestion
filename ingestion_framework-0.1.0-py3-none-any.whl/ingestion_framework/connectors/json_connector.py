"""
JSON connector — single files, multiline JSON, JSON Lines, and Auto Loader
streaming.

For batch loads we use spark.read.json(). For streaming / continuous file
arrival, we recommend Auto Loader (cloudFiles) — set source_options['streaming']
to "true" and the engine will use readStream.
"""

from __future__ import annotations

from pyspark.sql import DataFrame

from ingestion_framework.connectors.base import BaseConnector


class JsonConnector(BaseConnector):
    SOURCE_TYPE = "JSON"

    def read(self) -> DataFrame:
        path = self.cfg.source_location
        opts = self.cfg.source_options or {}

        is_streaming = (opts.get("streaming", "false") or "false").lower() == "true"
        multiline    = (opts.get("multiline", "false") or "false").lower() == "true"

        # Schema is optional — if provided, use it (safer for production)
        schema_json = self.cfg.schema_json()

        if is_streaming:
            # Auto Loader — recommended for continuously arriving files.
            reader = (self.spark.readStream
                      .format("cloudFiles")
                      .option("cloudFiles.format", "json")
                      .option("cloudFiles.schemaLocation", opts.get("schema_location", f"{path}/_schemas"))
                      .option("multiline", str(multiline).lower())
                      # Allow new columns to flow through to Bronze rather than failing.
                      .option("cloudFiles.schemaEvolutionMode", "addNewColumns"))
            if schema_json:
                from pyspark.sql.types import StructType
                reader = reader.schema(StructType.fromJson(schema_json))
            return reader.load(path)

        # Batch read
        reader = self.spark.read.option("multiline", str(multiline).lower())
        if schema_json:
            from pyspark.sql.types import StructType
            reader = reader.schema(StructType.fromJson(schema_json))
        return reader.json(path)
