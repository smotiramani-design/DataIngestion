"""
CSV connector.

Uses Spark's native CSV reader in PERMISSIVE mode by default — malformed rows
are captured in a `_corrupt_record` column rather than silently dropped. This
preserves the framework's zero-record-loss guarantee.
"""

from __future__ import annotations

from pyspark.sql import DataFrame

from ingestion_framework.connectors.base import BaseConnector


class CsvConnector(BaseConnector):
    SOURCE_TYPE = "CSV"

    def read(self) -> DataFrame:
        return _read_text_file(self, default_delimiter=",")


# Shared by CSV and DELIMITED — the only differences are the default delimiter
# and the source_type label.
def _read_text_file(connector: BaseConnector, default_delimiter: str) -> DataFrame:
    opts = connector.cfg.source_options or {}
    path = connector.cfg.source_location

    is_streaming = (opts.get("streaming", "false") or "false").lower() == "true"
    delimiter    = opts.get("delimiter", default_delimiter)
    header       = (opts.get("header", "true") or "true").lower()
    quote        = opts.get("quote", '"')
    escape       = opts.get("escape", "\\")
    encoding     = opts.get("encoding", "UTF-8")
    multiline    = (opts.get("multiline", "false") or "false").lower()

    schema_json = connector.cfg.schema_json()

    if is_streaming:
        reader = (connector.spark.readStream
                  .format("cloudFiles")
                  .option("cloudFiles.format", "csv")
                  .option("cloudFiles.schemaLocation", opts.get("schema_location", f"{path}/_schemas")))
    else:
        reader = connector.spark.read.format("csv")

    reader = (reader
              .option("sep", delimiter)
              .option("header", header)
              .option("quote", quote)
              .option("escape", escape)
              .option("encoding", encoding)
              .option("multiLine", multiline)
              # PERMISSIVE keeps malformed rows; bad rows go to _corrupt_record
              .option("mode", "PERMISSIVE")
              .option("columnNameOfCorruptRecord", "_corrupt_record"))

    if schema_json:
        from pyspark.sql.types import StructType
        # When schema is supplied, a _corrupt_record column must be in it for
        # PERMISSIVE mode to retain malformed rows.
        schema = StructType.fromJson(schema_json)
        if "_corrupt_record" not in [f.name for f in schema.fields]:
            from pyspark.sql.types import StringType, StructField
            schema = schema.add(StructField("_corrupt_record", StringType(), True))
        reader = reader.schema(schema)
    else:
        reader = reader.option("inferSchema", opts.get("infer_schema", "true"))

    return reader.load(path)
