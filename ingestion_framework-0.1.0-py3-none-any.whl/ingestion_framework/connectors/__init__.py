"""
Connector registry.

Each source_type maps to a Connector class. New source types are added by
implementing BaseConnector and registering here — no other framework code
needs to change.
"""

from ingestion_framework.connectors.base import BaseConnector
from ingestion_framework.connectors.api_connector import ApiConnector
from ingestion_framework.connectors.rdbms_connector import RdbmsConnector
from ingestion_framework.connectors.json_connector import JsonConnector
from ingestion_framework.connectors.excel_connector import ExcelConnector
from ingestion_framework.connectors.csv_connector import CsvConnector
from ingestion_framework.connectors.delimited_connector import DelimitedConnector
from ingestion_framework.connectors.fixed_connector import FixedLengthConnector


_REGISTRY = {
    "API":       ApiConnector,
    "RDBMS":     RdbmsConnector,
    "JSON":      JsonConnector,
    "EXCEL":     ExcelConnector,
    "CSV":       CsvConnector,
    "DELIMITED": DelimitedConnector,
    "FIXED":     FixedLengthConnector,
}


def get_connector(source_type: str) -> type:
    """Return the connector class for a given source_type."""
    cls = _REGISTRY.get(source_type.upper())
    if cls is None:
        raise ValueError(
            f"No connector registered for source_type='{source_type}'. "
            f"Known types: {sorted(_REGISTRY.keys())}"
        )
    return cls


__all__ = ["BaseConnector", "get_connector"]
