"""
Fixed-length file connector.

The position map lives in `schema_definition`. Expected JSON shape:

    {
      "fields": [
        {"name": "customer_id",  "start": 1,  "length": 10, "type": "string", "trim": true},
        {"name": "first_name",   "start": 11, "length": 30, "type": "string", "trim": true},
        {"name": "balance",      "start": 41, "length": 13, "type": "decimal", "scale": 2}
      ]
    }

`start` is 1-indexed (matches mainframe / COBOL conventions). Type coercion
is best-effort: we use try_cast / try_to_date so malformed values become
NULL rather than aborting the batch — preserving the framework's
zero-record-loss contract. Downstream DLT expectations can flag the NULLs.
"""

from __future__ import annotations

from typing import List, Dict, Any

from pyspark.sql import DataFrame
from pyspark.sql.functions import col, expr, length

from ingestion_framework.connectors.base import BaseConnector


class FixedLengthConnector(BaseConnector):
    SOURCE_TYPE = "FIXED"

    def read(self) -> DataFrame:
        schema_def = self.cfg.schema_json()
        if not schema_def or "fields" not in schema_def:
            raise ValueError(
                f"FIXED feed '{self.cfg.feed_name}' requires schema_definition with a 'fields' array"
            )

        fields: List[Dict[str, Any]] = schema_def["fields"]
        self._validate_positions(fields)

        # Read every line as a single STRING column.
        raw = (self.spark.read
               .text(self.cfg.source_location)
               .withColumnRenamed("value", "_raw_line"))

        # Build a single SQL SELECT expression per field — keeps the entire
        # pipeline (slice -> trim -> cast) inside one expr() call, which is
        # the most reliable way to use try_cast across PySpark versions.
        select_exprs = []
        for f in fields:
            name = f["name"]
            select_exprs.append(expr(self._field_sql(f)).alias(name))

        # Keep _raw_line for replay / quarantine
        select_exprs.append(col("_raw_line"))

        df = raw.select(*select_exprs)
        # Tag rows whose declared length doesn't match expectations — DLT can
        # route them to error_log via expectations on _length_ok.
        expected_len = max(int(f["start"]) + int(f["length"]) - 1 for f in fields)
        df = df.withColumn("_line_length", length(col("_raw_line")))
        df = df.withColumn("_length_ok", col("_line_length") >= expected_len)
        return df

    # ----------------------------------------------------------------- internals
    @staticmethod
    def _field_sql(spec: Dict[str, Any]) -> str:
        """Return a SQL expression that slices, trims, and try_casts one field."""
        start = int(spec["start"])
        length_ = int(spec["length"])
        ftype = (spec.get("type") or "string").lower()
        do_trim = bool(spec.get("trim", True))

        # Slice — substring(_raw_line, start, length)
        sliced = f"substring(_raw_line, {start}, {length_})"
        if do_trim:
            sliced = f"trim({sliced})"

        if ftype in ("string", "str"):
            return sliced
        if ftype in ("int", "integer"):
            return f"try_cast(nullif({sliced}, '') AS INT)"
        if ftype in ("long", "bigint"):
            return f"try_cast(nullif({sliced}, '') AS BIGINT)"
        if ftype in ("decimal", "numeric"):
            scale = int(spec.get("scale", 2))
            precision = int(spec.get("precision", 18))
            return f"try_cast(nullif({sliced}, '') AS DECIMAL({precision},{scale}))"
        if ftype == "date":
            fmt = spec.get("format", "yyyyMMdd")
            return f"try_to_date(nullif({sliced}, ''), '{fmt}')"
        if ftype in ("timestamp", "datetime"):
            fmt = spec.get("format", "yyyyMMddHHmmss")
            return f"try_to_timestamp(nullif({sliced}, ''), '{fmt}')"
        return sliced  # unknown type — leave as STRING

    @staticmethod
    def _validate_positions(fields: List[Dict[str, Any]]) -> None:
        """Sanity-check field positions don't overlap and start at 1."""
        sorted_fields = sorted(fields, key=lambda f: int(f["start"]))
        cursor = 1
        for f in sorted_fields:
            start = int(f["start"])
            if start < cursor:
                raise ValueError(
                    f"Fixed-length field '{f['name']}' overlaps prior field "
                    f"(starts at {start}, expected >= {cursor})"
                )
            cursor = start + int(f["length"])
