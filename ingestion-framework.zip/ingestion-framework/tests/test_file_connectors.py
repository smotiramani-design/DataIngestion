"""
Integration tests for file-based connectors using real temp files.

These exercise the actual Spark readers (no mocks) against tiny fixtures, so
we catch real schema / parse / encoding issues that unit tests miss.
"""

import os
import tempfile

import pytest

from ingestion_framework.config import FeedConfig
from ingestion_framework.connectors.csv_connector import CsvConnector
from ingestion_framework.connectors.delimited_connector import DelimitedConnector
from ingestion_framework.connectors.fixed_connector import FixedLengthConnector


# ---------------------------------------------------------------------------
# CSV
# ---------------------------------------------------------------------------
class TestCsvConnector:
    def test_reads_well_formed_csv(self, spark, tmp_path):
        path = tmp_path / "good.csv"
        path.write_text("id,name,amount\n1,Alice,100\n2,Bob,250\n")

        cfg = FeedConfig(
            feed_id=1, feed_name="t", source_type="CSV",
            source_location=str(path),
            source_options={"header": "true", "infer_schema": "true"},
            target_table="x", schema_definition=None,
            load_mode="FULL", watermark_column=None,
            schedule_cron=None, sla_minutes=None,
            owner="t", is_active=True,
        )
        df = CsvConnector(spark, cfg).read()

        assert df.count() == 2
        assert set(df.columns) >= {"id", "name", "amount"}
        names = sorted(r["name"] for r in df.select("name").collect())
        assert names == ["Alice", "Bob"]

    def test_permissive_mode_preserves_malformed_rows(self, spark, tmp_path):
        """A malformed row must NOT be silently dropped (zero record loss)."""
        path = tmp_path / "mixed.csv"
        path.write_text("id,name,amount\n1,Alice,100\nMALFORMED-NO-COMMAS\n3,Carol,300\n")

        cfg = FeedConfig(
            feed_id=1, feed_name="t", source_type="CSV",
            source_location=str(path),
            source_options={"header": "true", "infer_schema": "false"},
            target_table="x", schema_definition=None,
            load_mode="FULL", watermark_column=None,
            schedule_cron=None, sla_minutes=None,
            owner="t", is_active=True,
        )
        df = CsvConnector(spark, cfg).read()

        # All three rows must be present — the malformed one ends up with
        # nulls in the typed columns. Spark may or may not surface the
        # _corrupt_record column when inferSchema=false; the contract here
        # is "no records dropped".
        assert df.count() == 3


# ---------------------------------------------------------------------------
# Delimited
# ---------------------------------------------------------------------------
class TestDelimitedConnector:
    def test_pipe_delimited_parses_correctly(self, spark, tmp_path):
        path = tmp_path / "vendor.psv"
        path.write_text("id|name|amount\n1|Alice|100\n2|Bob|250\n")

        cfg = FeedConfig(
            feed_id=1, feed_name="t", source_type="DELIMITED",
            source_location=str(path),
            source_options={"delimiter": "|", "header": "true", "infer_schema": "true"},
            target_table="x", schema_definition=None,
            load_mode="FULL", watermark_column=None,
            schedule_cron=None, sla_minutes=None,
            owner="t", is_active=True,
        )
        df = DelimitedConnector(spark, cfg).read()
        assert df.count() == 2

    def test_missing_delimiter_raises(self, spark, tmp_path):
        cfg = FeedConfig(
            feed_id=1, feed_name="t", source_type="DELIMITED",
            source_location=str(tmp_path / "nope.txt"),
            source_options={},  # no delimiter — should fail loudly
            target_table="x", schema_definition=None,
            load_mode="FULL", watermark_column=None,
            schedule_cron=None, sla_minutes=None,
            owner="t", is_active=True,
        )
        with pytest.raises(ValueError) as exc:
            DelimitedConnector(spark, cfg).read()
        assert "delimiter" in str(exc.value).lower()


# ---------------------------------------------------------------------------
# Fixed-length
# ---------------------------------------------------------------------------
class TestFixedLengthConnector:
    SCHEMA_DEF = """
    {
      "fields": [
        {"name": "account_id", "start": 1,  "length": 6,  "type": "string", "trim": true},
        {"name": "txn_code",   "start": 7,  "length": 4,  "type": "string", "trim": true},
        {"name": "amount",     "start": 11, "length": 10, "type": "decimal", "scale": 2, "precision": 12}
      ]
    }
    """

    def _make_cfg(self, location: str) -> FeedConfig:
        return FeedConfig(
            feed_id=1, feed_name="ledger", source_type="FIXED",
            source_location=location,
            source_options={},
            target_table="x",
            schema_definition=self.SCHEMA_DEF,
            load_mode="FULL", watermark_column=None,
            schedule_cron=None, sla_minutes=None,
            owner="t", is_active=True,
        )

    def test_slices_columns_by_position(self, spark, tmp_path):
        # account_id (1-6) + txn_code (7-10) + amount (11-20)
        path = tmp_path / "ledger.txt"
        path.write_text(
            "ACC001DEPT0000123.45\n"
            "ACC002WDRW0000050.00\n"
        )

        df = FixedLengthConnector(spark, self._make_cfg(str(path))).read()
        rows = df.orderBy("account_id").collect()
        assert df.count() == 2
        assert rows[0]["account_id"] == "ACC001"
        assert rows[0]["txn_code"]   == "DEPT"
        assert str(rows[0]["amount"]) == "123.45"
        assert rows[1]["account_id"] == "ACC002"

    def test_short_lines_tagged_not_dropped(self, spark, tmp_path):
        """Short lines must remain in the DF tagged as length-not-ok."""
        path = tmp_path / "short.txt"
        path.write_text("ACC001DEPT0000123.45\nSHORT\n")
        df = FixedLengthConnector(spark, self._make_cfg(str(path))).read()

        # Both lines present (zero record loss); flag is False on the short one
        assert df.count() == 2
        bad = df.where("_length_ok = false").collect()
        assert len(bad) == 1
        assert bad[0]["_raw_line"] == "SHORT"

    def test_overlapping_positions_raise_validation_error(self, spark, tmp_path):
        bad_schema = """
        {
          "fields": [
            {"name": "a", "start": 1, "length": 5},
            {"name": "b", "start": 3, "length": 5}
          ]
        }
        """
        path = tmp_path / "wont_be_read.txt"
        path.write_text("anything\n")
        cfg = FeedConfig(
            feed_id=1, feed_name="t", source_type="FIXED",
            source_location=str(path), source_options={},
            target_table="x", schema_definition=bad_schema,
            load_mode="FULL", watermark_column=None,
            schedule_cron=None, sla_minutes=None,
            owner="t", is_active=True,
        )
        with pytest.raises(ValueError) as exc:
            FixedLengthConnector(spark, cfg).read()
        assert "overlap" in str(exc.value).lower()
