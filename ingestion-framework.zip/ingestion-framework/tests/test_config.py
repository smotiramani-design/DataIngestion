"""
Tests for the FeedConfig dataclass — option helpers and JSON parsing.
"""

import pytest

from ingestion_framework.config import FeedConfig


def _make(opts=None, schema_def=None) -> FeedConfig:
    return FeedConfig(
        feed_id=1,
        feed_name="test_feed",
        source_type="CSV",
        source_location="/tmp/anywhere",
        source_options=opts or {},
        target_table="bronze.test_feed",
        schema_definition=schema_def,
        load_mode="FULL",
        watermark_column=None,
        schedule_cron=None,
        sla_minutes=None,
        owner="t@example.com",
        is_active=True,
    )


class TestOptHelpers:
    def test_opt_returns_value_when_present(self):
        cfg = _make({"delimiter": "|"})
        assert cfg.opt("delimiter") == "|"

    def test_opt_returns_default_when_missing(self):
        cfg = _make({})
        assert cfg.opt("delimiter", ",") == ","

    def test_opt_returns_none_when_missing_no_default(self):
        cfg = _make({})
        assert cfg.opt("delimiter") is None

    def test_opt_handles_no_options_dict(self):
        # source_options can come back as None from the table
        cfg = _make(opts={})  # frozen dataclass — start with empty dict
        assert cfg.opt("anything", "fallback") == "fallback"

    def test_opt_int_parses_numeric_strings(self):
        cfg = _make({"timeout_seconds": "30"})
        assert cfg.opt_int("timeout_seconds") == 30

    def test_opt_int_returns_default_when_missing(self):
        cfg = _make({})
        assert cfg.opt_int("timeout_seconds", 60) == 60

    @pytest.mark.parametrize("raw,expected", [
        ("true", True), ("True", True), ("TRUE", True),
        ("1", True), ("yes", True), ("y", True),
        ("false", False), ("0", False), ("no", False),
        ("anything-else", False),
    ])
    def test_opt_bool_parses_truthy_values(self, raw, expected):
        cfg = _make({"streaming": raw})
        assert cfg.opt_bool("streaming") is expected

    def test_opt_bool_default_when_missing(self):
        cfg = _make({})
        assert cfg.opt_bool("streaming", default=True) is True
        assert cfg.opt_bool("streaming", default=False) is False


class TestSchemaJson:
    def test_returns_none_when_blank(self):
        assert _make(schema_def=None).schema_json() is None
        assert _make(schema_def="").schema_json() is None

    def test_parses_valid_json(self):
        cfg = _make(schema_def='{"fields": [{"name": "x", "start": 1, "length": 5}]}')
        parsed = cfg.schema_json()
        assert parsed["fields"][0]["name"] == "x"

    def test_raises_on_malformed_json(self):
        cfg = _make(schema_def="{not-valid-json")
        with pytest.raises(Exception):
            cfg.schema_json()
