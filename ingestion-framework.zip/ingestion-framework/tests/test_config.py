"""
Tests for the FeedConfig dataclass — option helpers and JSON parsing.
"""

import pytest

from ingestion_framework.config import FeedConfig


def _make(opts=None, schema_def=None) -> FeedConfig:
    return FeedConfig(
        feed_id=1,
        project_id=1,
        feed_name="test_feed",
        source_type="CSV",
        source_location="/tmp/anywhere",
        source_options=opts or {},
        target_table="bronze.test_feed",
        schema_definition=schema_def,
        load_mode="FULL",
        watermark_column=None,
        schedule_cron=None,
        sla_minutes=None,
        owner="t@example.com",
        is_active=True,
    )


class TestOptHelpers:
    def test_opt_returns_value_when_present(self):
        cfg = _make({"delimiter": "|"})
        assert cfg.opt("delimiter") == "|"

    def test_opt_returns_default_when_missing(self):
        cfg = _make({})
        assert cfg.opt("delimiter", ",") == ","

    def test_opt_returns_none_when_missing_no_default(self):
        cfg = _make({})
        assert cfg.opt("delimiter") is None

    def test_opt_handles_no_options_dict(self):
        # source_options can come back as None from the table
        cfg = _make(opts={})  # frozen dataclass — start with empty dict
        assert cfg.opt("anything", "fallback") == "fallback"

    def test_opt_int_parses_numeric_strings(self):
        cfg = _make({"timeout_seconds": "30"})
        assert cfg.opt_int("timeout_seconds") == 30

    def test_opt_int_returns_default_when_missing(self):
        cfg = _make({})
        assert cfg.opt_int("timeout_seconds", 60) == 60

    @pytest.mark.parametrize("raw,expected", [
        ("true", True), ("True", True), ("TRUE", True),
        ("1", True), ("yes", True), ("y", True),
        ("false", False), ("0", False), ("no", False),
        ("anything-else", False),
    ])
    def test_opt_bool_parses_truthy_values(self, raw, expected):
        cfg = _make({"streaming": raw})
        assert cfg.opt_bool("streaming") is expected

    def test_opt_bool_default_when_missing(self):
        cfg = _make({})
        assert cfg.opt_bool("streaming", default=True) is True
        assert cfg.opt_bool("streaming", default=False) is False


class TestSchemaJson:
    def test_returns_none_when_blank(self):
        assert _make(schema_def=None).schema_json() is None
        assert _make(schema_def="").schema_json() is None

    def test_parses_valid_json(self):
        cfg = _make(schema_def='{"fields": [{"name": "x", "start": 1, "length": 5}]}')
        parsed = cfg.schema_json()
        assert parsed["fields"][0]["name"] == "x"

    def test_raises_on_malformed_json(self):
        cfg = _make(schema_def="{not-valid-json")
        with pytest.raises(Exception):
            cfg.schema_json()


# ---------------------------------------------------------------------------
# Project + multi-project FeedConfig behavior
# ---------------------------------------------------------------------------
from ingestion_framework.config import Project


def _make_project(catalog="finance_data") -> Project:
    return Project(
        project_id=42,
        project_code="finance",
        project_name="Finance",
        description=None,
        default_catalog=catalog,
        bronze_schema="bronze",
        silver_schema="silver",
        gold_schema="gold",
        default_secret_scope="finance-ingest",
        alert_email="finance@example.com",
        pagerduty_service=None,
        framework_version="0.1.0",
        owner_team="finance-data-eng",
        cost_center="CC-1001",
        is_active=True,
    )


class TestProjectTableNames:
    """The platform's catalog/schema convention is encoded on Project."""

    def test_bronze_table_uses_default_catalog_and_schema(self):
        p = _make_project()
        assert p.bronze_table_name("orders") == "finance_data.bronze.orders"

    def test_silver_table_prefixes_silver(self):
        p = _make_project()
        assert p.silver_table_name("orders") == "finance_data.silver.silver_orders"

    def test_gold_table_prefixes_gold(self):
        p = _make_project()
        assert p.gold_table_name("orders") == "finance_data.gold.gold_orders"

    def test_alternate_catalog(self):
        p = _make_project(catalog="marketing_data")
        assert p.bronze_table_name("customers") == "marketing_data.bronze.customers"


class TestResolvedTargetTable:
    """Effective Bronze table — explicit override vs project default."""

    def test_explicit_target_table_wins(self):
        cfg = _make()  # has target_table="bronze.test_feed"
        p = _make_project()
        # Explicit override is honored regardless of project defaults
        assert cfg.resolved_target_table(p) == "bronze.test_feed"

    def test_null_target_table_falls_back_to_project_default(self):
        cfg = FeedConfig(
            feed_id=1, project_id=42, feed_name="orders",
            source_type="CSV", source_location="/x",
            source_options={}, target_table=None,  # ← deliberately None
            schema_definition=None, load_mode="FULL",
            watermark_column=None, schedule_cron=None, sla_minutes=None,
            owner="x", is_active=True,
        )
        p = _make_project()
        # Should derive from project: <catalog>.<bronze_schema>.<feed_name>
        assert cfg.resolved_target_table(p) == "finance_data.bronze.orders"

    def test_each_project_gets_its_own_namespace(self):
        """Two projects with the same feed_name produce different Bronze tables."""
        cfg = FeedConfig(
            feed_id=1, project_id=1, feed_name="customers",
            source_type="API", source_location="x",
            source_options={}, target_table=None,
            schema_definition=None, load_mode="FULL",
            watermark_column=None, schedule_cron=None, sla_minutes=None,
            owner="x", is_active=True,
        )
        finance = _make_project(catalog="finance_data")
        marketing = _make_project(catalog="marketing_data")

        assert cfg.resolved_target_table(finance)   == "finance_data.bronze.customers"
        assert cfg.resolved_target_table(marketing) == "marketing_data.bronze.customers"
