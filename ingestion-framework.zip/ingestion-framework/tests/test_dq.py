"""
Tests for the DQ engine.

The engine is the single biggest piece of new code in the ADF pivot — it
replaces what DLT @expect_or_quarantine did. These tests exercise the
core behavior with real Spark DataFrames and a stubbed rule repository.
"""

from __future__ import annotations

from typing import List
from unittest.mock import MagicMock

import pytest

from ingestion_framework.dq import (
    DqEngine, DqRule, DqRuleRepository, DqResult,
)


def _rule(
    rule_id: int = 1,
    feed_id: int = 1,
    name: str = "test_rule",
    rule_type: str = "CUSTOM_SQL",
    predicate: str = "id IS NOT NULL",
    severity: str = "ERROR",
    action: str = "QUARANTINE",
) -> DqRule:
    return DqRule(
        rule_id=rule_id, feed_id=feed_id, rule_name=name,
        rule_type=rule_type, predicate=predicate,
        severity=severity, action=action,
        error_message=None, is_active=True,
    )


def _stub_repo(rules: List[DqRule]) -> DqRuleRepository:
    repo = MagicMock(spec=DqRuleRepository)
    repo.list_active_for_feed.return_value = rules
    return repo


class TestNoRules:
    """When no active rules exist, every row passes through."""

    def test_passthrough_when_no_rules(self, spark):
        df = spark.createDataFrame([(1, "a"), (2, "b"), (3, None)], ["id", "name"])
        engine = DqEngine(spark, repo=_stub_repo([]))
        result = engine.evaluate(df, feed_id=1)

        assert isinstance(result, DqResult)
        assert result.good_df.count() == 3
        assert result.quarantine_df is None
        assert result.quarantine_count == 0
        assert result.dropped_count == 0
        assert result.violations == []
        assert not result.has_fatal_violations


class TestQuarantineAction:
    def test_bad_rows_routed_to_quarantine(self, spark):
        df = spark.createDataFrame(
            [(1, "ok"), (2, "ok"), (None, "bad"), (None, "bad2")],
            ["id", "name"],
        )
        rules = [_rule(predicate="id IS NOT NULL", action="QUARANTINE")]
        engine = DqEngine(spark, repo=_stub_repo(rules))
        result = engine.evaluate(df, feed_id=1)

        assert result.good_df.count() == 2
        assert result.quarantine_count == 2
        assert result.quarantine_df is not None
        # Quarantined rows should be tagged with the rule that flagged them
        cols = result.quarantine_df.columns
        assert "_dq_rule_id" in cols
        assert "_dq_rule_name" in cols
        assert "_dq_severity" in cols

    def test_violations_report_per_rule_count(self, spark):
        df = spark.createDataFrame(
            [(1, 100), (2, -10), (3, 50), (4, -5)],
            ["id", "amount"],
        )
        rules = [_rule(predicate="amount >= 0", action="QUARANTINE", name="non_negative_amount")]
        engine = DqEngine(spark, repo=_stub_repo(rules))
        result = engine.evaluate(df, feed_id=1)

        assert len(result.violations) == 1
        assert result.violations[0].rule.rule_name == "non_negative_amount"
        assert result.violations[0].bad_count == 2


class TestDropAction:
    def test_dropped_rows_dont_appear_in_quarantine(self, spark):
        df = spark.createDataFrame([(1,), (2,), (None,)], ["id"])
        rules = [_rule(predicate="id IS NOT NULL", action="DROP")]
        engine = DqEngine(spark, repo=_stub_repo(rules))
        result = engine.evaluate(df, feed_id=1)

        # The row is gone from good_df AND not in quarantine_df
        assert result.good_df.count() == 2
        assert result.quarantine_df is None
        assert result.quarantine_count == 0
        assert result.dropped_count == 1


class TestFailRunAction:
    def test_fail_run_flag_set_when_violations_exist(self, spark):
        df = spark.createDataFrame([(1,), (None,)], ["id"])
        rules = [_rule(predicate="id IS NOT NULL", action="FAIL_RUN", severity="FATAL")]
        engine = DqEngine(spark, repo=_stub_repo(rules))
        result = engine.evaluate(df, feed_id=1)

        assert result.has_fatal_violations is True
        # The bad rows still come out of good_df (the engine doesn't promote them)
        assert result.good_df.count() == 1

    def test_no_fail_run_flag_when_clean(self, spark):
        df = spark.createDataFrame([(1,), (2,)], ["id"])
        rules = [_rule(predicate="id IS NOT NULL", action="FAIL_RUN", severity="FATAL")]
        engine = DqEngine(spark, repo=_stub_repo(rules))
        result = engine.evaluate(df, feed_id=1)

        assert result.has_fatal_violations is False
        assert result.good_df.count() == 2


class TestMultipleRules:
    def test_row_failing_any_rule_is_excluded_from_good(self, spark):
        df = spark.createDataFrame(
            [(1, 100), (2, -10), (None, 50), (3, 200)],
            ["id", "amount"],
        )
        rules = [
            _rule(rule_id=1, name="id_required",     predicate="id IS NOT NULL", action="QUARANTINE"),
            _rule(rule_id=2, name="amount_positive", predicate="amount >= 0",   action="QUARANTINE"),
        ]
        engine = DqEngine(spark, repo=_stub_repo(rules))
        result = engine.evaluate(df, feed_id=1)

        # Good rows: must satisfy ALL rules. Only (1,100) and (3,200) qualify.
        assert result.good_df.count() == 2
        # Total violations across both rules: 1 (id null) + 1 (negative amt) = 2
        assert result.quarantine_count == 2
        assert len(result.violations) == 2

    def test_mixed_actions_track_separately(self, spark):
        df = spark.createDataFrame(
            [(1, 100), (None, 100), (2, -5)],
            ["id", "amount"],
        )
        rules = [
            _rule(rule_id=1, name="drop_null_id", predicate="id IS NOT NULL", action="DROP"),
            _rule(rule_id=2, name="quarantine_neg", predicate="amount >= 0", action="QUARANTINE"),
        ]
        engine = DqEngine(spark, repo=_stub_repo(rules))
        result = engine.evaluate(df, feed_id=1)

        assert result.dropped_count == 1
        assert result.quarantine_count == 1
        assert result.good_df.count() == 1


class TestPredicateBuilder:
    """Direct test of the SQL predicate translation logic."""

    @pytest.mark.parametrize("rt", ["NOT_NULL", "RANGE", "REGEX", "CUSTOM_SQL"])
    def test_simple_predicates_pass_through(self, rt):
        rule = _rule(rule_type=rt, predicate="x > 0")
        assert DqEngine._build_predicate(rule) == "x > 0"

    def test_unique_rule_type_raises_in_builder(self):
        # UNIQUE needs window evaluation, not a row-level predicate.
        rule = _rule(rule_type="UNIQUE", predicate="email")
        with pytest.raises(ValueError, match="UNIQUE"):
            DqEngine._build_predicate(rule)

    def test_unknown_rule_type_raises(self):
        rule = _rule(rule_type="MAGIC", predicate="x")
        with pytest.raises(ValueError, match="Unknown rule_type"):
            DqEngine._build_predicate(rule)
