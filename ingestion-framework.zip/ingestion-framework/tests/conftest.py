"""
Shared pytest fixtures.

The package is installed (editable) via `pip install -e .` before running
tests, so imports like `from ingestion_framework.config import ...` resolve
naturally — no sys.path hacking required.
"""

import pytest


@pytest.fixture(scope="session")
def spark():
    """Session-scoped SparkSession for fast test execution."""
    from pyspark.sql import SparkSession

    spark = (SparkSession.builder
             .master("local[2]")
             .appName("ingestion-framework-tests")
             .config("spark.sql.shuffle.partitions", "2")
             .config("spark.ui.enabled", "false")
             .config("spark.driver.bindAddress", "127.0.0.1")
             .config("spark.driver.host", "127.0.0.1")
             .getOrCreate())
    spark.sparkContext.setLogLevel("ERROR")
    yield spark
    spark.stop()
