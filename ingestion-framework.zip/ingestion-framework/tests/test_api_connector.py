"""
Tests for ApiConnector pure-logic helpers (no network calls).
"""

import pytest

from ingestion_framework.config import FeedConfig
from ingestion_framework.connectors.api_connector import ApiConnector


def _cfg(opts) -> FeedConfig:
    return FeedConfig(
        feed_id=1, project_id=1, feed_name="t", source_type="API",
        source_location="https://api.example.com/things",
        source_options=opts,
        target_table="x", schema_definition=None,
        load_mode="FULL", watermark_column=None,
        schedule_cron=None, sla_minutes=None,
        owner="t", is_active=True,
    )


class TestDottedGet:
    def test_simple_path(self):
        assert ApiConnector._dotted_get({"a": 1}, "a") == 1

    def test_nested_path(self):
        body = {"data": {"items": [1, 2, 3], "next": "abc"}}
        assert ApiConnector._dotted_get(body, "data.items") == [1, 2, 3]
        assert ApiConnector._dotted_get(body, "data.next") == "abc"

    def test_missing_path_returns_none(self):
        assert ApiConnector._dotted_get({"a": 1}, "b") is None
        assert ApiConnector._dotted_get({"a": 1}, "a.b.c") is None


class TestExtractRecords:
    def test_root_list_no_path(self):
        assert ApiConnector._extract_records([{"a": 1}, {"a": 2}], None) == [{"a": 1}, {"a": 2}]

    def test_dict_no_path_wraps_in_list(self):
        assert ApiConnector._extract_records({"a": 1}, None) == [{"a": 1}]

    def test_with_dotted_path(self):
        body = {"data": {"items": [{"x": 1}, {"x": 2}]}}
        assert ApiConnector._extract_records(body, "data.items") == [{"x": 1}, {"x": 2}]

    def test_missing_path_returns_empty(self):
        assert ApiConnector._extract_records({"a": 1}, "missing.path") == []


class TestLinkHeaderParser:
    def test_parses_rel_next(self):
        h = '<https://api.example.com/things?page=2>; rel="next", <https://api.example.com/things?page=10>; rel="last"'
        assert ApiConnector._parse_link_next(h) == "https://api.example.com/things?page=2"

    def test_no_next_returns_none(self):
        h = '<https://api.example.com/things?page=10>; rel="last"'
        assert ApiConnector._parse_link_next(h) is None

    def test_empty_header_returns_none(self):
        assert ApiConnector._parse_link_next("") is None


class TestAuthHeaders:
    def test_bearer_token_header(self, spark):
        cfg = _cfg({"auth_type": "bearer", "auth_token": "abc123"})
        connector = ApiConnector(spark, cfg)
        headers = connector._build_auth_headers()
        assert headers["Authorization"] == "Bearer abc123"
        assert headers["Accept"] == "application/json"

    def test_api_key_header(self, spark):
        cfg = _cfg({"auth_type": "api_key", "auth_token": "xyz", "auth_header": "X-Custom-Key"})
        headers = ApiConnector(spark, cfg)._build_auth_headers()
        assert headers["X-Custom-Key"] == "xyz"

    def test_no_auth(self, spark):
        cfg = _cfg({})
        headers = ApiConnector(spark, cfg)._build_auth_headers()
        assert "Authorization" not in headers
        assert headers["Accept"] == "application/json"

    def test_extra_headers_merged(self, spark):
        cfg = _cfg({"headers": '{"X-Trace-Id": "run-42"}'})
        headers = ApiConnector(spark, cfg)._build_auth_headers()
        assert headers["X-Trace-Id"] == "run-42"
