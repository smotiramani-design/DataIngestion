"""
Tests for the connector registry and base contract.
"""

import pytest

from ingestion_framework.connectors import get_connector
from ingestion_framework.connectors.base import BaseConnector


class TestRegistry:
    @pytest.mark.parametrize("source_type", [
        "API", "RDBMS", "JSON", "EXCEL", "CSV", "DELIMITED", "FIXED",
    ])
    def test_each_source_type_returns_a_connector_subclass(self, source_type):
        cls = get_connector(source_type)
        assert issubclass(cls, BaseConnector)

    def test_lookup_is_case_insensitive(self):
        upper = get_connector("CSV")
        lower = get_connector("csv")
        mixed = get_connector("Csv")
        assert upper is lower is mixed

    def test_unknown_source_type_raises_with_helpful_message(self):
        with pytest.raises(ValueError) as exc:
            get_connector("PARQUET")
        assert "PARQUET" in str(exc.value)
        # The error should list known types so an operator can self-serve
        assert "CSV" in str(exc.value)
