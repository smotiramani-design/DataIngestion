"""
Re-evaluate DQ rules against existing Bronze data (project-scoped).

In the DLT-based design this script drained DLT-managed quarantine tables
into error_log. Without DLT, the DQ engine writes quarantine + error_log
in-line during each run — so this script is no longer about "draining"
quarantine. Its role now is **rule replay**: when an operator adds or
modifies a dq_rule, this Job re-evaluates the rules against existing
Bronze data without re-pulling from source.

Usage:
    ingest-drain-quarantine --project finance
    ingest-drain-quarantine --project finance --feed orders_oracle

The Job triggers per-feed re-evaluation. For each feed, it reads the
last N hours of Bronze (configurable), passes it through the DQ engine,
and writes any new quarantine rows + error_log entries.

Note: the script's name is preserved for backwards compatibility with
the Asset Bundle wiring; the underlying behavior is now "rule replay".
"""

from __future__ import annotations

import argparse
import logging
import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pyspark.sql import SparkSession


log = logging.getLogger(__name__)


def replay_one_feed(
    spark: "SparkSession",
    project_code: str,
    feed_name: str,
    hours_back: int = 24,
) -> int:
    """
    Re-evaluate DQ rules for one feed against the last N hours of Bronze.
    Returns the count of newly-quarantined rows written to error_log.
    """
    from ingestion_framework.config import ConfigRepository
    from ingestion_framework.dq import DqEngine
    from ingestion_framework.audit import ErrorService

    repo = ConfigRepository(spark)
    project = repo.get_project(project_code)
    cfg = repo.get_feed(project_code, feed_name)
    target_table = cfg.resolved_target_table(project)

    # Read recent Bronze rows
    try:
        bronze = (spark.table(target_table)
                  .where(f"_ingest_ts >= current_timestamp() - INTERVAL {int(hours_back)} HOURS"))
    except Exception:
        log.info("No Bronze table yet for feed=%s — nothing to replay", feed_name)
        return 0

    # Run DQ
    dq_engine = DqEngine(spark)
    result = dq_engine.evaluate(bronze, feed_id=cfg.feed_id)

    # Write quarantine and error_log entries for any new violations
    errors = ErrorService(spark)
    if result.quarantine_df is not None and result.quarantine_count > 0:
        qtable = project.silver_table_name(cfg.feed_name) + "_quarantine"
        (result.quarantine_df.write
             .format("delta").mode("append").option("mergeSchema", "true")
             .saveAsTable(qtable))

    rows_logged = 0
    for v in result.violations:
        if v.bad_count == 0:
            continue
        msg = (v.rule.error_message
               or f"DQ rule '{v.rule.rule_name}' failed on {v.bad_count} row(s) "
                  f"during replay; action={v.rule.action}")
        errors.log_dq_violation(
            run_id=f"replay-{project_code}-{feed_name}",
            project_id=project.project_id,
            feed_id=cfg.feed_id,
            rule_name=v.rule.rule_name,
            severity=v.rule.severity,
            message=msg,
            bad_count=v.bad_count,
        )
        rows_logged += 1

    return rows_logged


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Re-evaluate DQ rules against existing Bronze data (project-scoped)."
    )
    parser.add_argument("--project", required=True,
                        help="project_code — only this project's feeds will be replayed")
    parser.add_argument("--feed", default=None,
                        help="Optional single feed name (default: all active feeds in project)")
    parser.add_argument("--hours-back", type=int, default=24,
                        help="How many hours of Bronze data to re-evaluate (default: 24)")
    parser.add_argument("--log-level", default="INFO")
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=getattr(logging, args.log_level.upper()),
        format="%(asctime)s %(levelname)-7s %(name)s — %(message)s",
    )

    from pyspark.sql import SparkSession
    from ingestion_framework.config import ConfigRepository

    spark = SparkSession.builder.getOrCreate()

    if args.feed:
        feeds = [args.feed]
    else:
        repo = ConfigRepository(spark)
        feeds = [f.feed_name for f in repo.list_active_feeds(project_code=args.project)]

    total = 0
    for feed_name in feeds:
        try:
            total += replay_one_feed(
                spark=spark,
                project_code=args.project,
                feed_name=feed_name,
                hours_back=args.hours_back,
            )
        except Exception:
            log.exception("Replay failed for feed=%s", feed_name)

    print(f"Re-evaluated DQ rules; wrote {total} new error_log entries "
          f"for project '{args.project}'")
    return 0


if __name__ == "__main__":
    sys.exit(main())
