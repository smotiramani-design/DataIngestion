-- =============================================================================
-- Sample seed data — one division with three illustrative project tenants
-- and a representative feed per source type.
--
-- Run after sql/01_create_control_tables.sql. Replace placeholders (URLs,
-- JDBC strings, secret references) before running against a real workspace.
-- In production, source credentials come from dbutils.secrets — never inline.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1. Project tenants
-- -----------------------------------------------------------------------------
-- Note: project_id is identity-generated. Rather than hardcoding integers,
-- the inserts below reference projects by code via a subquery — this keeps
-- the script portable across environments.

INSERT INTO ingest_platform.control.projects
    (project_code, project_name, description,
     default_catalog, bronze_schema, silver_schema, gold_schema,
     default_secret_scope, alert_email, pagerduty_service,
     framework_version, owner_team, cost_center, is_active)
VALUES
    ('finance',
     'Finance Data Platform',
     'GL, AP/AR, treasury, and forecasting feeds for the Finance division.',
     'finance_data', 'bronze', 'silver', 'gold',
     'finance-ingest',
     'finance-data-eng@example.com',
     'finance-data-platform',
     '0.1.0',
     'finance-data-eng',
     'CC-1001',
     TRUE),

    ('marketing',
     'Marketing Analytics',
     'Customer engagement, campaign attribution, and CDP integration feeds.',
     'marketing_data', 'bronze', 'silver', 'gold',
     'marketing-ingest',
     'mktg-analytics@example.com',
     NULL,
     '0.1.0',
     'marketing-analytics',
     'CC-2003',
     TRUE),

    ('operations',
     'Operations Data',
     'Supply chain, mainframe ledgers, and operational reporting feeds.',
     'operations_data', 'bronze', 'silver', 'gold',
     'ops-ingest',
     'ops-platform@example.com',
     'ops-data-platform',
     '0.1.0',
     'ops-platform',
     'CC-3007',
     TRUE);

-- -----------------------------------------------------------------------------
-- 2. Feed config samples — one per source pattern, scattered across projects
-- -----------------------------------------------------------------------------
-- Each row references its owning project via a SELECT subquery on project_code.

-- ============ FINANCE PROJECT FEEDS ==========================================

-- 2.1  Oracle GL (RDBMS, INCREMENTAL)
INSERT INTO ingest_platform.control.feed_config
    (project_id, feed_name, source_type, source_location, source_options,
     target_table, schema_definition, load_mode, watermark_column,
     schedule_cron, sla_minutes, owner, is_active)
VALUES (
    (SELECT project_id FROM ingest_platform.control.projects WHERE project_code = 'finance'),
    'gl_journal_oracle', 'RDBMS',
    'jdbc:oracle:thin:@//oracle-prod.example.com:1521/ORCL',
    map(
        'driver',           'oracle.jdbc.OracleDriver',
        'user',             '{{secrets/finance-ingest/oracle_user}}',
        'password',         '{{secrets/finance-ingest/oracle_password}}',
        'dbtable',          'GL.JOURNAL_ENTRIES',
        'fetch_size',       '20000',
        'partition_column', 'JOURNAL_ID',
        'lower_bound',      '1',
        'upper_bound',      '50000000',
        'num_partitions',   '8'
    ),
    NULL,                                    -- target_table NULL → derive from project default
    NULL, 'INCREMENTAL', 'POSTED_AT',
    '0 0 */1 * * ?', 60,
    'finance-data-eng@example.com', TRUE
);

-- 2.2  Vendor pipe-delimited extract (DELIMITED)
INSERT INTO ingest_platform.control.feed_config
    (project_id, feed_name, source_type, source_location, source_options,
     target_table, schema_definition, load_mode, watermark_column,
     schedule_cron, sla_minutes, owner, is_active)
VALUES (
    (SELECT project_id FROM ingest_platform.control.projects WHERE project_code = 'finance'),
    'vendor_extract_acme', 'DELIMITED',
    'abfss://landing@finance-data.dfs.core.windows.net/vendors/acme/',
    map('delimiter', '|', 'header', 'true', 'encoding', 'UTF-8'),
    NULL, NULL, 'FULL', NULL,
    '0 30 4 * * ?', 60,
    'vendor-ops@example.com', TRUE
);

-- 2.3  Excel forecast workbook (EXCEL, single tab)
INSERT INTO ingest_platform.control.feed_config
    (project_id, feed_name, source_type, source_location, source_options,
     target_table, schema_definition, load_mode, watermark_column,
     schedule_cron, sla_minutes, owner, is_active)
VALUES (
    (SELECT project_id FROM ingest_platform.control.projects WHERE project_code = 'finance'),
    'forecast_workbook', 'EXCEL',
    'abfss://landing@finance-data.dfs.core.windows.net/forecast/forecast_2026.xlsx',
    map('header', 'true', 'infer_schema', 'true', 'data_address', 'A1'),
    NULL, NULL, 'FULL', NULL,
    '0 0 6 * * MON', 60,
    'finance-fp&a@example.com', TRUE
);

-- ============ MARKETING PROJECT FEEDS ========================================

-- 2.4  Customer API (API, cursor pagination)
INSERT INTO ingest_platform.control.feed_config
    (project_id, feed_name, source_type, source_location, source_options,
     target_table, schema_definition, load_mode, watermark_column,
     schedule_cron, sla_minutes, owner, is_active)
VALUES (
    (SELECT project_id FROM ingest_platform.control.projects WHERE project_code = 'marketing'),
    'cdp_customers', 'API',
    'https://cdp.example.com/api/v2/customers',
    map(
        'auth_type',      'bearer',
        'auth_token',     '{{secrets/marketing-ingest/cdp_token}}',
        'pagination',     'cursor',
        'cursor_field',   'meta.next_cursor',
        'records_path',   'data',
        'timeout_seconds','30',
        'max_retries',    '5'
    ),
    NULL, NULL, 'INCREMENTAL', 'updated_at',
    '0 */15 * * * ?', 30,
    'mktg-analytics@example.com', TRUE
);

-- 2.5  Campaign events streaming JSON (JSON, Auto Loader)
INSERT INTO ingest_platform.control.feed_config
    (project_id, feed_name, source_type, source_location, source_options,
     target_table, schema_definition, load_mode, watermark_column,
     schedule_cron, sla_minutes, owner, is_active)
VALUES (
    (SELECT project_id FROM ingest_platform.control.projects WHERE project_code = 'marketing'),
    'campaign_events', 'JSON',
    'abfss://landing@marketing-data.dfs.core.windows.net/campaigns/events/',
    map(
        'streaming',       'true',
        'multiline',       'false',
        'schema_location', 'abfss://landing@marketing-data.dfs.core.windows.net/_schemas/campaign_events/'
    ),
    NULL, NULL, 'INCREMENTAL', NULL,
    NULL, 30, 'mktg-analytics@example.com', TRUE
);

-- 2.6  Regional sales multi-tab Excel (EXCEL, multi-tab)
INSERT INTO ingest_platform.control.feed_config
    (project_id, feed_name, source_type, source_location, source_options,
     target_table, schema_definition, load_mode, watermark_column,
     schedule_cron, sla_minutes, owner, is_active)
VALUES (
    (SELECT project_id FROM ingest_platform.control.projects WHERE project_code = 'marketing'),
    'regional_sales', 'EXCEL',
    'abfss://landing@marketing-data.dfs.core.windows.net/sales/regional_sales.xlsx',
    map('header', 'true', 'sheets', 'NorthAmerica,EMEA,APAC,LATAM'),
    NULL, NULL, 'FULL', NULL,
    '0 0 5 * * ?', 120,
    'mktg-analytics@example.com', TRUE
);

-- ============ OPERATIONS PROJECT FEEDS =======================================

-- 2.7  Mainframe ledger fixed-length (FIXED)
INSERT INTO ingest_platform.control.feed_config
    (project_id, feed_name, source_type, source_location, source_options,
     target_table, schema_definition, load_mode, watermark_column,
     schedule_cron, sla_minutes, owner, is_active)
VALUES (
    (SELECT project_id FROM ingest_platform.control.projects WHERE project_code = 'operations'),
    'mainframe_ledger', 'FIXED',
    'abfss://landing@operations-data.dfs.core.windows.net/mainframe/ledger/',
    map(),
    NULL,
    '{
        "fields": [
            {"name": "account_id",  "start": 1,  "length": 12, "type": "string", "trim": true},
            {"name": "txn_date",    "start": 13, "length": 8,  "type": "date",   "format": "yyyyMMdd"},
            {"name": "txn_code",    "start": 21, "length": 4,  "type": "string", "trim": true},
            {"name": "amount",      "start": 25, "length": 15, "type": "decimal","scale": 2, "precision": 18},
            {"name": "currency",    "start": 40, "length": 3,  "type": "string", "trim": true},
            {"name": "description", "start": 43, "length": 60, "type": "string", "trim": true}
        ]
    }',
    'INCREMENTAL', NULL,
    '0 0 3 * * ?', 180,
    'ops-platform@example.com', TRUE
);

-- 2.8  SQL Server inventory snapshots (RDBMS, FULL)
INSERT INTO ingest_platform.control.feed_config
    (project_id, feed_name, source_type, source_location, source_options,
     target_table, schema_definition, load_mode, watermark_column,
     schedule_cron, sla_minutes, owner, is_active)
VALUES (
    (SELECT project_id FROM ingest_platform.control.projects WHERE project_code = 'operations'),
    'inventory_snapshot_mssql', 'RDBMS',
    'jdbc:sqlserver://mssql-prod.example.com:1433;database=Operations;encrypt=true',
    map(
        'driver',   'com.microsoft.sqlserver.jdbc.SQLServerDriver',
        'user',     '{{secrets/ops-ingest/mssql_user}}',
        'password', '{{secrets/ops-ingest/mssql_password}}',
        'dbtable',  'dbo.inventory_snapshot'
    ),
    NULL, NULL, 'FULL', NULL,
    '0 0 2 * * ?', 240,
    'ops-platform@example.com', TRUE
);

-- 2.9  CSV transactions Auto Loader (CSV)
INSERT INTO ingest_platform.control.feed_config
    (project_id, feed_name, source_type, source_location, source_options,
     target_table, schema_definition, load_mode, watermark_column,
     schedule_cron, sla_minutes, owner, is_active)
VALUES (
    (SELECT project_id FROM ingest_platform.control.projects WHERE project_code = 'operations'),
    'transactions_csv', 'CSV',
    'abfss://landing@operations-data.dfs.core.windows.net/transactions/',
    map(
        'streaming',       'true',
        'header',          'true',
        'infer_schema',    'true',
        'schema_location', 'abfss://landing@operations-data.dfs.core.windows.net/_schemas/transactions/'
    ),
    NULL, NULL, 'INCREMENTAL', NULL,
    NULL, 30, 'ops-platform@example.com', TRUE
);

-- =============================================================================
-- 3. Sample DQ rules — illustrative rules per feed
-- =============================================================================
-- Rules attach to feeds by feed_id. We resolve via subquery for portability.

-- gl_journal_oracle (Finance) — three rules
INSERT INTO ingest_platform.control.dq_rules
    (feed_id, rule_name, rule_type, predicate, severity, action, error_message, is_active)
VALUES
    ((SELECT feed_id FROM ingest_platform.control.feed_config WHERE feed_name = 'gl_journal_oracle'),
     'journal_id_required', 'NOT_NULL', 'JOURNAL_ID IS NOT NULL',
     'ERROR', 'FAIL_RUN', 'Journal entries must have a primary key', TRUE),

    ((SELECT feed_id FROM ingest_platform.control.feed_config WHERE feed_name = 'gl_journal_oracle'),
     'amount_present', 'NOT_NULL', 'AMOUNT IS NOT NULL',
     'WARN', 'QUARANTINE', 'Amount cannot be null on a journal entry', TRUE),

    ((SELECT feed_id FROM ingest_platform.control.feed_config WHERE feed_name = 'gl_journal_oracle'),
     'currency_iso', 'REGEX', "CURRENCY RLIKE '^[A-Z]{3}$'",
     'WARN', 'QUARANTINE', 'Currency must be a 3-letter ISO code', TRUE);

-- cdp_customers (Marketing) — email validation
INSERT INTO ingest_platform.control.dq_rules
    (feed_id, rule_name, rule_type, predicate, severity, action, error_message, is_active)
VALUES
    ((SELECT feed_id FROM ingest_platform.control.feed_config WHERE feed_name = 'cdp_customers'),
     'valid_email', 'REGEX', "email RLIKE '^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$'",
     'WARN', 'QUARANTINE', 'Email failed RFC-ish validation', TRUE),

    ((SELECT feed_id FROM ingest_platform.control.feed_config WHERE feed_name = 'cdp_customers'),
     'customer_id_required', 'NOT_NULL', 'customer_id IS NOT NULL',
     'ERROR', 'FAIL_RUN', 'customer_id must be present', TRUE);

-- mainframe_ledger (Operations) — ledger sanity
INSERT INTO ingest_platform.control.dq_rules
    (feed_id, rule_name, rule_type, predicate, severity, action, error_message, is_active)
VALUES
    ((SELECT feed_id FROM ingest_platform.control.feed_config WHERE feed_name = 'mainframe_ledger'),
     'amount_in_range', 'RANGE', 'amount BETWEEN -100000000 AND 100000000',
     'WARN', 'QUARANTINE', 'Amount outside expected ledger range', TRUE),

    ((SELECT feed_id FROM ingest_platform.control.feed_config WHERE feed_name = 'mainframe_ledger'),
     'txn_date_valid', 'NOT_NULL', 'txn_date IS NOT NULL',
     'ERROR', 'QUARANTINE', 'Transaction date is required', TRUE);
