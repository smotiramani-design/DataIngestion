"""
Audit and Error services (multi-project edition).

Every audit_log row carries:
  * project_id          — denormalized from feed_config for fast filtering
  * framework_version   — which wheel ran this (governance + diagnostics)

Every error_log row carries:
  * project_id          — required, partitioned on, used by RBAC

These services are the only code path that mutates the control tables.
"""

from __future__ import annotations

import traceback
from datetime import datetime
from typing import Optional

from pyspark.sql import SparkSession
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType, IntegerType,
    TimestampType, BooleanType,
)


# =============================================================================
# Audit
# =============================================================================
class AuditService:
    """Manages audit_log rows for each pipeline run."""

    DEFAULT_TABLE = "ingest_platform.control.audit_log"

    _SCHEMA = StructType([
        StructField("run_id",                StringType(),    False),
        StructField("project_id",            LongType(),      False),
        StructField("feed_id",               LongType(),      False),
        StructField("pipeline_id",           StringType(),    True),
        StructField("start_ts",              TimestampType(), False),
        StructField("end_ts",                TimestampType(), True),
        StructField("status",                StringType(),    False),
        StructField("source_record_count",   LongType(),      True),
        StructField("bronze_count",          LongType(),      True),
        StructField("silver_count",          LongType(),      True),
        StructField("quarantine_count",      LongType(),      True),
        StructField("reconciliation_status", StringType(),    True),
        StructField("duration_seconds",      IntegerType(),   True),
        StructField("triggered_by",          StringType(),    True),
        StructField("error_summary",         StringType(),    True),
        StructField("framework_version",     StringType(),    True),
    ])

    def __init__(self, spark: SparkSession, table: str = DEFAULT_TABLE):
        self.spark = spark
        self.table = table

    # ------ lifecycle --------------------------------------------------------
    def start_run(
        self,
        run_id: str,
        project_id: int,
        feed_id: int,
        framework_version: str,
        pipeline_id: Optional[str] = None,
        triggered_by: str = "schedule",
    ) -> None:
        """Insert the initial RUNNING row, stamped with project + framework version."""
        row = [(
            run_id, project_id, feed_id, pipeline_id,
            datetime.utcnow(), None,
            "RUNNING", None, None, None, None, None, None,
            triggered_by, None, framework_version,
        )]
        df = self.spark.createDataFrame(row, schema=self._SCHEMA)
        df.write.mode("append").saveAsTable(self.table)

    def complete_run(
        self,
        run_id: str,
        status: str,
        source_count: Optional[int] = None,
        bronze_count: Optional[int] = None,
        silver_count: Optional[int] = None,
        quarantine_count: Optional[int] = None,
        reconciliation_status: Optional[str] = None,
        error_summary: Optional[str] = None,
    ) -> None:
        """MERGE the final state of the run."""
        if status not in ("SUCCESS", "FAILED", "PARTIAL"):
            raise ValueError(f"Invalid terminal status: {status}")

        sets = [
            "t.end_ts = current_timestamp()",
            f"t.status = '{status}'",
            "t.duration_seconds = CAST(unix_timestamp(current_timestamp()) - unix_timestamp(t.start_ts) AS INT)",
        ]
        if source_count is not None:      sets.append(f"t.source_record_count = {int(source_count)}")
        if bronze_count is not None:      sets.append(f"t.bronze_count = {int(bronze_count)}")
        if silver_count is not None:      sets.append(f"t.silver_count = {int(silver_count)}")
        if quarantine_count is not None:  sets.append(f"t.quarantine_count = {int(quarantine_count)}")
        if reconciliation_status:         sets.append(f"t.reconciliation_status = '{reconciliation_status}'")
        if error_summary:
            safe = error_summary.replace("'", "''")[:4000]
            sets.append(f"t.error_summary = '{safe}'")

        sql = f"""
            UPDATE {self.table} AS t
            SET    {', '.join(sets)}
            WHERE  t.run_id = '{run_id}'
        """
        self.spark.sql(sql)


# =============================================================================
# Errors
# =============================================================================
class ErrorService:
    """Writes rows to error_log."""

    DEFAULT_TABLE = "ingest_platform.control.error_log"

    _SCHEMA = StructType([
        StructField("project_id",       LongType(),      False),
        StructField("run_id",           StringType(),    False),
        StructField("feed_id",          LongType(),      False),
        StructField("error_ts",         TimestampType(), False),
        StructField("error_type",       StringType(),    False),
        StructField("error_severity",   StringType(),    False),
        StructField("raw_record",       StringType(),    True),
        StructField("rule_name",        StringType(),    True),   # ← renamed
        StructField("error_message",    StringType(),    True),
        StructField("stack_trace",      StringType(),    True),
        StructField("resolved_flag",    BooleanType(),   False),
        StructField("resolved_ts",      TimestampType(), True),
        StructField("resolved_by",      StringType(),    True),
    ])

    def __init__(self, spark: SparkSession, table: str = DEFAULT_TABLE):
        self.spark = spark
        self.table = table

    # ------ single error -----------------------------------------------------
    def log_exception(
        self,
        run_id: str,
        project_id: int,
        feed_id: int,
        error_type: str,
        severity: str,
        message: str,
        exc: Optional[BaseException] = None,
        raw_record: Optional[str] = None,
    ) -> None:
        """Log a single exception or framework-level error (non-DQ)."""
        stack = ""
        if exc is not None:
            stack = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        row = [(
            project_id, run_id, feed_id,
            datetime.utcnow(), error_type, severity,
            raw_record, None, message[:4000], stack[:8000],
            False, None, None,
        )]
        df = self.spark.createDataFrame(row, schema=self._SCHEMA)
        df.write.mode("append").saveAsTable(self.table)

    # ------ DQ rule violation summary ----------------------------------------
    # Writes ONE row per (run, rule) pair — not one per bad record. The bad
    # records themselves live in the feed's quarantine Delta table, written
    # directly by the DQ engine. Keeping these summaries in error_log means
    # the operator console gets a tidy "open errors" list without joining
    # against quarantine tables.
    def log_dq_violation(
        self,
        run_id: str,
        project_id: int,
        feed_id: int,
        rule_name: str,
        severity: str,
        message: str,
        bad_count: int,
    ) -> None:
        msg = f"{message} (rows affected: {bad_count})"
        row = [(
            project_id, run_id, feed_id,
            datetime.utcnow(), "DQ", severity,
            None, rule_name, msg[:4000], None,
            False, None, None,
        )]
        df = self.spark.createDataFrame(row, schema=self._SCHEMA)
        df.write.mode("append").saveAsTable(self.table)
