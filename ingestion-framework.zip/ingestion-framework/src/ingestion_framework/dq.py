"""
Data Quality engine — replaces DLT @expect_or_quarantine decorators.

The framework deploys without DLT, so quality enforcement is our code.
At a high level, for each feed run after Bronze write:

  1. Read all active rows from dq_rules where feed_id = <this feed>
  2. For each rule, evaluate the SQL predicate against the just-landed batch
  3. Split the rows: good ones flow to Silver, bad ones get the rule's `action`
  4. Aggregate quarantine rows and write them to <silver_table>_quarantine
  5. Emit one error_log row per (run, rule) pair that had violations
  6. If any FAIL_RUN rule has violations, raise — the engine marks run FAILED

Rule semantics:
  predicate    : a SQL boolean expression where TRUE means "row is good"
  severity     : informational tier — WARN | ERROR | FATAL (drives alerting)
  action       : DROP | QUARANTINE | FAIL_RUN — controls row routing
  rule_type    : NOT_NULL | RANGE | REGEX | UNIQUE | CUSTOM_SQL
                 — UNIQUE is special: predicate is ignored, the engine groups
                 by the columns named in `predicate` (comma-separated) and
                 marks duplicates as failures.

The engine intentionally does NOT optimize for the case where rules are
correlated (e.g. same predicate evaluated twice) — clarity beats cleverness
for a control plane this small. If perf becomes an issue, we can union the
predicates into one filter.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import List, Optional, Tuple

from pyspark.sql import DataFrame, SparkSession, Row
from pyspark.sql.functions import col, count, expr, lit
from pyspark.sql.window import Window


log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# DQ rule model
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class DqRule:
    rule_id: int
    feed_id: int
    rule_name: str
    rule_type: str        # NOT_NULL | RANGE | REGEX | UNIQUE | CUSTOM_SQL
    predicate: str
    severity: str         # WARN | ERROR | FATAL
    action: str           # DROP | QUARANTINE | FAIL_RUN
    error_message: Optional[str]
    is_active: bool

    @classmethod
    def from_row(cls, r: Row) -> "DqRule":
        d = r.asDict()
        return cls(
            rule_id=d["rule_id"],
            feed_id=d["feed_id"],
            rule_name=d["rule_name"],
            rule_type=d["rule_type"],
            predicate=d["predicate"],
            severity=d["severity"],
            action=d["action"],
            error_message=d.get("error_message"),
            is_active=bool(d["is_active"]),
        )


@dataclass(frozen=True)
class RuleViolation:
    """Result of evaluating one rule against the batch."""
    rule: DqRule
    bad_count: int


@dataclass(frozen=True)
class DqResult:
    """What the engine cares about after evaluation."""
    good_df: DataFrame
    quarantine_df: Optional[DataFrame]   # None if no QUARANTINE rules fired
    violations: List[RuleViolation]
    quarantine_count: int
    dropped_count: int

    @property
    def has_fatal_violations(self) -> bool:
        return any(
            v.bad_count > 0 and v.rule.action == "FAIL_RUN"
            for v in self.violations
        )


# ---------------------------------------------------------------------------
# Repository
# ---------------------------------------------------------------------------
class DqRuleRepository:
    """Read access to dq_rules."""

    DEFAULT_TABLE = "ingest_platform.control.dq_rules"

    def __init__(self, spark: SparkSession, table: str = DEFAULT_TABLE):
        self.spark = spark
        self.table = table

    def list_active_for_feed(self, feed_id: int) -> List[DqRule]:
        rows = (self.spark.table(self.table)
                .where(f"feed_id = {int(feed_id)} AND is_active = TRUE")
                .collect())
        return [DqRule.from_row(r) for r in rows]


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------
class DqEngine:
    """Evaluate dq_rules against a batch of newly-landed Bronze rows."""

    # Internal column used to mark per-rule status. Stripped from outputs.
    _STATUS_COL = "_dq_status"

    def __init__(self, spark: SparkSession, repo: Optional[DqRuleRepository] = None):
        self.spark = spark
        self.repo = repo or DqRuleRepository(spark)

    # ----------------------------------------------------------------- public
    def evaluate(self, df: DataFrame, feed_id: int) -> DqResult:
        """
        Evaluate all active rules for `feed_id` against `df`.

        Returns a DqResult with the partitioned data. The caller is
        responsible for actually writing quarantine_df (we don't pick the
        target table here — that's project- and feed-specific and lives in
        the Engine class).
        """
        rules = self.repo.list_active_for_feed(feed_id)
        if not rules:
            log.info("No active DQ rules for feed_id=%s — passing all rows through", feed_id)
            return DqResult(
                good_df=df, quarantine_df=None,
                violations=[], quarantine_count=0, dropped_count=0,
            )

        # Materialize once — we'll filter twice (good vs bad)
        df = df.cache()

        violations: List[RuleViolation] = []
        # Build the "good predicate" — a row is GOOD if it passes EVERY active
        # rule. We accumulate these as a conjunction.
        # For QUARANTINE/DROP/FAIL_RUN we still need per-rule bad sets to
        # report counts, so we evaluate each rule individually too.

        good_mask_parts: List[str] = []
        bad_dfs_for_quarantine: List[DataFrame] = []
        dropped_count = 0
        any_fail_run_violations = False

        for rule in rules:
            # Build the predicate expression for this rule
            try:
                rule_expr = self._build_predicate(rule)
            except ValueError as exc:
                log.error("Cannot build predicate for rule %s: %s", rule.rule_name, exc)
                continue

            bad = df.where(f"NOT ({rule_expr})")
            bad_count = bad.count()
            violations.append(RuleViolation(rule=rule, bad_count=bad_count))

            if bad_count == 0:
                continue

            log.warning(
                "DQ rule violated: feed_id=%s rule=%s severity=%s action=%s bad=%d",
                feed_id, rule.rule_name, rule.severity, rule.action, bad_count,
            )

            if rule.action == "FAIL_RUN":
                any_fail_run_violations = True
                # Still include in good_mask so we don't keep these rows.
                good_mask_parts.append(f"({rule_expr})")
            elif rule.action == "DROP":
                dropped_count += bad_count
                good_mask_parts.append(f"({rule_expr})")
            elif rule.action == "QUARANTINE":
                # Stamp the bad rows with the rule that flagged them and add
                # to the quarantine union.
                tagged = (bad
                          .withColumn("_dq_rule_id",   lit(rule.rule_id))
                          .withColumn("_dq_rule_name", lit(rule.rule_name))
                          .withColumn("_dq_severity",  lit(rule.severity)))
                bad_dfs_for_quarantine.append(tagged)
                good_mask_parts.append(f"({rule_expr})")

        # Compute the good-rows set by ANDing every rule's predicate
        if good_mask_parts:
            good_df = df.where(" AND ".join(good_mask_parts))
        else:
            good_df = df

        # Union all quarantine sets if any
        quarantine_df: Optional[DataFrame] = None
        quarantine_count = 0
        if bad_dfs_for_quarantine:
            quarantine_df = bad_dfs_for_quarantine[0]
            for extra in bad_dfs_for_quarantine[1:]:
                # unionByName so column order doesn't matter; allow missing
                # columns since QUARANTINE rules might tag different supersets
                quarantine_df = quarantine_df.unionByName(extra, allowMissingColumns=True)
            quarantine_count = quarantine_df.count()

        result = DqResult(
            good_df=good_df,
            quarantine_df=quarantine_df,
            violations=violations,
            quarantine_count=quarantine_count,
            dropped_count=dropped_count,
        )

        # Caller decides whether to raise on FAIL_RUN; we just expose the flag.
        if any_fail_run_violations:
            log.error("FAIL_RUN-tier DQ violations detected for feed_id=%s", feed_id)

        return result

    # ----------------------------------------------------------------- internal
    @staticmethod
    def _build_predicate(rule: DqRule) -> str:
        """
        Translate (rule_type, predicate) into a SQL boolean expression where
        TRUE means the row is good.

        For most rule_types, `predicate` IS the expression. UNIQUE is the
        exception — `predicate` is treated as a comma-separated column list
        and the engine adds a windowed dedup check.
        """
        rt = rule.rule_type.upper()
        if rt in ("NOT_NULL", "RANGE", "REGEX", "CUSTOM_SQL"):
            # Trust the operator's predicate
            return rule.predicate
        if rt == "UNIQUE":
            # The predicate is a column list. We can't express "no duplicates
            # exist in this batch for these columns" as a row-level predicate
            # without a window — bail out. UNIQUE is handled separately by
            # _evaluate_unique_rule below; this builder shouldn't be called.
            raise ValueError(
                f"UNIQUE rule type ({rule.rule_name}) needs window evaluation; "
                "evaluate via _evaluate_unique_rule instead."
            )
        raise ValueError(f"Unknown rule_type: {rule.rule_type}")

    # NOTE: UNIQUE rule support is sketched but intentionally not wired into
    # evaluate() above — adding it cleanly requires a windowed pass that
    # preserves the per-rule bad sets. Tracked as future work; the schema
    # supports it via chk_rule_type.
    @staticmethod
    def _evaluate_unique_rule(df: DataFrame, rule: DqRule) -> Tuple[DataFrame, int]:
        keys = [k.strip() for k in rule.predicate.split(",")]
        if not keys:
            raise ValueError(f"UNIQUE rule {rule.rule_name} has no key columns")
        w = Window.partitionBy(*keys)
        with_count = df.withColumn("_dq_dup_count", count("*").over(w))
        bad = with_count.where("_dq_dup_count > 1").drop("_dq_dup_count")
        return bad, bad.count()
