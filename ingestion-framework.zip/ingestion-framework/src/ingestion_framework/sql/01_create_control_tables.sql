-- =============================================================================
-- Data Ingestion Framework — Control Tables (Multi-Project Platform Edition)
-- =============================================================================
-- The framework is deployed once per division and shared by many projects.
-- Every operational table is scoped by project_id so that:
--   * Two projects can both have a feed named "customers" without colliding
--   * RBAC can be granted per project (Unity Catalog row filters or views)
--   * One project's outage doesn't blast-radius other projects
--   * The platform team can roll new framework versions without forcing all
--     projects to upgrade in lockstep
--
-- Tables:
--   projects     — registry of consuming projects (the new top-level entity)
--   feed_config  — feeds, scoped by project_id
--   dq_rules     — data-quality rules per feed, evaluated by the DQ engine
--                  (replaces DLT @expect_or_quarantine decorators)
--   audit_log    — runs, scoped by project_id (denormalized from feed_config)
--   error_log    — errors, scoped by project_id
-- =============================================================================

CREATE CATALOG IF NOT EXISTS ingest_platform;
CREATE SCHEMA IF NOT EXISTS ingest_platform.control;

-- -----------------------------------------------------------------------------
-- projects — registry of consuming projects (NEW)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ingest_platform.control.projects (
    project_id           BIGINT GENERATED ALWAYS AS IDENTITY,
    project_code         STRING  NOT NULL,    -- short, unique (e.g. 'finance', 'mktg')
    project_name         STRING  NOT NULL,    -- human-readable
    description          STRING,

    -- Default landing zones — feeds inherit these unless overridden.
    -- Bronze/Silver/Gold are conventionally three schemas in one catalog.
    default_catalog      STRING  NOT NULL,    -- e.g. 'finance_data'
    bronze_schema        STRING  NOT NULL DEFAULT 'bronze',
    silver_schema        STRING  NOT NULL DEFAULT 'silver',
    gold_schema          STRING  NOT NULL DEFAULT 'gold',

    -- Operational defaults
    default_secret_scope STRING,              -- per-project secret scope name
    alert_email          STRING  NOT NULL,    -- on-failure escalation
    pagerduty_service    STRING,              -- optional FATAL-tier routing

    -- Governance
    framework_version    STRING  NOT NULL DEFAULT '0.1.0',  -- which wheel they're pinned to
    owner_team           STRING  NOT NULL,    -- accountable team / DL
    cost_center          STRING,              -- chargeback tag
    is_active            BOOLEAN NOT NULL DEFAULT TRUE,

    created_ts           TIMESTAMP NOT NULL DEFAULT current_timestamp(),
    updated_ts           TIMESTAMP NOT NULL DEFAULT current_timestamp(),

    CONSTRAINT pk_projects PRIMARY KEY (project_id)
)
USING DELTA
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Project codes are the natural key — must be unique
CREATE INDEX IF NOT EXISTS idx_projects_code
    ON ingest_platform.control.projects (project_code);

-- -----------------------------------------------------------------------------
-- feed_config — now scoped by project_id
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ingest_platform.control.feed_config (
    feed_id              BIGINT GENERATED ALWAYS AS IDENTITY,
    project_id           BIGINT  NOT NULL,    -- NEW — owning project
    feed_name            STRING  NOT NULL,
    source_type          STRING  NOT NULL,
    source_location      STRING  NOT NULL,
    source_options       MAP<STRING, STRING>,

    -- target_table is now optional — if NULL, framework derives it from the
    -- project's default_catalog + bronze_schema + feed_name.
    -- Operators can still override per-feed when needed.
    target_table         STRING,

    schema_definition    STRING,
    load_mode            STRING  NOT NULL,
    watermark_column     STRING,
    schedule_cron        STRING,
    sla_minutes          INT,
    owner                STRING  NOT NULL,    -- individual / DL within the project
    is_active            BOOLEAN NOT NULL DEFAULT TRUE,
    created_ts           TIMESTAMP NOT NULL DEFAULT current_timestamp(),
    updated_ts           TIMESTAMP NOT NULL DEFAULT current_timestamp(),

    CONSTRAINT pk_feed_config PRIMARY KEY (feed_id),
    CONSTRAINT fk_feed_project FOREIGN KEY (project_id)
        REFERENCES ingest_platform.control.projects(project_id),
    CONSTRAINT chk_source_type CHECK (source_type IN
        ('API','RDBMS','JSON','EXCEL','CSV','DELIMITED','FIXED')),
    CONSTRAINT chk_load_mode   CHECK (load_mode   IN
        ('FULL','INCREMENTAL','CDC','UPSERT'))
)
USING DELTA
PARTITIONED BY (project_id)
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- (project_id, feed_name) is the business key — one feed name per project,
-- but the same name CAN be reused across projects.
CREATE INDEX IF NOT EXISTS idx_feed_config_proj_name
    ON ingest_platform.control.feed_config (project_id, feed_name);

-- -----------------------------------------------------------------------------
-- audit_log — denormalize project_id for fast per-project filters
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ingest_platform.control.audit_log (
    run_id                 STRING    NOT NULL,
    project_id             BIGINT    NOT NULL,   -- NEW (denormalized from feed_config)
    feed_id                BIGINT    NOT NULL,
    pipeline_id            STRING,
    start_ts               TIMESTAMP NOT NULL,
    end_ts                 TIMESTAMP,
    status                 STRING    NOT NULL,
    source_record_count    BIGINT,
    bronze_count           BIGINT,
    silver_count           BIGINT,
    quarantine_count       BIGINT,
    reconciliation_status  STRING,
    duration_seconds       INT,
    triggered_by           STRING,
    error_summary          STRING,
    framework_version      STRING,              -- NEW — which wheel ran this

    CONSTRAINT pk_audit_log PRIMARY KEY (run_id),
    CONSTRAINT fk_audit_project FOREIGN KEY (project_id)
        REFERENCES ingest_platform.control.projects(project_id),
    CONSTRAINT chk_audit_status CHECK (status IN
        ('RUNNING','SUCCESS','FAILED','PARTIAL'))
)
USING DELTA
PARTITIONED BY (project_id)
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact'   = 'true'
);

-- -----------------------------------------------------------------------------
-- error_log — same project scoping
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ingest_platform.control.error_log (
    error_id           BIGINT GENERATED ALWAYS AS IDENTITY,
    project_id         BIGINT    NOT NULL,    -- NEW
    run_id             STRING    NOT NULL,
    feed_id            BIGINT    NOT NULL,
    error_ts           TIMESTAMP NOT NULL,
    error_type         STRING    NOT NULL,
    error_severity     STRING    NOT NULL,
    raw_record         STRING,
    rule_name          STRING,            -- FK to dq_rules.rule_name (when error_type='DQ')
    error_message      STRING,
    stack_trace        STRING,
    resolved_flag      BOOLEAN   NOT NULL DEFAULT FALSE,
    resolved_ts        TIMESTAMP,
    resolved_by        STRING,

    CONSTRAINT pk_error_log PRIMARY KEY (error_id),
    CONSTRAINT fk_error_project FOREIGN KEY (project_id)
        REFERENCES ingest_platform.control.projects(project_id),
    CONSTRAINT chk_error_type     CHECK (error_type     IN
        ('SCHEMA','DQ','CONNECTIVITY','RUNTIME','CONFIG')),
    CONSTRAINT chk_error_severity CHECK (error_severity IN
        ('WARN','ERROR','FATAL'))
)
USING DELTA
PARTITIONED BY (project_id)
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact'   = 'true'
);

-- -----------------------------------------------------------------------------
-- dq_rules — data-quality rules per feed (NEW; replaces DLT expectations)
-- -----------------------------------------------------------------------------
-- One row per rule per feed. The DQ engine reads this table at run time and
-- evaluates each active rule's predicate against the just-landed Bronze data.
-- Rules are first-class control entities so the operator console can CRUD
-- them without code changes or redeploys.
CREATE TABLE IF NOT EXISTS ingest_platform.control.dq_rules (
    rule_id            BIGINT GENERATED ALWAYS AS IDENTITY,
    feed_id            BIGINT  NOT NULL,
    rule_name          STRING  NOT NULL,    -- e.g. 'amount_non_negative'
    rule_type          STRING  NOT NULL,    -- NOT_NULL | RANGE | REGEX | UNIQUE | CUSTOM_SQL
    predicate          STRING  NOT NULL,    -- SQL boolean expression (true = good row)
    severity           STRING  NOT NULL,    -- WARN | ERROR | FATAL
    action             STRING  NOT NULL,    -- DROP | QUARANTINE | FAIL_RUN
    error_message      STRING,              -- operator-friendly description
    is_active          BOOLEAN NOT NULL DEFAULT TRUE,
    created_ts         TIMESTAMP NOT NULL DEFAULT current_timestamp(),
    updated_ts         TIMESTAMP NOT NULL DEFAULT current_timestamp(),

    CONSTRAINT pk_dq_rules PRIMARY KEY (rule_id),
    CONSTRAINT fk_dq_rules_feed FOREIGN KEY (feed_id)
        REFERENCES ingest_platform.control.feed_config(feed_id),
    CONSTRAINT chk_rule_type CHECK (rule_type IN
        ('NOT_NULL','RANGE','REGEX','UNIQUE','CUSTOM_SQL')),
    CONSTRAINT chk_rule_severity CHECK (severity IN
        ('WARN','ERROR','FATAL')),
    CONSTRAINT chk_rule_action CHECK (action IN
        ('DROP','QUARANTINE','FAIL_RUN'))
)
USING DELTA
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true'
);

-- Rule names must be unique per feed
CREATE INDEX IF NOT EXISTS idx_dq_rules_feed_name
    ON ingest_platform.control.dq_rules (feed_id, rule_name);

-- -----------------------------------------------------------------------------
-- Project-scoped views — these are what the React console queries.
-- A SECURE VIEW with row filters could replace these to enforce RBAC at the
-- catalog layer; for now they're plain views and the console filters by
-- project_id explicitly.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW ingest_platform.control.v_active_feeds AS
SELECT f.*, p.project_code, p.project_name, p.default_catalog
FROM   ingest_platform.control.feed_config f
JOIN   ingest_platform.control.projects p USING (project_id)
WHERE  f.is_active = TRUE AND p.is_active = TRUE;

CREATE OR REPLACE VIEW ingest_platform.control.v_recent_runs AS
SELECT a.*, f.feed_name, f.source_type, f.target_table,
       p.project_code, p.project_name
FROM   ingest_platform.control.audit_log a
JOIN   ingest_platform.control.feed_config f USING (feed_id)
JOIN   ingest_platform.control.projects p ON p.project_id = a.project_id
WHERE  a.start_ts >= current_timestamp() - INTERVAL 7 DAYS
ORDER BY a.start_ts DESC;

CREATE OR REPLACE VIEW ingest_platform.control.v_open_errors AS
SELECT e.*, f.feed_name, f.target_table,
       p.project_code, p.project_name
FROM   ingest_platform.control.error_log e
JOIN   ingest_platform.control.feed_config f USING (feed_id)
JOIN   ingest_platform.control.projects p ON p.project_id = e.project_id
WHERE  e.resolved_flag = FALSE;

-- Per-project SLA / reliability summary — feeds the platform admin dashboard
CREATE OR REPLACE VIEW ingest_platform.control.v_project_health_24h AS
SELECT
    p.project_id,
    p.project_code,
    p.project_name,
    COUNT(DISTINCT f.feed_id)                                      AS active_feeds,
    COUNT(a.run_id)                                                AS runs_24h,
    SUM(CASE WHEN a.status = 'SUCCESS' THEN 1 ELSE 0 END)          AS successes_24h,
    SUM(CASE WHEN a.status = 'FAILED'  THEN 1 ELSE 0 END)          AS failures_24h,
    SUM(CASE WHEN a.status = 'PARTIAL' THEN 1 ELSE 0 END)          AS partial_24h,
    COALESCE(SUM(a.quarantine_count), 0)                           AS quarantined_24h
FROM       ingest_platform.control.projects p
LEFT JOIN  ingest_platform.control.feed_config f
       ON f.project_id = p.project_id AND f.is_active = TRUE
LEFT JOIN  ingest_platform.control.audit_log a
       ON a.project_id = p.project_id
       AND a.start_ts >= current_timestamp() - INTERVAL 24 HOURS
WHERE p.is_active = TRUE
GROUP BY p.project_id, p.project_code, p.project_name;
