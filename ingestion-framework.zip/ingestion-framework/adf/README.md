# ADF templates

Parameterized Azure Data Factory pipeline + trigger templates for the
ingestion platform. One ADF pipeline runs per project; this folder
contains the templates from which each project's resources are generated.

## Files

| File | Purpose |
|---|---|
| `pipeline_template.json` | The pipeline definition. Reads `feed_config` + `dq_rules`, fans out per-feed via ForEach, branches on `source_type` to ADF Copy or Databricks Notebook, then runs DQ + Silver + Gold notebooks. |
| `trigger_schedule_template.json` | A schedule trigger (hourly default). Each project gets its own trigger with its own cadence. |

## Generating per-project resources

The templates use `${projectCode}` as a placeholder. Per-project resources are
generated at deploy time by simple text substitution:

```bash
# Example: generate finance pipeline + trigger
sed 's/${projectCode}/finance/g' adf/pipeline_template.json \
    > out/ingest_pipeline_finance.json
sed 's/${projectCode}/finance/g' adf/trigger_schedule_template.json \
    > out/trigger_finance_hourly.json
```

In CI this happens for every project listed in `databricks.yml`'s
`variables.projects` block.

## Required Linked Services in the ADF instance

The pipeline references these by name; they must exist in the target ADF
instance before deploying the pipeline:

- **`ls_databricks`** — Azure Databricks Linked Service. MSI-authenticated.
- **`ls_adls`** — ADLS Gen2 storage. The `landing`, `bronze`, and `silver`
  zones are all underneath this.
- **`ls_oracle`** — Oracle JDBC Linked Service. Credentials from Key Vault.
- **`ls_mssql`** — SQL Server Linked Service. Credentials from Key Vault.
- **`ls_keyvault`** — Azure Key Vault for all source-system secrets.

## Required Datasets

- **`ds_databricks_control`** — Databricks Delta dataset pointing at
  `ingest_platform.control` schema. Used by the Lookup activity.
- **`ds_rdbms_dynamic`** — parameterized RDBMS source dataset. Connection
  string + table name come from the per-feed iteration.
- **`ds_adls_csv`**, **`ds_adls_delimited`** — ADLS file source datasets,
  parameterized by path.
- **`ds_bronze_dynamic`** — Databricks Delta sink dataset, parameterized by
  the feed's `target_table`.

## Required Notebooks (deployed to Databricks workspace)

These are thin wrappers around the framework wheel's CLIs. Each lives at
`/Shared/ingestion-framework/notebooks/`:

- **`run_feed`** — calls `ingest-run-feed --project ... --feed ... --triggered-by ...`
- **`dq_and_silver`** — runs DQ engine + promotes to Silver
- **`build_gold`** — runs the project-specific Gold transforms

The notebooks consume widget parameters from ADF's `baseParameters` and
shell out to the wheel's Python entry points.

## Why no Asset Bundle for ADF?

Databricks Asset Bundles only deploy Databricks-native resources (Jobs,
DLT pipelines, notebooks, ML resources). ADF has its own ARM-based
deployment mechanism. For consistency, we generate per-project ADF JSON
in the same CI pass that deploys the bundle, and use `az datafactory
pipeline create` (or ARM template deployment) to push them.

## Trigger types beyond schedule

We currently ship only `trigger_schedule_template.json`. Two future options:

- **Tumbling window trigger** — for incremental loads with explicit window
  boundaries (better than a plain schedule when downstream needs to know
  exactly which window each run covered).
- **Storage event trigger** — fires on blob arrival. We deferred this when
  we dropped streaming, but it's a clean way to support file-drop SFTP feeds
  if needed later.
