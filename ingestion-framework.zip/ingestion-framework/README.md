# Ingestion Framework

A configuration-driven, source-agnostic data ingestion framework for
Databricks + Delta Lake. One row in `feed_config` is everything you need to
onboard a new feed — eight source patterns supported out of the box.

## Install

From a built wheel:

```bash
pip install ingestion_framework-0.1.0-py3-none-any.whl
```

From source (editable, for development):

```bash
git clone <repo>
cd ingestion-framework
pip install -e ".[dev]"
```

## What this framework does

- **Lands any source into Bronze without losing a record.** APIs, Oracle / SQL
  Server, JSON, Excel (single & multi-tab), CSV, delimited, and fixed-length
  files all funnel through a common engine.
- **Promotes Bronze → Silver → Gold via Delta Live Tables**, with quarantine
  (not drop) for rows that fail data-quality expectations.
- **Logs every run** to `audit_log` and **every bad record** to `error_log`,
  giving operators a single place to triage and replay.

## Package layout

```
ingestion-framework/
├── pyproject.toml                         Build & dependency config
├── README.md                              You are here
├── databricks.yml                         Asset Bundle root
├── resources/                             Asset Bundle Job & Pipeline definitions
│   ├── jobs.yml
│   └── pipelines.yml
├── src/
│   └── ingestion_framework/               The installable package
│       ├── config.py                      FeedConfig + ConfigRepository
│       ├── audit.py                       AuditService + ErrorService
│       ├── engine.py                      IngestionEngine
│       ├── connectors/                    7 connector implementations
│       ├── pipelines/dlt_pipeline.py      DLT pipeline (config-driven)
│       ├── jobs/                          run_feed, run_all_feeds, drain_quarantine
│       ├── sql/                           DDL — shipped inside the wheel
│       └── config_samples/                INSERT examples — shipped inside the wheel
└── tests/                                 50 pytest cases
```

## Quickstart

### 1. Provision the control tables

The DDL ships inside the wheel. Extract and execute via Databricks SQL:

```python
from importlib.resources import files
ddl = (files("ingestion_framework") / "sql" / "01_create_control_tables.sql").read_text()
# Split on ; and execute each, or paste into a SQL editor
```

### 2. Onboard a feed

Pick the closest sample from `ingestion_framework/config_samples/sample_feeds.sql`
and adapt it. Onboarding is a config insert — no code change.

```sql
INSERT INTO ingest_platform.control.feed_config
    (feed_name, source_type, source_location, source_options,
     target_table, load_mode, owner, is_active)
VALUES (
    'my_new_feed',
    'CSV',
    'abfss://landing@mydatalake.dfs.core.windows.net/my_feed/',
    map('header', 'true', 'streaming', 'true'),
    'ingest_platform.bronze.my_new_feed',
    'INCREMENTAL',
    'me@example.com',
    TRUE
);
```

### 3. Run it

After installing the wheel, the package exposes three console scripts:

```bash
# Single feed
ingest-run-feed --feed my_new_feed --triggered-by manual

# All active feeds, bounded parallelism
ingest-run-all-feeds --max-parallel 4

# Drain DLT quarantine into error_log
ingest-drain-quarantine
```

Or call from a notebook:

```python
from ingestion_framework.jobs.run_feed import run
run_id = run(feed_name="my_new_feed", triggered_by="manual")
```

### 4. Promote to Silver / Gold via DLT

The DLT pipeline notebook lives at
`src/ingestion_framework/pipelines/dlt_pipeline.py`. The Asset Bundle
deploys it for you (see below).

## Deployment via Databricks Asset Bundles

The framework ships with a Databricks Asset Bundle so the entire deployment
(library upload, jobs, schedules, DLT pipeline) lives as code:

```bash
# Validate
databricks bundle validate -t dev

# Deploy to dev
databricks bundle deploy -t dev

# Run the all-feeds Job ad hoc
databricks bundle run ingest_all_feeds_job -t dev

# Promote to prod
databricks bundle deploy -t prod
```

See `databricks.yml` and the `resources/` directory for the full topology.

## Adding a new source type

1. Subclass `BaseConnector` in `src/ingestion_framework/connectors/your_connector.py`
2. Implement `read() -> DataFrame`
3. Register it in `src/ingestion_framework/connectors/__init__.py`
4. Add a `CHECK` constraint value in `sql/01_create_control_tables.sql`

## Design contracts

These hold across every connector and code path:

- **Zero record loss.** Connectors do not filter, dedupe, or drop. Bronze is
  append-only. Bad rows are quarantined, never silently discarded.
- **Idempotent runs.** Re-running the same `run_id` produces the same result.
  Watermarks come from MAX(watermark_column) on Bronze, not external state.
- **Replay from Bronze.** Source systems are read once. DQ rule changes replay
  through Silver against the existing Bronze data.
- **Config table is the only control surface.** Operators never edit code to
  change a feed.

## Running the tests

```bash
pip install -e ".[test]"
pytest -v
```

The suite spins up a local in-process SparkSession. ~30 seconds end-to-end.

## Production prerequisites

These are intentionally NOT bundled — each org provisions them:

- **Databricks workspace** with Unity Catalog enabled
- **JDBC drivers** for Oracle / SQL Server installed on the cluster
- **`com.crealytics:spark-excel`** on the cluster's library path for Excel
- **Secret scopes** (`dbutils.secrets`) for credentials referenced as
  `{{secrets/scope/key}}` in `source_options`
- **Storage credentials / external locations** in Unity Catalog for any
  ADLS / S3 paths
